# Source code for the Compress "Max quality" encoder

Compress (https://github.com/CustomGPTer/compress) ships one program built from the three source
archives in this folder, all unmodified:

| File               | What                 | Upstream                                              | Licence          |
|--------------------|----------------------|-------------------------------------------------------|------------------|
| ffmpeg-8.0.tar.gz  | FFmpeg, tag n8.0     | https://github.com/FFmpeg/FFmpeg                      | GPL v2 or later (as configured) |
| x264.tar.gz        | x264, stable branch  | https://github.com/mirror/x264 (commit c24e06c)       | GPL v2 or later  |
| x265-4.1.tar.gz    | x265, tag 4.1        | https://bitbucket.org/multicoreware/x265_git          | GPL v2 or later  |

`build.sh` is the exact script used to build them into `libffmpeg.so` for 64-bit ARM Android.

## Rebuilding

Needs Linux or macOS (or Windows with WSL), the Android NDK (29.0.14206865 was used), cmake, ninja,
make, nasm and pkg-config.

    mkdir src
    tar -xzf ffmpeg-8.0.tar.gz -C src
    tar -xzf x264.tar.gz -C src
    tar -xzf x265-4.1.tar.gz -C src
    NDK=/path/to/android-ndk ./build.sh

The result is `out/libffmpeg.so`. Copy it to `app/src/main/jniLibs/arm64-v8a/` in the Compress project.

#!/bin/bash
# Builds the software encoder used by Compress's "Max quality" mode:
# FFmpeg with x264 and x265, as a single arm64 Android executable.
# Usage: NDK=/path/to/ndk ./build.sh
set -euo pipefail

NDK="${NDK:?set NDK to the Android NDK folder}"
API=29
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/src"
OUT="$HERE/out"
PREFIX="$OUT/prefix"
TC="$NDK/toolchains/llvm/prebuilt/linux-x86_64"
SYSROOT="$TC/sysroot"
CC="$TC/bin/aarch64-linux-android${API}-clang"
CXX="$TC/bin/aarch64-linux-android${API}-clang++"
JOBS="${JOBS:-$(nproc)}"
export PKG_CONFIG_LIBDIR="$PREFIX/lib/pkgconfig"
export PKG_CONFIG_PATH="$PREFIX/lib/pkgconfig"
mkdir -p "$PREFIX"

echo "=== x264 ==="
if [ ! -f "$PREFIX/lib/libx264.a" ]; then
  cd "$SRC/x264"
  make distclean >/dev/null 2>&1 || true
  CC="$CC" AR="$TC/bin/llvm-ar" RANLIB="$TC/bin/llvm-ranlib" STRIP="$TC/bin/llvm-strip" \
  ./configure --host=aarch64-linux-android --sysroot="$SYSROOT" \
    --cross-prefix="$TC/bin/llvm-" \
    --enable-static --enable-pic --disable-cli --disable-opencl \
    --bit-depth=8 --prefix="$PREFIX"
  make -j"$JOBS"
  make install
fi

echo "=== x265 ==="
if [ ! -f "$PREFIX/lib/libx265.a" ]; then
  mkdir -p "$OUT/x265-build" && cd "$OUT/x265-build"
  cmake "$SRC/x265/source" -G Ninja \
    -DCMAKE_SYSTEM_NAME=Linux -DCMAKE_SYSTEM_PROCESSOR=aarch64 -DCROSS_COMPILE_ARM64=ON \
    -DCMAKE_C_COMPILER="$CC" -DCMAKE_CXX_COMPILER="$CXX" \
    -DCMAKE_AR="$TC/bin/llvm-ar" -DCMAKE_RANLIB="$TC/bin/llvm-ranlib" \
    -DCMAKE_FIND_ROOT_PATH="$SYSROOT" -DCMAKE_FIND_ROOT_PATH_MODE_PROGRAM=NEVER \
    -DCMAKE_BUILD_TYPE=Release \
    -DENABLE_SHARED=OFF -DENABLE_CLI=OFF -DENABLE_PIC=ON -DENABLE_LIBNUMA=OFF \
    -DCMAKE_INSTALL_PREFIX="$PREFIX"
  ninja -j"$JOBS"
  ninja install
  # bionic has no separate pthread / rt libraries, and libc++ is linked statically
  sed -i -e 's/-lpthread//g' -e 's/-lrt//g' -e 's/-lc++_shared/-lc++_static -lc++abi/g' \
         -e 's/-lc++\b/-lc++_static -lc++abi/g' "$PREFIX/lib/pkgconfig/x265.pc"
  grep -q "c++_static" "$PREFIX/lib/pkgconfig/x265.pc" || \
    sed -i 's/^Libs.private:.*/Libs.private: -lc++_static -lc++abi -lm -ldl/' "$PREFIX/lib/pkgconfig/x265.pc"
fi

echo "=== ffmpeg ==="
cd "$SRC/ffmpeg"
make distclean >/dev/null 2>&1 || true
./configure \
  --prefix="$PREFIX" --target-os=android --arch=aarch64 --cpu=armv8-a \
  --enable-cross-compile --cc="$CC" --cxx="$CXX" \
  --ar="$TC/bin/llvm-ar" --nm="$TC/bin/llvm-nm" --ranlib="$TC/bin/llvm-ranlib" --strip="$TC/bin/llvm-strip" \
  --sysroot="$SYSROOT" --pkg-config=pkg-config --pkg-config-flags=--static \
  --enable-gpl --enable-libx264 --enable-libx265 \
  --enable-static --disable-shared --enable-pic \
  --disable-doc --disable-ffplay --disable-ffprobe --disable-debug \
  --disable-network --disable-devices --disable-vulkan \
  --disable-mediacodec --disable-jni --disable-hwaccels \
  --disable-encoders --enable-encoder=libx264,libx265,aac,gif,png,mjpeg,pcm_s16le \
  --disable-muxers --enable-muxer=mp4,mov,ipod,gif,null,image2,wav \
  --disable-protocols --enable-protocol=file,pipe,fd \
  --extra-cflags="-I$PREFIX/include -O3" \
  --extra-ldflags="-L$PREFIX/lib -Wl,-z,max-page-size=16384" \
  --extra-libs="-lm"
make -j"$JOBS"
"$TC/bin/llvm-strip" -o "$OUT/libffmpeg.so" ffmpeg
ls -la "$OUT/libffmpeg.so"
echo "=== done ==="

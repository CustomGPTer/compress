#!/usr/bin/env python3
"""Builds the Compress website (plain HTML and CSS, no scripts) into the folder given as argv[1]."""
import json
import sys
from pathlib import Path

OUT = Path(sys.argv[1])
BASE = "https://customgpter.github.io/compress/"
REPO = "https://github.com/CustomGPTer/compress"
APK = REPO + "/releases/latest/download/Compress.apk"
ISSUES = REPO + "/issues"
VERSION = "1.1"
DATE_LONG = "16 November 2026"
DATE_ISO = "2026-11-16"
APK_BYTES = "15,199,962"
APK_MB = "15.2 MB"
APK_SHA = "952ee0f6aa535e5743486784ca80a610f0aa8fac41bc8bb3e241a2f4d0ae4425"
OG_ALT = "A one-minute video shrinking from 128 MB to 39 MB with its picture size, date and sound kept, beside the Compress name"

ICON = ('<rect width="108" height="108" rx="24" fill="#12181e"/>'
        '<g transform="translate(54 54) scale(1.3) translate(-54 -54)">'
        '<path fill="none" stroke="#e9eef3" stroke-width="4.5" stroke-linejoin="round" d="M41 43h26a5 5 0 0 1 5 5v12a5 5 0 0 1-5 5H41a5 5 0 0 1-5-5V48a5 5 0 0 1 5-5z"/>'
        '<path fill="#e9eef3" d="M50.5 48.2l9.2 5.3a.6.6 0 0 1 0 1l-9.2 5.3a.6.6 0 0 1-.9-.5V48.7a.6.6 0 0 1 .9-.5z"/>'
        '<path fill="none" stroke="#3ddc97" stroke-width="5" stroke-linecap="round" stroke-linejoin="round" d="M54 24v12M47.5 30.5 54 37l6.5-6.5M54 84V72M47.5 77.5 54 71l6.5 6.5"/>'
        '</g>')
ICON_SVG = f'<svg viewBox="0 0 108 108" aria-hidden="true">{ICON}</svg>'

GRID = ('<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="6.5" height="6.5" rx="1.6"/>'
        '<rect x="13.5" y="4" width="6.5" height="6.5" rx="1.6"/><rect x="4" y="13.5" width="6.5" height="6.5" rx="1.6"/>'
        '<rect x="13.5" y="13.5" width="6.5" height="6.5" rx="1.6"/></svg>')


def head(title, desc, path, extra=""):
    url = BASE + path
    robots = '<meta name="robots" content="noindex">\n' if path == "404.html" else ""
    canonical = "" if path == "404.html" else f'<link rel="canonical" href="{url}">\n'
    return f'''<!DOCTYPE html>
<html lang="en-GB">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<meta name="description" content="{desc}">
<meta name="author" content="Jonathan Jackson">
{robots}{canonical}<meta name="theme-color" content="#f2f7f4" media="(prefers-color-scheme: light)">
<meta name="theme-color" content="#0a120e" media="(prefers-color-scheme: dark)">
<meta property="og:type" content="website">
<meta property="og:site_name" content="Compress">
<meta property="og:title" content="{title}">
<meta property="og:description" content="{desc}">
<meta property="og:url" content="{url}">
<meta property="og:image" content="{BASE}assets/og.png">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta property="og:image:alt" content="{OG_ALT}">
<meta property="og:locale" content="en_GB">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="assets/favicon.svg" type="image/svg+xml">
<link rel="apple-touch-icon" href="assets/apple-touch-icon.png">
<link rel="preload" href="assets/fonts/literata-latin-700-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="assets/fonts/literata-latin-400-normal.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="assets/site.css?v=1">
{extra}</head>
<body>
<a class="skip" href="#main">Skip to content</a>
'''


def masthead(current=""):
    def a(href, label, cls=""):
        cur = ' aria-current="page"' if href == current else ""
        c = f' class="{cls}"' if cls else ""
        inner = (GRID + label) if cls else label
        return f'<li><a{c} href="{href}"{cur}>{inner}</a></li>'
    return ('<header class="masthead">\n<div class="wrap">\n'
            f'<a class="brand" href="./" aria-label="Compress home">{ICON_SVG}<span>Compress</span></a>\n'
            '<nav aria-label="Main"><ul>'
            + a("./#features", "Features") + a("compare.html", "Compare") + a("releases.html", "Releases")
            + a("more-apps.html", "More apps", "more-apps") + a("privacy.html", "Privacy") + a("terms.html", "Terms")
            + a("licences.html", "Licences")
            + '</ul></nav>\n</div>\n</header>\n')


FOOT = f'''<footer class="colophon">
<div class="wrap">
<div>
<p>&copy; 2026 Jonathan Jackson. Compress is an independent app.</p>
<p>This site uses no cookies and no tracking. It is set in Literata and Atkinson Hyperlegible.</p>
</div>
<nav aria-label="Footer"><ul>
<li><a href="./">Home</a></li>
<li><a href="compare.html">Compare</a></li>
<li><a href="releases.html">Release notes</a></li>
<li><a href="more-apps.html">More apps</a></li>
<li><a href="privacy.html">Privacy policy</a></li>
<li><a href="terms.html">Terms of use</a></li>
<li><a href="licences.html">Licences</a></li>
<li><a href="{REPO}">Source code</a></li>
<li><a href="{ISSUES}">Contact</a></li>
</ul></nav>
</div>
</footer>
</body>
</html>
'''


def ld(obj):
    return '<script type="application/ld+json">' + json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "</script>\n"


def crumbs(name, path):
    return ld({"@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": [
        {"@type": "ListItem", "position": 1, "name": "Compress", "item": BASE},
        {"@type": "ListItem", "position": 2, "name": name, "item": BASE + path}]})


def page(path, title, desc, body, current="", extra=""):
    (OUT / path).write_text(head(title, desc, path, extra) + masthead(current) + body + FOOT, encoding="utf-8")


DL = f'<a class="button" href="{APK}">Download for Android</a>'
CHROME = "Chrome may say the file might be harmful. It shows this for app files that do not come from Google Play. Choose Download anyway."

# ------------------------------------------------------------------ home

FEATURES = [
    ("Four quality levels", "Visually identical, High, Balanced and Small. Each one shows the size to expect for your own video before you choose it."),
    ("Fit a size", "WhatsApp 16 MB, Discord 10 MB, Gmail 25 MB, or a size of your own. If the first attempt lands over, it is redone a little smaller. The picture is only made smaller when there is no other way to keep it sharp."),
    ("The full picture", "A video keeps its original resolution unless you pick a smaller one, from 2160p down to 240p or a figure of your own. The frame rate can be lowered too, which saves a lot by itself."),
    ("Three formats", "HEVC by default, which can need about half the space of H.264 for the same picture. H.264 for anything that has to play everywhere. AV1 on phones whose video chip can write it."),
    ("Two engines", "Fast uses the phone's own video chip, and is the right choice nearly every time. Max quality uses the x264 and x265 encoders for the smallest file at a given quality, and takes many times longer."),
    ("Screen off, app closed", "Compressing carries on in the background with a progress notification, and picks up again after a restart. It pauses if the phone gets hot, and waits for the charger when the battery is under 15%."),
    ("Skips what will not shrink", "A video that is already small for its quality is left alone, and a result that comes out no smaller is thrown away. A switch turns this off for the times you are compressing for another reason."),
    ("Trim, crop and turn", "Cut the ends off, crop the edges with a box you drag to fit, rotate, mirror, speed up or slow down, and set the volume anywhere from silent to three times louder."),
    ("Join, GIF and audio", "Join up to three clips into one video, turn a clip into a GIF, or save the sound on its own."),
    ("Dates, places and HDR", "The copy keeps the original's date and details, so it sorts beside it in your gallery. One switch removes where it was filmed. HDR is kept, or converted for older screens."),
    ("Compare", "Put the original and the copy one over the other at any moment in the video, drag the divider across, and pinch to zoom right in."),
    ("Originals and automation", "Originals are kept unless you turn on Replace originals, which uses Android's 30-day bin. Overnight mode waits for the charger, and automatic mode compresses new camera videos while the phone charges. All three are off to begin with."),
]

FAQ = [
    ("Is Compress really free?",
     "Yes. There is no paid version, no subscription and no adverts, and nothing in the app is locked.",
     ' <a href="compare.html">See the comparison</a>.'),
    ("Is Compress on Google Play?",
     "No. Compress is a personal project and is downloaded from this site as an Android app file. It needs Android 10 or later on a 64-bit phone, which covers almost every phone sold in recent years.", ""),
    ("Are my videos uploaded anywhere?",
     "No. Compress reads and writes videos on your phone, and it has no servers. It uses the internet for one thing only: to check for a newer version of itself.",
     ' The detail is in the <a href="privacy.html#services">privacy policy</a>.'),
    ("Will I see a difference?",
     "On Visually identical and High you should not, at normal viewing. Compressing always discards something, and the lower settings trade more of it for a smaller file, so each setting says plainly what to expect. Use Compare to check a result for yourself before you delete anything.", ""),
    ("How much smaller will a video be?",
     "It depends on the video and the setting. On High, Compress aims a one-minute 1080p video at about 39 MB, where a phone usually records that minute at 100 MB or more. A video that is already tightly packed, such as one downloaded from a website, may not shrink at all. Compress says so and skips it.", ""),
    ("Will my original be changed?",
     "No. Compress saves a new copy, in Movies/Compress unless you choose another folder, and leaves the original alone. If you turn on Replace originals, you are asked after each batch to move the originals to Android's bin, where they stay for 30 days.", ""),
    ("Does it really work with the screen off?",
     "Yes. Compress runs as a background task with a notification that shows progress, so you can turn the screen off or use another app. Recent versions of Android limit how long an app may do this in a day, to about six hours. If that limit is reached, Compress stops tidily and carries on when you next open it.", ""),
    ("What is the difference between Fast and Max quality?",
     "Fast hands the work to the phone's video chip, which is quick and stays cool. Max quality does the work in software with the x264 and x265 encoders. It can squeeze a file smaller for the same picture, but it takes many times longer and warms the phone, so it is best left running on charge.", ""),
    ("Will the copy play on other devices?",
     "A copy in HEVC plays on most phones, tablets, televisions and computers made since about 2017. If it has to play on something older, choose H.264 instead. AV1 files are the smallest and need a recent device or browser.", ""),
    ("How do I update Compress?",
     "Compress tells you when it opens if a newer version is out. Download it from this site and install it over the one you have. Your settings and your queue are kept.", ""),
]

DEMO = ('<div class="demo" role="img" aria-label="An example in Compress. A one-minute video called Holiday.mp4 at 1920 by 1080. '
        'Two bars show its size: the original at 128 MB, and the compressed copy shrinking to 39 MB. Below, the picture size, date and sound are each marked Kept, '
        'and the size is marked 70% smaller. The buttons underneath read Share, Compare and Done.">'
        '<div class="view"><div class="bar"><span class="dot"></span><span>Holiday.mp4</span><span class="next">Compress</span></div>'
        '<div class="stage"><svg class="play" viewBox="0 0 48 48" aria-hidden="true"><circle cx="24" cy="24" r="23" fill="rgba(8,14,11,.6)"/><path fill="#fff" d="M19.5 15.5 33.5 24l-14 8.5z"/></svg>'
        '<span class="meta">1920 &times; 1080 &middot; 1:00</span></div></div>'
        '<div class="sheet">'
        '<div class="meter"><div class="m was"><span class="lab">Original</span><span class="track"><span class="fill"></span></span><span class="num">128 MB</span></div>'
        '<div class="m now"><span class="lab">Compressed</span><span class="track"><span class="fill"></span></span><span class="num">39 MB</span></div></div>'
        '<ul class="rows">'
        '<li class="row keep" style="--i:0;--j:0"><span class="k">Picture</span><span class="v">1920 &times; 1080</span><span class="t">Kept</span></li>'
        '<li class="row keep" style="--i:1;--j:1"><span class="k">Date</span><span class="v">14 June 2026, 18:42</span><span class="t">Kept</span></li>'
        '<li class="row keep" style="--i:2;--j:2"><span class="k">Sound</span><span class="v">Untouched</span><span class="t">Kept</span></li>'
        '<li class="row go" style="--i:3;--j:3"><span class="k">Size</span><span class="v">128 MB</span><span class="t">70% smaller</span></li>'
        '</ul><div class="acts"><span>Share</span><span>Compare</span><span class="do">Done</span></div></div></div>')


def home():
    title = "Compress: a free video compressor for Android"
    desc = ("Compress makes the videos on your Android phone smaller without a difference you can see, and keeps going with the screen off. "
            "Free, no adverts, nothing uploaded.")
    app = {"@context": "https://schema.org", "@type": "SoftwareApplication", "name": "Compress", "url": BASE,
           "description": "Compress is an Android app that makes videos smaller without a difference you can see, at the full picture size, "
                          "and carries on with the screen off. The work is done on the phone.",
           "applicationCategory": "MultimediaApplication", "applicationSubCategory": "Video compressor",
           "operatingSystem": "Android 10 or later", "softwareVersion": VERSION, "downloadUrl": APK,
           "releaseNotes": BASE + "releases.html", "offers": {"@type": "Offer", "price": "0", "priceCurrency": "GBP"},
           "inLanguage": "en-GB", "image": BASE + "assets/og.png",
           "featureList": [f"{t}: {d}" if len(d) < 90 else t for t, d in FEATURES],
           "author": {"@type": "Person", "name": "Jonathan Jackson"}}
    site = {"@context": "https://schema.org", "@type": "WebSite", "name": "Compress", "url": BASE, "inLanguage": "en-GB"}
    faq = {"@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [
        {"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a, _ in FAQ]}
    feats = "\n".join(f"<div><dt>{t}</dt><dd>{d}</dd></div>" for t, d in FEATURES)
    faqs = "".join(f"<div><h3>{q}</h3><p>{a}{more}</p></div>" for q, a, more in FAQ)
    body = f'''<main id="main">
<div class="hero">
<div class="wrap hero-grid">
<div class="hero-copy">
<h1>Smaller videos, the same picture</h1>
<p class="lede">Phone videos are far bigger than they need to be. Compress is an Android app that shrinks them without a difference you can see, at the full picture size unless you choose a smaller one. Start it, turn the screen off, and it tells you when it is done.</p>
<p class="lede">It is free, with no adverts and nothing to unlock. The work is done on your phone, so your videos are never uploaded, and your originals are kept unless you say otherwise.</p>
<p class="get">{DL}</p>
<p class="facts">Free, with nothing to unlock. Android 10 or later, 64-bit. No ads, no accounts, no uploads. <a href="compare.html">Compare</a> &middot; <a href="releases.html">Release notes</a></p>
<p class="facts">{CHROME}</p>
</div>
{DEMO}
</div>
</div>

<section id="how" aria-labelledby="how-h">
<div class="wrap">
<h2 id="how-h">How it works</h2>
<p class="intro">A phone has a fraction of a second to store each frame as it films, so it stores them loosely. Compress goes back over the same video with time to spare and packs it properly.</p>
<ol class="steps">
<li><h3>Pick your videos</h3><p>Tick up to three from your albums, or send them to Compress from your gallery with Share. The biggest are one tap away, with a total of the space you could free.</p></li>
<li><h3>Choose how small</h3><p>Pick a quality level, or a size to fit, such as <span class="path">WhatsApp 16 MB</span>. Compress shows the size it expects and how long it should take before you start.</p></li>
<li><h3>Leave it to it</h3><p>Tap <span class="path">Compress</span> and put the phone down. It works with the screen off, checks that the new file plays, and saves it. The original stays where it was.</p></li>
</ol>
</div>
</section>

<section id="features" aria-labelledby="features-h">
<div class="wrap">
<h2 id="features-h">Everything is in, and all of it is free</h2>
<p class="intro">Making one video smaller takes two taps. The rest of the app is for the days you need more: a clip that has to fit an email, a film that needs its ends cut off, or a camera roll that has filled the phone.</p>
<dl class="features">
{feats}
</dl>
</div>
</section>

<section id="permissions" aria-labelledby="permissions-h">
<div class="wrap">
<h2 id="permissions-h">What it asks of your phone</h2>
<p class="intro">Compress has no access to your contacts, camera, microphone or location, and uses what it does have only for what is listed here.</p>
<div class="scroll">
<table>
<thead><tr><th scope="col">Access</th><th scope="col">What Compress does with it</th><th scope="col">What it never does</th></tr></thead>
<tbody>
<tr><th scope="row">Your videos</th><td>Lists the videos on your phone, reads the ones you tick, and saves the smaller copies. It also reads the place stored inside a video, so that the copy can keep it.</td><td>Send a video, or anything else on your phone, anywhere.</td></tr>
<tr><th scope="row">Notifications</th><td>Shows progress while the screen is off, and tells you when a video is done.</td><td>Advertise, or nag you to open the app.</td></tr>
<tr><th scope="row">Internet access</th><td>Checks GitHub once a day for a newer version. Nothing else.</td><td>Upload a video, or pass on anything about one.</td></tr>
<tr><th scope="row">Background running</th><td>Lets overnight and automatic modes start by themselves once the phone is on charge. You are asked only if you turn one of them on.</td><td>Run when there is nothing waiting to be compressed.</td></tr>
</tbody>
</table>
</div>
<p class="after-table">The detail is in the <a href="privacy.html">privacy policy</a>.</p>
</div>
</section>

<section id="privacy" aria-labelledby="privacy-h">
<div class="wrap">
<h2 id="privacy-h">Your videos are your business</h2>
<ul class="plain">
<li><h3>Nothing is uploaded</h3><p>Compress reads and writes videos on the phone. A film of your home, your children or your work goes no further than your own hand.</p></li>
<li><h3>No accounts, no adverts</h3><p>There is nothing to sign up for and no advertising in the app. This site has no cookies and no tracking.</p></li>
<li><h3>No servers</h3><p>Compress's developer runs no servers and collects nothing. There is no log of who uses the app or what they do with it.</p></li>
</ul>
</div>
</section>

<section id="free" aria-labelledby="free-h">
<div class="wrap">
<h2 id="free-h">Free, including what others charge for</h2>
<p class="intro">Compress has no paid version and carries no adverts. Going by their makers' own Google Play listings, other well-known video compressors show adverts, and one keeps some of what it does for a paid version.</p>
<dl class="features">
<div><dt>No adverts</dt><dd>Proton Video Compressor by H. Arthur and Panda Video Compress &amp; Convert by Farluner Apps &amp; Games each say on their Google Play listings that they contain ads.</dd></div>
<div><dt>Nothing held back</dt><dd>Panda's listing puts more than three videos at once, no ads and no promotional text on shared videos among the things its Premium adds.</dd></div>
<div><dt>The tools are built in</dt><dd>Trim, crop, rotate, speed, join, GIF and audio-only are all part of Compress. There is nothing further to buy.</dd></div>
<div><dt>Done on the phone</dt><dd>Compress needs no internet to compress a video, and nothing is sent anywhere.</dd></div>
</dl>
<p class="more"><a href="compare.html">See the full comparison, with sources</a></p>
</div>
</section>

<section id="questions" aria-labelledby="questions-h">
<div class="wrap">
<h2 id="questions-h">Questions</h2>
<div class="faq">
{faqs}
</div>
</div>
</section>

<section id="get" aria-labelledby="get-h">
<div class="wrap"><div class="measure">
<h2 id="get-h">Getting Compress</h2>
<p>Compress is a personal project and is free, with no paid version. It is downloaded from this site as an Android app file and is not on Google Play. It runs on 64-bit phones and tablets with Android 10 or later.</p>
<p class="get">{DL}</p>
<p>When you download, Chrome may warn that the file might be harmful. It shows this warning for app files that do not come from Google Play; choose Download anyway. If you want to be sure the file is the real one, compare it with the checksum in the <a href="releases.html#checking">release notes</a>.</p>
<p>Open the downloaded file to install it. The first time, Android asks you to allow your browser to install apps. Google Play Protect may also step in, because Compress is an app it has not seen before: choose More details, then Install anyway. To update, install the latest version over the one you have: your settings and your queue are kept. What changed in each version is in the <a href="releases.html">release notes</a>.</p>
<p>Compress is free software, and its <a href="{REPO}">source code</a> is public. The same developer makes <a href="more-apps.html">other free Android apps</a>. For a question, a problem, or anything about your data, <a href="{ISSUES}">open an issue on GitHub</a>.</p>
</div></div>
</section>
</main>
'''
    (OUT / "index.html").write_text(head(title, desc, "", ld(app) + ld(site) + ld(faq)) + masthead() + body + FOOT, encoding="utf-8")


# ------------------------------------------------------------------ compare

def cell(app, cls, value, small=""):
    s = f"<small>{small}</small>" if small else ""
    if cls == "na":
        return f'<td class="na"><span class="app">{app}</span><span class="v"><span aria-label="Not mentioned in its listing">&ndash;</span></span></td>'
    return f'<td class="{cls}"><span class="app">{app}</span><span class="v">{value}{s}</span></td>'


def compare():
    P, N = "Proton Video Compressor", "Panda Video Compress"
    rows = [
        ("No adverts", ("yes", "Free", ""), ("pay", "Has adverts", ""), ("pay", "Has adverts", "Premium removes them")),
        ("Fitting a size, such as for WhatsApp or email", ("yes", "Free", ""), ("yes", "Free", ""), ("yes", "Free", "")),
        ("Choosing the picture size", ("yes", "Free", ""), ("yes", "Free", ""), ("yes", "Free", "")),
        ("Saving in HEVC (H.265)", ("yes", "Free", ""), ("na", "", ""), ("yes", "Free", "")),
        ("Trimming", ("yes", "Free", ""), ("na", "", ""), ("yes", "Free", "")),
        ("Cropping, rotating and changing speed", ("yes", "Free", ""), ("na", "", ""), ("na", "", "")),
        ("Removing or boosting the sound", ("yes", "Free", ""), ("yes", "Free", ""), ("na", "", "")),
        ("Comparing before and after", ("yes", "Free", ""), ("yes", "Free", ""), ("na", "", "")),
        ("Several videos in one go", ("yes", "Free", "Three per go"), ("na", "", ""), ("yes", "Free", "Up to three at once. More is paid")),
        ("Sharing with nothing added", ("yes", "Free", ""), ("na", "", ""), ("pay", "Paid", "Premium removes promotional text")),
    ]
    trs = ""
    for name, ours, proton, panda in rows:
        o = cell("Compress", ours[0] + " ours", ours[1], ours[2])
        trs += f'<tr><th scope="row">{name}</th>{o}{cell(P, *proton)}{cell(N, *panda)}</tr>\n'
    title = "Compress compared with other Android video compressors"
    desc = "What is free in Compress and what other Android video compressors show adverts for or keep for a paid version, checked against their own Google Play listings."
    body = f'''<main id="main" class="doc">
<div class="wrap">
<div class="measure">
<h1>Free in Compress, with adverts or a price elsewhere</h1>
<p class="lede">Compress has no paid version, no subscription and no adverts. Other well-known video compressors pay their way with adverts, and some keep part of what they do for a paid version.</p>
<div class="get">
{DL}
<p class="facts">Free. Android 10 or later, 64-bit. <a href="./#features">What it does</a></p>
</div>
<h2 id="paid">Video compressors on Google Play</h2>
<p>Proton Video Compressor by H. Arthur and Panda Video Compress &amp; Convert by Farluner Apps &amp; Games are each free to install from Google Play. For each feature, the table shows whether it comes with the free app, only with a paid version, or is not mentioned by the app's maker.</p>
</div>
<div class="scroll">
<table class="cmp">
<thead><tr><th scope="col">Feature</th><th scope="col" class="ours">Compress<small>No paid version</small></th><th scope="col">Proton Video Compressor<small>By H. Arthur. Listed on Google Play as Video Compressor - Reduce Size</small></th><th scope="col">Panda Video Compress &amp; Convert<small>By Farluner Apps &amp; Games. Has a paid Premium</small></th></tr></thead>
<tbody>
{trs}</tbody>
</table>
</div>
<div class="measure">
<p class="key"><strong class="yes">Free</strong> In the free app. <strong class="pay">Paid</strong> Listed by the maker among the things its paid version adds. <strong class="pay">Has adverts</strong> The app's Google Play listing says it contains ads. <strong>&ndash;</strong> Not mentioned in the listing; the app may or may not have it.</p>
<p class="key">Checked on {DATE_LONG} against each maker's own Google Play listing: <a href="https://play.google.com/store/apps/details?id=com.arthur.hritik.proton.video.compressor">Proton Video Compressor</a> and <a href="https://play.google.com/store/apps/details?id=com.pandavideocompressor">Panda Video Compress &amp; Convert</a>. Product names belong to their owners.</p>

<h2 id="types">Which videos it works on</h2>
<p>Compress opens the kinds of video a phone can play, including MP4, MOV, MKV, WebM and 3GP, and always saves an MP4. Proton's listing names MP4, MKV, AVI, MOV, WebM, TS, 3GP, M4V, WMV and MPEG. Panda's listing says it converts between MP4, AVI, MKV, FLV, RMVB, 3GP, MPEG, WebM, WMV and MOV.</p>

<h2 id="phone">Where the work is done</h2>
<p>Compress reads and writes your videos on your phone, with or without an internet connection, and no video is ever sent anywhere. Both other apps' listings also say the work is done on the phone. If it matters to you, check each app's privacy policy to see what else it collects before you give it a video.</p>

<h2 id="honest">What Compress does not do</h2>
<ul>
<li>It takes three videos per go and does them one after another. There is no unlimited batch.</li>
<li>It always saves an MP4. It is not a converter to MKV, WebM, AVI or other kinds of file.</li>
<li>It does not show a short sample before it starts. You compare afterwards, with the original still in place.</li>
<li>Compressing always discards something. The top two settings are chosen so that you should not see it, but no setting gives back exactly what went in.</li>
<li>Max quality is slow and warms the phone, and it does not keep HDR: an HDR video is compressed with the Fast engine instead.</li>
<li>AV1 is offered only on phones whose video chip can write it.</li>
<li>It needs a 64-bit phone or tablet with Android 10 or later. There is no version for iPhone or for computers.</li>
</ul>

<h2 id="wrong">If something here is out of date</h2>
<p>Apps change. If a row is no longer right, <a href="{ISSUES}">open an issue on GitHub</a> and it will be corrected.</p>
</div>
</div>
</main>
'''
    page("compare.html", title, desc, body, "compare.html", crumbs("Compare", "compare.html"))


# ------------------------------------------------------------------ releases

ADDED = [
    "Four quality levels, each showing the size to expect before you choose: Visually identical, High, Balanced and Small.",
    "Size targets for WhatsApp (16 MB), Discord (10 MB) and Gmail (25 MB), or a size of your own, with a second attempt if the first lands over.",
    "Original resolution kept by default, with 2160p down to 240p or a custom figure, and a lower frame rate if you want one.",
    "HEVC, H.264 and, where the phone's video chip can write it, AV1.",
    "Two engines: Fast, on the phone's video chip, and Max quality, using the x264 and x265 encoders.",
    "Compressing with the screen off or the app closed, with a progress notification and a finished notification that offers Share and Compare.",
    "Up to three videos per go, one after another, with the size and time predicted before you start.",
    "Videos that are already small, or that would come out no smaller, are skipped.",
    "Trim, crop, rotate, mirror, speed, and volume from silent to three times louder.",
    "Join up to three clips, make a GIF, or save the sound on its own.",
    "Date and details kept on the copy, a switch to remove the location, and HDR kept or converted.",
    "A compare screen with a divider to drag and pinch to zoom.",
    "A home screen with all videos and albums, filters, sorting, and a total of the space that could be freed.",
    "Copies saved to Movies/Compress by default, with other folders in Settings.",
    "Replace originals, off by default, which uses Android's 30-day bin after each copy has been checked.",
    "Overnight mode and automatic mode, both off by default.",
    "Pausing when the phone is hot, and waiting for the charger under 15% battery.",
    "An optional space-saved tally, off by default, with a Clear button.",
    "Picking up the queue again after a restart.",
    "A notice when a newer version is out.",
]


def releases():
    added = "".join(f"<li>{a}</li>" for a in ADDED)
    body = f'''<main id="main" class="doc">
<div class="wrap">
<div class="measure">
<h1>Release notes</h1>
<p class="lede">What was added, improved and fixed in each version of Compress, newest first. The current version is {VERSION}.</p>
<div class="get">
<a class="button" href="{APK}">Download the latest version</a>
<p class="facts">Version {VERSION}. Android app file, {APK_MB}. Android 10 or later, 64-bit. Free.</p>
<p class="facts">{CHROME} To be sure of the file, see <a href="#checking">Checking your download</a>.</p>
</div>
<nav class="contents" aria-label="Versions"><strong>Versions</strong><ul><li><a href="#v1-1">1.1&ensp;First release</a></li></ul></nav>

<article class="release" id="v1-1">
<p class="ver">Version {VERSION}</p>
<h2>First release</h2>
<p class="when"><span class="tag">Latest</span>Released {DATE_LONG}</p>
<h3>Added</h3>
<ul>{added}</ul>
</article>

<h2 id="installing">Installing and updating</h2>
<ul>
<li>When you download, Chrome may warn that the file might be harmful. It shows this warning for app files that do not come from Google Play. Choose Download anyway.</li>
<li>Open the downloaded file. The first time, Android asks you to allow your browser or file manager to install apps. Allow it, then tap Install.</li>
<li>Google Play Protect may say it does not recognise the app, or block it, because Compress does not come from Google Play. Choose More details, then Install anyway.</li>
<li>The first time you open Compress, allow it to see your videos, and allow notifications so that it can show progress while the screen is off.</li>
<li>To update, download the latest version and install it over the one you have. Your settings and your queue are kept.</li>
<li>Every version is signed with the same key, so Android accepts an update only if it comes from the same developer.</li>
</ul>
<h2 id="checking">Checking your download</h2>
<p>The file for version {VERSION} is {APK_BYTES} bytes. Its SHA-256 checksum is:</p>
<p class="sum"><code>{APK_SHA}</code></p>
<p>Earlier downloads and their files are listed on <a href="{REPO}/releases">GitHub Releases</a>. To report a problem with a version, <a href="{ISSUES}">open an issue on GitHub</a>.</p>
<h2 id="source">Source code</h2>
<p>Compress is free software under the GNU General Public License, version 3 or later. The app's source code is in the <a href="{REPO}/tree/main/android">android folder of its GitHub repository</a>. The source for the FFmpeg, x264 and x265 encoder inside it is attached to each release as <code>compress-encoder-sources.zip</code>. The <a href="licences.html">licences page</a> has the detail.</p>
</div>
</div>
</main>
'''
    page("releases.html", "Release notes | Compress",
         "What was added, improved and fixed in each version of the Compress video compressor for Android, with the download, its size and its checksum.",
         body, "releases.html", crumbs("Release notes", "releases.html"))


# ------------------------------------------------------------------ more apps

SIBS = [
    ("Shelfmark", "#1e4d3a", "#12301f",
     '<svg viewBox="0 0 108 108"><rect x="33" y="20" width="42" height="68" rx="5" fill="#fff"/><rect x="47" y="32" width="21" height="4" fill="#1e4d3a"/><rect x="47" y="42" width="14" height="4" fill="#1e4d3a"/></svg>',
     '<svg class="mapp-icon" viewBox="0 0 108 108" aria-hidden="true"><rect width="108" height="108" rx="24" fill="#1e4d3a"/><rect x="33" y="20" width="42" height="68" rx="5" fill="#fffdf5"/><rect x="33" y="20" width="8" height="68" rx="4" fill="#d9bd76"/><rect x="47" y="32" width="21" height="4" fill="#1e4d3a"/><rect x="47" y="42" width="14" height="4" fill="#1e4d3a"/></svg>',
     "An ebook reader that sorts your library",
     "Shelfmark files your books under bookshop headings, so a library of thousands is as easy to browse as a shop. It keeps your place across devices and reads aloud.",
     "shelfmark", "Shelfmark.apk", "Free, with no adverts. Android 10 or later."),
    ("Grab", "#0f766e", "#0a4a45",
     '<svg viewBox="0 0 108 108"><path d="M54 26v32M42 46l12 12 12-12M32 64v12q0 4 4 4h36q4 0 4-4V64" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
     '<svg class="mapp-icon" viewBox="0 0 108 108" aria-hidden="true"><rect width="108" height="108" rx="24" fill="#0f766e"/><path d="M54 26v32M42 46l12 12 12-12M32 64v12q0 4 4 4h36q4 0 4-4V64" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
     "A video downloader without the adverts",
     "Grab has its own ad-blocking browser. Open a page with a video on it, tap the round Download button, choose a size, and the file is saved to your phone.",
     "grab", "Grab.apk", "Free, with no adverts. Android 10 or later, 64-bit."),
    ("PDF+", "#1f5fa8", "#123c6e",
     '<svg viewBox="0 0 108 108"><path fill="#fff" d="M37 28h24l14 14v36a4 4 0 0 1-4 4H37a4 4 0 0 1-4-4V32a4 4 0 0 1 4-4z"/><path fill="#1f5fa8" d="M51 50h6v9h9v6h-9v9h-6v-9h-9v-6h9z"/></svg>',
     '<svg class="mapp-icon" viewBox="0 0 108 108" aria-hidden="true"><rect width="108" height="108" rx="24" fill="#1f5fa8"/><path fill="#fff" d="M37 28h24l14 14v36a4 4 0 0 1-4 4H37a4 4 0 0 1-4-4V32a4 4 0 0 1 4-4z"/><path fill="#c9dbf2" d="M61 28l14 14H65a4 4 0 0 1-4-4z"/><path fill="#1f5fa8" d="M51 50h6v9h9v6h-9v9h-6v-9h-9v-6h9z"/></svg>',
     "A PDF reader, editor and scanner",
     "Read, annotate, fill and sign, edit, scan, convert, compress and redact. PDF+ brings the tools other PDF apps charge for into one free app.",
     "pdfplus", "PDFPlus.apk", "Free, with no adverts. Android 11 or later."),
    ("Clearcut", "#5b50f0", "#2a2378",
     '<svg viewBox="0 0 108 108"><circle cx="54" cy="41" r="10.5" fill="#fff"/><path d="M34 78c0-14.5 8.5-23 20-23s20 8.5 20 23z" fill="#fff"/><path d="M27 41V27h14M67 27h14v14M27 67v14h14M67 81h14V67" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
     '<svg class="mapp-icon" viewBox="0 0 108 108" aria-hidden="true"><defs><linearGradient id="mapp-cc" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#5b50f0"/><stop offset="1" stop-color="#2a2378"/></linearGradient></defs><rect width="108" height="108" rx="24" fill="url(#mapp-cc)"/><circle cx="54" cy="41" r="10.5" fill="#fff"/><path d="M34 78c0-14.5 8.5-23 20-23s20 8.5 20 23z" fill="#fff"/><path d="M27 41V27h14M67 27h14v14M27 67v14h14M67 81h14V67" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>',
     "A background remover that works on your phone",
     "One tap cuts the subject out of a photo, and hand tools tidy the rest. Save it see-through, put something new behind it, or make it a WhatsApp sticker. Your photos are never uploaded.",
     "clearcut", "Clearcut.apk", "Free, with no adverts. Android 10 or later, 64-bit."),
    ("Vigil", "#1b2e4b", "#09111e",
     '<svg viewBox="0 0 64 64"><circle cx="32" cy="32" r="17" fill="none" stroke="#fff" stroke-width="4"/><circle cx="32" cy="32" r="8.5" fill="#fff"/></svg>',
     '<svg class="mapp-icon" viewBox="0 0 64 64" aria-hidden="true"><rect width="64" height="64" rx="14" fill="#0f1317"/><circle cx="32" cy="32" r="17" fill="none" stroke="#f2f5f7" stroke-width="4"/><circle cx="32" cy="32" r="8.5" fill="#4fd1a5"/><circle cx="35.4" cy="28.6" r="2.5" fill="#0f1317"/></svg>',
     "A spare phone as a security camera",
     "Vigil turns a phone you no longer use into a camera for your home, your pets or your site cabin. It spots people, vehicles and sounds, and saves clips to your own Google Drive.",
     "vigil", "Vigil.apk", "Free, with no adverts. Android 10 or later."),
    ("Retag", "#1565c0", "#0d3f7a",
     '<svg viewBox="0 0 108 108"><g transform="translate(54 54) scale(1.22) rotate(-32) translate(-54 -54)"><path fill="#fff" d="M36 38h30a6 6 0 0 1 4.2 1.8l11 11a4.5 4.5 0 0 1 0 6.4l-11 11a6 6 0 0 1-4.2 1.8H36a6 6 0 0 1-6-6V44a6 6 0 0 1 6-6z"/></g></svg>',
     '<svg class="mapp-icon" viewBox="0 0 108 108" aria-hidden="true"><rect width="108" height="108" rx="24" fill="#1565c0"/><g transform="translate(54 54) scale(1.22) rotate(-32) translate(-54 -54)"><path fill="#fff" d="M36 38h30a6 6 0 0 1 4.2 1.8l11 11a4.5 4.5 0 0 1 0 6.4l-11 11a6 6 0 0 1-4.2 1.8H36a6 6 0 0 1-6-6V44a6 6 0 0 1 6-6z"/><circle cx="70" cy="54" r="3.6" fill="#1565c0"/><path fill="#1565c0" d="M37 47.5h22a1.75 1.75 0 0 1 0 3.5H37a1.75 1.75 0 0 1 0-3.5zM37 57h15a1.75 1.75 0 0 1 0 3.5H37a1.75 1.75 0 0 1 0-3.5z"/></g></svg>',
     "A photo metadata editor and remover",
     "Retag shows the details hidden inside a photo, such as where and when it was taken and on which phone, and lets you change them or take them out before you share.",
     "retag", "Retag.apk", "Free, with no adverts. Android 11 or later."),
]


def more_apps():
    cards = ""
    for name, b, b2, cover, icon, kind, say, slug, apk, needs in SIBS:
        cards += (f'<li class="mapp" style="--b:{b};--b2:{b2}"><div class="mapp-cover" aria-hidden="true">{cover}</div>'
                  f'<div class="mapp-body">{icon}<h2>{name}</h2><p class="mapp-kind">{kind}</p><p class="mapp-say">{say}</p>'
                  f'<p class="mapp-go"><a class="button" href="https://github.com/CustomGPTer/{slug}/releases/latest/download/{apk}">Download {name}</a>'
                  f'<a class="mapp-site" href="https://customgpter.github.io/{slug}/">{name} website</a></p>'
                  f'<p class="mapp-needs">{needs}</p></div></li>\n')
    items = ld({"@context": "https://schema.org", "@type": "ItemList", "name": "More apps from the maker of Compress",
                "url": BASE + "more-apps.html", "itemListElement": [
                    {"@type": "ListItem", "position": i + 1, "name": s[0], "url": f"https://customgpter.github.io/{s[7]}/"}
                    for i, s in enumerate(SIBS)]})
    body = f'''<main id="main" class="doc">
<div class="wrap">
<div class="measure">
<h1>More apps</h1>
<p class="lede">Compress has siblings. Each is an Android app made by the same developer, free, with no adverts and nothing to unlock. Each button downloads the latest app file straight from that app's own page on GitHub.</p>
</div>
<ul class="mapps">
{cards}</ul>
<div class="measure">
<h2 id="installing">Installing one</h2>
<p>These apps install the same way Compress does. Chrome may say the file might be harmful. It shows this for app files that do not come from Google Play. Choose Download anyway. Open the downloaded file, allow your browser to install apps if Android asks, and if Google Play Protect steps in, choose More details, then Install anyway.</p>
<p>Each app has its own website with its release notes, privacy policy and terms, and its own place to report a problem.</p>
<p class="get"><a class="button" href="{APK}">Download Compress for Android</a></p>
<p class="facts">You can also reach this list from More apps, at the foot of Settings inside Compress.</p>
</div>
</div>
</main>
'''
    page("more-apps.html", "More apps | Compress",
         "Other free Android apps from the maker of Compress: Shelfmark, Grab, PDF+, Clearcut, Vigil and Retag. No adverts and nothing to unlock.",
         body, "more-apps.html", crumbs("More apps", "more-apps.html") + items)


# ------------------------------------------------------------------ privacy

def privacy():
    body = f'''<main id="main" class="doc">
<div class="wrap">
<div class="measure">
<h1>Privacy policy</h1>
<p class="lede">Last updated {DATE_LONG}. This policy covers the Compress app for Android (package <code>uk.jj.compress</code>) and this website. Compress is made by Jonathan Jackson, an individual developer in the United Kingdom.</p>
<nav class="contents" aria-label="On this page"><strong>On this page</strong><ul><li><a href="#short">The short version</a></li><li><a href="#device">What stays on your phone</a></li><li><a href="#access">What the app can reach</a></li><li><a href="#services">Services the app contacts</a></li><li><a href="#deleting">Keeping and deleting your data</a></li><li><a href="#rights">Your rights</a></li><li><a href="#security">Security</a></li><li><a href="#website">This website</a></li><li><a href="#children">Children</a></li><li><a href="#changes">Changes</a></li><li><a href="#contact">Contact</a></li></ul></nav>

<h2 id="short">The short version</h2>
<ul>
<li>Your videos are read and compressed on your phone. They are never uploaded, to the developer or to anyone else.</li>
<li>Compress has no accounts and no servers of its own. The developer receives nothing from your phone.</li>
<li>There is no advertising and no analytics in the app.</li>
<li>The one thing the app uses the internet for is to ask GitHub whether a newer version is out. The detail is <a href="#services">below</a>.</li>
</ul>

<h2 id="device">What stays on your phone</h2>
<p>Compress reads a video where it is kept and saves the smaller copy to the Movies/Compress folder, or to another folder you choose in Settings, where your gallery and other apps can see it. GIFs are saved to Pictures/Compress and sound files to Music/Compress. While a video is being compressed, the unfinished copy is held in the app's own working folder and removed afterwards.</p>
<p>The app keeps the following in its private storage: your settings; the queue of videos waiting or just finished; a note of which videos have already been compressed, so that they can be marked and filtered; a list of the originals it has moved to Android's bin at your request; and, only if you switch it on, a tally of the space saved with the names of the videos. A video leaves your phone only when you choose to send it somewhere yourself, with Share.</p>

<h2 id="access">What the app can reach</h2>
<div class="scroll">
<table>
<thead><tr><th scope="col">Access</th><th scope="col">Why</th><th scope="col">When</th></tr></thead>
<tbody>
<tr><th scope="row">The videos on your phone</th><td>To list your videos and albums, read the ones you choose and save the smaller copies. This includes the place stored inside a video, so that the copy can keep it</td><td>Once you allow it, which Android asks the first time you open Compress. You may allow only some videos. Compress looks only for videos</td></tr>
<tr><th scope="row">Notifications</th><td>To show progress while the screen is off and to tell you when a video is done</td><td>While compressing and when it finishes. Android asks you to allow this</td></tr>
<tr><th scope="row">Running in the background</th><td>To carry on compressing with the screen off, and to start overnight or automatic mode when the phone is put on charge</td><td>Only while there are videos to compress. Starting by itself needs a further permission that is asked for only if you turn one of those modes on</td></tr>
<tr><th scope="row">The internet</th><td>For the one service listed in the next section</td><td>As described there</td></tr>
</tbody>
</table>
</div>
<p class="after-table">Compress does not ask for your contacts, your camera, your microphone or your location.</p>

<h2 id="services">Services the app contacts</h2>
<div class="scroll">
<table>
<thead><tr><th scope="col">Service</th><th scope="col">What is sent</th><th scope="col">When</th></tr></thead>
<tbody>
<tr><th scope="row">GitHub</th><td>A request for the number of the latest version of Compress. Nothing about you or your videos</td><td>About once a day when you open the app, and when you tap Check now. A switch in Settings turns the daily check off</td></tr>
<tr><th scope="row">Another app on your phone</th><td>The videos you chose</td><td>Only when you tap Share</td></tr>
</tbody>
</table>
</div>
<p class="after-table">GitHub also receives your device's internet address, as any online service does, and the name of the app. It handles this under the <a href="https://docs.github.com/site-policy/privacy-policies/github-general-privacy-statement">GitHub Privacy Statement</a>. The developer of Compress receives none of it.</p>
<p>Compressing needs no internet connection at all. With the daily check switched off, the app contacts nothing.</p>

<h2 id="deleting">Keeping and deleting your data</h2>
<ul>
<li>Copies in Movies/Compress stay until you delete them from your gallery.</li>
<li>Originals that you asked Compress to replace are held in Android's bin for 30 days and then deleted by Android. Until then you can put them back, or delete them at once, under Settings, then Bin.</li>
<li>The space-saved tally is off unless you turn it on, and Clear wipes it.</li>
<li>Clearing the app's storage or uninstalling Compress deletes everything it holds. Videos you saved stay on your phone.</li>
<li>If your phone's own backup is switched on, Android may include Compress's settings in it. The queue, the tally and the other lists are left out. That backup is yours and is managed in your phone's settings.</li>
</ul>

<h2 id="rights">Your rights</h2>
<p>UK and EU data protection law gives you rights over personal data that an organisation holds about you, including the right to see it, correct it and have it deleted.</p>
<p>The developer of Compress holds no personal data about you: there is no account, no server and no log of who uses the app. Your videos are on your own phone, where you control them directly using the steps above. If you need help, use the contact link below. You also have the right to complain to the Information Commissioner's Office at <a href="https://ico.org.uk">ico.org.uk</a>.</p>

<h2 id="security">Security</h2>
<p>The app's own data is held in private storage that other apps cannot read. Videos you save are ordinary files in your phone's shared storage, as they were before.</p>
<p>The app's connection to GitHub uses HTTPS.</p>

<h2 id="website">This website</h2>
<p>This site sets no cookies, runs no analytics and loads nothing from other websites. It is hosted on GitHub Pages, and GitHub, as the host, receives the internet address of visitors and handles it under the <a href="https://docs.github.com/site-policy/privacy-policies/github-general-privacy-statement">GitHub Privacy Statement</a>. The app file is downloaded from GitHub as well, on the same terms.</p>

<h2 id="children">Children</h2>
<p>Compress is a general-purpose video tool. It is not directed at children and its developer does not knowingly collect information from anyone.</p>

<h2 id="changes">Changes</h2>
<p>If the app changes in a way that affects this policy, this page will be updated and the date at the top changed.</p>

<h2 id="contact">Contact</h2>
<p>For a question about this policy or about your data, <a href="{ISSUES}">open an issue on GitHub</a>. Issues are public, so please do not include personal details or videos in one.</p>

</div>
</div>
</main>
'''
    page("privacy.html", "Privacy policy | Compress",
         "How the Compress video compressor for Android handles your videos: they are compressed on your phone and never uploaded. No accounts, no adverts, no analytics.",
         body, "privacy.html", crumbs("Privacy policy", "privacy.html"))


# ------------------------------------------------------------------ terms

def terms():
    body = f'''<main id="main" class="doc">
<div class="wrap">
<div class="measure">
<h1>Terms of use</h1>
<p class="lede">Last updated {DATE_LONG}. These terms apply to the Compress app for Android. They set out how the app is offered and where responsibility lies when you use it. If you do not accept them, please do not use the app.</p>
<nav class="contents" aria-label="On this page"><strong>On this page</strong><ul><li><a href="#who">Who provides Compress</a></li><li><a href="#licence">Your licence</a></li><li><a href="#videos">Your videos</a></li><li><a href="#phone">Your phone</a></li><li><a href="#warranty">No warranty</a></li><li><a href="#liability">Liability</a></li><li><a href="#ending">Ending these terms</a></li><li><a href="#changes">Changes</a></li><li><a href="#law">Governing law</a></li><li><a href="#contact">Contact</a></li></ul></nav>

<h2 id="who">Who provides Compress</h2>
<p>Compress is an independent app made by Jonathan Jackson, an individual developer in the United Kingdom. It is a personal project, offered free of charge, and is not connected with Google, with any phone maker, with any messaging or email service, or with the maker of any other app.</p>

<h2 id="licence">Your licence</h2>
<p>Compress is free software. You may install it and use it free of charge, at home or at work, on as many devices as you like, and you may pass it on to other people. It is licensed under the GNU General Public License, version 3 or later, which also lets you study and change its <a href="{REPO}">source code</a> and pass on your changed version, provided you do so under the same licence and make your source code available in turn.</p>
<p>If you pass on a changed version, please give it a different name, so that nobody mistakes it for the original. Compress includes software made by other people. Those parts are yours to use under their own licences, which are listed on the <a href="licences.html">licences page</a>.</p>

<h2 id="videos">Your videos</h2>
<ul>
<li>Your videos are yours. The developer never sees them and claims no rights in them.</li>
<li>You are responsible for the videos you open in Compress and for what you do with the results. Compress, trim or join only videos you have the right to change.</li>
<li>Compressing discards part of a video for good. The copy is not the original, and the original cannot be rebuilt from it.</li>
<li>Check a copy before you delete its original. Compress checks that each new file opens and plays, which is not the same as you being happy with how it looks and sounds.</li>
<li>Replace originals is off unless you turn it on. When it is on, originals go to Android's bin only after you confirm, and Android deletes them for good after 30 days.</li>
<li>The size and time shown before you start are estimates, and a size target may be missed by a little.</li>
</ul>

<h2 id="phone">Your phone</h2>
<p>Compressing video is heavy work. It uses battery and warms the phone, most of all on the Max quality engine. Compress pauses when Android reports that the phone is hot and waits for the charger when the battery is low, unless you switch that protection off. Long runs are best left on charge, somewhere the phone can stay cool.</p>

<h2 id="warranty">No warranty</h2>
<p>Compress is provided as it is, without charge and without any promise that it will be free of faults, always available, able to read or compress a particular video, or suited to a particular purpose.</p>

<h2 id="liability">Liability</h2>
<p>As far as the law allows, the developer is not liable for loss of data, loss of videos, or any indirect loss that comes from using or being unable to use Compress. Keep your originals until you have checked the copies, and have a backup of any video that matters before you turn on Replace originals.</p>
<p>Nothing in these terms limits liability that cannot legally be limited, including liability for death or personal injury caused by negligence, or for fraud. Nothing in these terms affects your statutory rights as a consumer.</p>

<h2 id="ending">Ending these terms</h2>
<p>You can stop using Compress at any time by uninstalling it. The <a href="privacy.html#deleting">privacy policy</a> explains how to remove what it has stored.</p>

<h2 id="changes">Changes</h2>
<p>These terms may be updated as the app changes. The date at the top shows the latest version, and continuing to use the app means you accept it.</p>

<h2 id="law">Governing law</h2>
<p>These terms are governed by the law of England and Wales. If you live elsewhere in the United Kingdom or in another country, you keep any protection that the law where you live says cannot be taken away.</p>

<h2 id="contact">Contact</h2>
<p>For a question about these terms, <a href="{ISSUES}">open an issue on GitHub</a>.</p>

</div>
</div>
</main>
'''
    page("terms.html", "Terms of use | Compress",
         "The terms for using the Compress video compressor for Android: your licence, your responsibility for the videos you compress, and the limits of liability.",
         body, "terms.html", crumbs("Terms of use", "terms.html"))


# ------------------------------------------------------------------ licences

def licences():
    body = f'''<main id="main" class="doc">
<div class="wrap">
<div class="measure">
<h1>Licences and credits</h1>
<p class="lede">Last updated {DATE_LONG}. Compress is built on software made by other people. This page gives Compress's own licence, credits the work it depends on and names the licence each part is used under.</p>
<nav class="contents" aria-label="On this page"><strong>On this page</strong><ul><li><a href="#compress">Compress itself</a></li><li><a href="#encoders">The encoders</a></li><li><a href="#software">Other software</a></li><li><a href="#typefaces">Typefaces</a></li><li><a href="#names">Names and trademarks</a></li><li><a href="#texts">Licence texts</a></li></ul></nav>

<h2 id="compress">Compress itself</h2>
<p>Compress is copyright &copy; 2026 Jonathan Jackson. It is free software: you can redistribute it and change it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the licence or, at your option, any later version. It is distributed in the hope that it will be useful, but without any warranty.</p>
<p>The full source code is in the <a href="{REPO}/tree/main/android">android folder of the GitHub repository</a>, with the build script for the encoders described below.</p>

<h2 id="encoders">The encoders</h2>
<p>The Max quality engine and the GIF maker run a separate program that is shipped inside the app. It is built from three projects, each unmodified. Their complete source code, as built, is attached to every release as <code>compress-encoder-sources.zip</code> on <a href="{REPO}/releases">GitHub Releases</a>.</p>
<div class="scroll">
<table>
<thead><tr><th scope="col">Component</th><th scope="col">Used for</th><th scope="col">Licence and copyright</th></tr></thead>
<tbody>
<tr><th scope="row"><a href="https://ffmpeg.org">FFmpeg</a> 8.0</th><td>Reading videos, filtering the picture and sound, and writing MP4 and GIF files in the Max quality engine</td><td>GNU General Public License, version 2 or later, as built here. Copyright &copy; the FFmpeg developers</td></tr>
<tr><th scope="row"><a href="https://www.videolan.org/developers/x264.html">x264</a></th><td>Writing H.264 video in the Max quality engine</td><td>GNU General Public License, version 2 or later. Copyright &copy; the x264 project</td></tr>
<tr><th scope="row"><a href="https://www.x265.org">x265</a> 4.1</th><td>Writing HEVC video in the Max quality engine</td><td>GNU General Public License, version 2 or later. Copyright &copy; MulticoreWare, Inc. and the x265 contributors</td></tr>
</tbody>
</table>
</div>

<h2 id="software">Other software</h2>
<div class="scroll">
<table>
<thead><tr><th scope="col">Component</th><th scope="col">Used for</th><th scope="col">Licence and copyright</th></tr></thead>
<tbody>
<tr><th scope="row"><a href="https://developer.android.com/media/media3">AndroidX Media3</a></th><td>The Fast engine: driving the phone's video chip, and writing the MP4 file</td><td>Apache License 2.0. Copyright &copy; The Android Open Source Project</td></tr>
<tr><th scope="row"><a href="https://developer.android.com/jetpack">AndroidX, WorkManager and Jetpack Compose</a></th><td>The screens, and starting work when the phone is on charge</td><td>Apache License 2.0. Copyright &copy; The Android Open Source Project</td></tr>
<tr><th scope="row"><a href="https://m3.material.io">Material components and icons</a></th><td>Buttons, lists, sliders and icons</td><td>Apache License 2.0. Copyright &copy; Google LLC</td></tr>
<tr><th scope="row"><a href="https://kotlinlang.org">Kotlin</a> and kotlinx.coroutines</th><td>The language the app is written in, and doing work in the background</td><td>Apache License 2.0. Copyright &copy; JetBrains s.r.o. and Kotlin contributors</td></tr>
</tbody>
</table>
</div>

<h2 id="typefaces">Typefaces</h2>
<p>The app uses your phone's own fonts. This website is set in two typefaces, both used under the SIL Open Font License, Version 1.1.</p>
<div class="scroll">
<table>
<thead><tr><th scope="col">Typeface</th><th scope="col">Copyright</th></tr></thead>
<tbody>
<tr><th scope="row"><a href="https://github.com/googlefonts/literata">Literata</a></th><td>Copyright 2017 The Literata Project Authors</td></tr>
<tr><th scope="row"><a href="https://www.brailleinstitute.org/freefont/">Atkinson Hyperlegible</a></th><td>Copyright 2020 Braille Institute of America, Inc.</td></tr>
</tbody>
</table>
</div>

<h2 id="names">Names and trademarks</h2>
<p>Compress is not affiliated with or endorsed by Google, Samsung, Meta, Discord, the makers of the software above, or any app named on this site. Android, Google Play, Chrome and Gmail are trademarks of Google LLC. WhatsApp is a trademark of WhatsApp LLC. Discord is a trademark of Discord Inc. Galaxy is a trademark of Samsung Electronics Co., Ltd. FFmpeg is a trademark of Fabrice Bellard, originator of the FFmpeg project. Other product names belong to their owners and are used only to describe them.</p>

<h2 id="texts">Licence texts</h2>
<ul>
<li><a href="https://www.gnu.org/licenses/gpl-3.0.html">GNU General Public License, version 3</a>. A copy is in the repository's <a href="{REPO}/blob/main/LICENSE">LICENSE file</a>.</li>
<li><a href="https://www.gnu.org/licenses/old-licenses/gpl-2.0.html">GNU General Public License, version 2</a></li>
<li><a href="https://www.apache.org/licenses/LICENSE-2.0">Apache License 2.0</a></li>
<li><a href="https://openfontlicense.org/open-font-license-official-text/">SIL Open Font License 1.1</a>. The copies for this site's two typefaces are in its <a href="assets/fonts/LICENSE-literata.txt">Literata</a> and <a href="assets/fonts/LICENSE-atkinson-hyperlegible.txt">Atkinson Hyperlegible</a> licence files.</li>
</ul>

</div>
</div>
</main>
'''
    page("licences.html", "Licences and credits | Compress",
         "The software and typefaces that the Compress video compressor for Android is built on, the licence each is used under, and where its source code is.",
         body, "licences.html", crumbs("Licences", "licences.html"))


def not_found():
    body = '''<main id="main" class="doc"><div class="wrap"><div class="measure">
<h1>That page was compressed to nothing</h1>
<p class="lede">The address may be mistyped, or the page may have moved.</p>
<p><a href="/compress/">Go to the Compress home page</a></p>
</div></div></main>
'''
    page("404.html", "Page not found | Compress", "That page is not on the Compress site.", body)


def small_files():
    (OUT / "robots.txt").write_text(f"User-agent: *\nAllow: /\n\nSitemap: {BASE}sitemap.xml\n")
    pages = ["", "compare.html", "releases.html", "more-apps.html", "privacy.html", "terms.html", "licences.html"]
    urls = "\n".join(f"  <url><loc>{BASE}{p}</loc><lastmod>{DATE_ISO}</lastmod></url>" for p in pages)
    (OUT / "sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + urls + "\n</urlset>\n")
    (OUT / ".nojekyll").write_text("")
    (OUT / "assets").mkdir(exist_ok=True)
    (OUT / "assets" / "favicon.svg").write_text(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108">{ICON}</svg>')


if __name__ == "__main__":
    OUT.mkdir(parents=True, exist_ok=True)
    small_files()
    home(); compare(); releases(); more_apps(); privacy(); terms(); licences(); not_found()
    print("built", sorted(p.name for p in OUT.glob("*.html")))

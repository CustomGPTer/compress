package uk.jj.compress

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import uk.jj.compress.data.SettingsStore

/** Looks at the signed TorusApps catalogue for a newer version. Nothing about the phone is sent. */
object Update {
    const val SITE = TorusLinks.PAGE
    const val RELEASES = TorusLinks.PAGE
    const val PRIVACY = TorusLinks.PRIVACY
    const val MORE_APPS = TorusLinks.HOME
    /** Compress's code stays public on GitHub, as its GPL libraries require. */
    const val SOURCE = "https://github.com/CustomGPTer/compress"
    /** Update available opens Compress's page; nothing downloads inside the app. */
    const val APK = TorusLinks.PAGE

    /** The newer version's name, or null. */
    val available = MutableStateFlow<String?>(null)

    fun isNewer(latest: String, current: String): Boolean {
        fun parts(v: String) = v.trim().removePrefix("v").split('.', '-').map { it.toIntOrNull() ?: 0 }
        val a = parts(latest); val b = parts(current)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /** @return "newer", "current" or "failed". */
    suspend fun check(force: Boolean = false): String = withContext(Dispatchers.IO) {
        val s = SettingsStore.value
        val now = System.currentTimeMillis()
        if (!force && (!s.updateCheck || now - s.lastUpdateCheck < 24 * 3600_000L)) return@withContext "current"
        try {
            val tag = TorusLinks.latestVersionNow() ?: return@withContext "failed"
            SettingsStore.update { it.copy(lastUpdateCheck = now) }
            if (tag.isNotBlank() && isNewer(tag, BuildConfig.VERSION_NAME)) {
                available.value = tag.removePrefix("v"); "newer"
            } else { available.value = null; "current" }
        } catch (e: Exception) {
            "failed"
        }
    }
}

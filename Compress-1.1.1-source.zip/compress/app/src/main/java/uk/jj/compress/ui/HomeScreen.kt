package uk.jj.compress.ui

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import uk.jj.compress.Nav
import uk.jj.compress.Screen
import uk.jj.compress.Update
import uk.jj.compress.data.Album
import uk.jj.compress.data.JobState
import uk.jj.compress.data.Jobs
import uk.jj.compress.data.Ledger
import uk.jj.compress.data.MediaRepo
import uk.jj.compress.data.Saver
import uk.jj.compress.data.SettingsStore
import uk.jj.compress.data.VideoItem
import uk.jj.compress.engine.Codec
import uk.jj.compress.engine.Format
import uk.jj.compress.engine.Planner
import uk.jj.compress.engine.Preset
import uk.jj.compress.service.CompressService

private enum class Sort(val label: String) {
    NEWEST("Newest first"), OLDEST("Oldest first"), BIGGEST("Biggest first"), SMALLEST("Smallest first"),
    LONGEST("Longest first"), SHORTEST("Shortest first"), NAME("Name A to Z"),
}

private enum class Filter(val label: String) {
    TODO("Not compressed yet"), BIG("Over 100 MB"), UHD("4K and up"), LONG("Over 1 minute"),
}

@Composable
fun Thumb(uri: Uri, modifier: Modifier = Modifier, px: Int = 320) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri, px) { value = MediaRepo.thumbnail(ctx, uri, px) }
    Box(modifier.background(C.SurfaceHigh)) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
    }
}

fun mediaPermissions(): Array<String> = buildList {
    if (Build.VERSION.SDK_INT >= 33) {
        add(Manifest.permission.READ_MEDIA_VIDEO); add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT >= 34) add(Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED)
    } else add(Manifest.permission.READ_EXTERNAL_STORAGE)
    add(Manifest.permission.ACCESS_MEDIA_LOCATION)
}.toTypedArray()

/** Rough saving if a video were compressed at the High setting. */
private fun possibleSaving(v: VideoItem): Long {
    if (v.durationMs <= 0 || v.width <= 0 || v.height <= 0) return 0
    val bps = Planner.presetBitrate(Codec.HEVC, Preset.HIGH, v.width, v.height, 30f) + 128_000L
    val predicted = bps * v.durationMs / 8000
    return if (predicted < v.size * 0.9) v.size - predicted else 0
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val videos by AppModel.videos.collectAsState()
    val loaded by AppModel.loaded.collectAsState()
    val picks by AppModel.picks.collectAsState()
    val jobs by Jobs.flow.collectAsState()
    val compressed by Ledger.compressedFlow.collectAsState()
    val settings by SettingsStore.flow.collectAsState()
    val update by Update.available.collectAsState()

    var tab by remember { mutableIntStateOf(0) }
    var sort by remember { mutableStateOf(Sort.NEWEST) }
    var filters by remember { mutableStateOf(setOf<Filter>()) }
    var album by remember { mutableStateOf<Album?>(null) }
    var sortMenu by remember { mutableStateOf(false) }
    var hasAccess by remember { mutableStateOf(MediaRepo.canReadSome(ctx)) }
    var fullAccess by remember { mutableStateOf(MediaRepo.canReadAll(ctx)) }
    val snackbar = remember { SnackbarHostState() }

    val askAccess = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        hasAccess = MediaRepo.canReadSome(ctx); fullAccess = MediaRepo.canReadAll(ctx)
        scope.launch { AppModel.refresh(ctx) }
    }
    val pickFiles = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { runCatching { ctx.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } }
            scope.launch {
                val offered = AppModel.setExternal(ctx, uris)
                AppModel.resetDraft()
                Nav.push(Screen.Options)
                if (offered > AppModel.MAX_PICKS) snackbar.showSnackbar("Three videos at most per go, so the first three were taken.")
            }
        }
    }

    LaunchedEffect(Unit) { Update.check() }

    val sourceIds = compressed.keys
    val outputIds = remember(compressed) { compressed.values.toSet() }
    val ownFolder = remember(settings.outputFolder) { Saver.videoFolder(settings.outputFolder, "").trimEnd('/') + "/" }
    fun isOutput(v: VideoItem) = v.id in outputIds || (settings.outputFolder != "beside" && v.relPath.equals(ownFolder, ignoreCase = true))

    val shown = remember(videos, sort, filters, album, compressed, ownFolder) {
        var list = videos.asSequence()
        album?.let { a -> list = list.filter { it.bucketId == a.id } }
        if (Filter.TODO in filters) list = list.filter { it.id !in sourceIds && !isOutput(it) }
        if (Filter.BIG in filters) list = list.filter { it.size >= 100_000_000 }
        if (Filter.UHD in filters) list = list.filter { it.longSide >= 3840 || it.shortSide >= 2160 }
        if (Filter.LONG in filters) list = list.filter { it.durationMs >= 60_000 }
        when (sort) {
            Sort.NEWEST -> list.sortedByDescending { it.sortDate }
            Sort.OLDEST -> list.sortedBy { it.sortDate }
            Sort.BIGGEST -> list.sortedByDescending { it.size }
            Sort.SMALLEST -> list.sortedBy { it.size }
            Sort.LONGEST -> list.sortedByDescending { it.durationMs }
            Sort.SHORTEST -> list.sortedBy { it.durationMs }
            Sort.NAME -> list.sortedBy { it.name.lowercase() }
        }.toList()
    }
    val reclaim = remember(videos, compressed, ownFolder) {
        videos.filter { it.id !in sourceIds && !isOutput(it) }.sumOf { possibleSaving(it) }
    }
    val albums = remember(videos) { MediaRepo.albums(videos) }

    val runningJob = jobs.firstOrNull { it.state == JobState.RUNNING }
    val queued = jobs.count { it.state == JobState.QUEUED }
    val binWaiting = jobs.count { it.replacePending }

    Scaffold(
        containerColor = C.Bg,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.Bg),
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Compress", fontWeight = FontWeight.Bold, fontSize = 24.sp)
                        Spacer(Modifier.width(8.dp)); Dot(C.Accent, Modifier.padding(top = 6.dp))
                    }
                },
                actions = {
                    IconButton(onClick = { pickFiles.launch(arrayOf("video/*")) }) { Icon(Icons.Rounded.FolderOpen, "Pick from files") }
                    Box {
                        IconButton(onClick = { sortMenu = true }) { Icon(Icons.Rounded.SwapVert, "Sort") }
                        DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }, containerColor = C.SurfaceHigh) {
                            Sort.entries.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s.label, color = if (s == sort) C.Accent else C.Text) },
                                    onClick = { sort = s; sortMenu = false },
                                )
                            }
                        }
                    }
                    IconButton(onClick = { Nav.push(Screen.Settings) }) { Icon(Icons.Rounded.Settings, "Settings") }
                },
            )
        },
        bottomBar = {
            if (picks.isNotEmpty()) {
                Surface(color = C.Surface, tonalElevation = 0.dp) {
                    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("${picks.size} of ${AppModel.MAX_PICKS} ticked", style = MaterialTheme.typography.titleMedium)
                            Hint(Format.size(picks.sumOf { it.size }))
                        }
                        TextButton(onClick = { AppModel.clearPicks() }) { Text("Clear", color = C.Muted) }
                        Spacer(Modifier.width(8.dp))
                        Button(onClick = { AppModel.resetDraft(); Nav.push(Screen.Options) },
                            colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.OnAccent)) {
                            Text("Next")
                        }
                    }
                }
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            if (!hasAccess) {
                AccessPanel { askAccess.launch(mediaPermissions()) }
                return@Column
            }

            // Tabs
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                listOf("All videos", "Albums").forEachIndexed { i, label ->
                    Column(Modifier.weight(1f).clickable { tab = i }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(label, style = MaterialTheme.typography.titleSmall, color = if (tab == i) C.Text else C.Muted)
                        Spacer(Modifier.height(8.dp))
                        Box(Modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp)).background(if (tab == i) C.Accent else Color.Transparent))
                    }
                }
            }

            if (tab == 1 && album == null) {
                LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(albums, key = { it.id }) { a ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(C.Surface).clickable { album = a; tab = 0 }.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Thumb(a.cover.uri, Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)))
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(a.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Hint("${a.count} video${if (a.count == 1) "" else "s"} · ${Format.size(a.size)}")
                            }
                        }
                    }
                }
                return@Column
            }

            // Filters
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                album?.let { a ->
                    Surface(onClick = { album = null }, shape = RoundedCornerShape(50), color = C.AccentDim, contentColor = C.Accent) {
                        Row(Modifier.padding(start = 14.dp, end = 8.dp, top = 6.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(a.name, style = MaterialTheme.typography.labelLarge, maxLines = 1)
                            Spacer(Modifier.width(4.dp)); Icon(Icons.Rounded.Close, "Show all albums", Modifier.size(18.dp))
                        }
                    }
                }
                Filter.entries.forEach { f ->
                    Pill(f.label, f in filters) { filters = if (f in filters) filters - f else filters + f }
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, bottom = 24.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                val full: (androidx.compose.foundation.lazy.grid.LazyGridItemSpanScope.() -> GridItemSpan) = { GridItemSpan(maxLineSpan) }
                update?.let { v ->
                    item(span = full) {
                        Banner("Update available: version $v", "Tap to open Compress on torusapps.com", C.Accent) {
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Update.APK)))
                        }
                    }
                }
                if (runningJob != null) item(span = full) {
                    Banner("Compressing · ${runningJob.progress}%", "${runningJob.name}${if (queued > 0) " · $queued more waiting" else ""}", C.Accent) { Nav.push(Screen.Progress) }
                } else if (queued > 0) item(span = full) {
                    Banner("$queued video${if (queued == 1) "" else "s"} waiting", "Tap to start now", C.Warn) {
                        CompressService.start(ctx); Nav.push(Screen.Progress)
                    }
                }
                if (binWaiting > 0) item(span = full) {
                    Banner("$binWaiting original${if (binWaiting == 1) "" else "s"} ready for the bin", "Tap to review and confirm", C.Blue) { Nav.push(Screen.Results) }
                }
                if (!fullAccess) item(span = full) {
                    Banner("Showing only the videos you allowed", "Tap to allow all videos", C.Muted) { askAccess.launch(mediaPermissions()) }
                }
                if (reclaim > 50_000_000 && album == null && filters.isEmpty()) item(span = full) {
                    Banner("About ${Format.size(reclaim)} could be freed", "Tap to see the biggest videos first", C.Accent) {
                        sort = Sort.BIGGEST; filters = setOf(Filter.TODO)
                    }
                }
                if (shown.isEmpty()) item(span = full) {
                    Box(Modifier.fillMaxWidth().padding(top = 64.dp), contentAlignment = Alignment.Center) {
                        if (!loaded) CircularProgressIndicator(color = C.Accent)
                        else Text(if (videos.isEmpty()) "No videos found on this phone." else "No videos match these filters.",
                            color = C.Muted, textAlign = TextAlign.Center)
                    }
                }
                items(shown, key = { it.id }) { v ->
                    val index = picks.indexOfFirst { it.uri == v.uri }
                    VideoCell(v, index, done = v.id in sourceIds, output = isOutput(v)) {
                        if (!AppModel.toggle(v)) scope.launch {
                            snackbar.currentSnackbarData?.dismiss()
                            snackbar.showSnackbar("Three videos at most per go.")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Banner(title: String, subtitle: String, tint: Color, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(16.dp)).background(C.Surface).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(36.dp).clip(RoundedCornerShape(2.dp)).background(tint))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Hint(subtitle)
        }
    }
}

@Composable
private fun VideoCell(v: VideoItem, pickIndex: Int, done: Boolean, output: Boolean, onClick: () -> Unit) {
    val picked = pickIndex >= 0
    Box(
        Modifier.aspectRatio(1f).clip(RoundedCornerShape(12.dp))
            .let { if (picked) it.border(3.dp, C.Accent, RoundedCornerShape(12.dp)) else it }
            .clickable(onClick = onClick),
    ) {
        Thumb(v.uri, Modifier.fillMaxSize())
        Box(Modifier.fillMaxWidth().height(44.dp).align(Alignment.BottomCenter)
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))))
        Row(Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp)) {
            Text(Format.duration(v.durationMs), fontSize = 11.sp, color = Color.White)
            Spacer(Modifier.weight(1f))
            Text(Format.size(v.size), fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.SemiBold)
        }
        if (done || output) {
            Text(if (output) "Compressed" else "Done",
                Modifier.align(Alignment.TopStart).padding(5.dp).clip(RoundedCornerShape(50))
                    .background(if (output) C.Accent else Color(0xCC000000)).padding(horizontal = 7.dp, vertical = 2.dp),
                fontSize = 10.sp, fontWeight = FontWeight.SemiBold, color = if (output) C.OnAccent else C.Accent)
        }
        if (picked) {
            Box(Modifier.fillMaxSize().background(Color(0x553DDC97)))
            Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(24.dp).clip(CircleShape).background(C.Accent), contentAlignment = Alignment.Center) {
                Text("${pickIndex + 1}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = C.OnAccent)
            }
        }
    }
}

@Composable
private fun AccessPanel(onAllow: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Let Compress see your videos", style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text("Compress needs to read the videos on this phone to make smaller copies. " +
            "Everything is done on the phone. Nothing is uploaded, and your originals are kept unless you choose otherwise.",
            color = C.Muted, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onAllow, colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.OnAccent)) {
            Text("Allow access")
        }
        Spacer(Modifier.height(12.dp))
        Hint("You will also be asked about notifications, which show progress while the screen is off.", Modifier.padding(horizontal = 12.dp))
    }
}

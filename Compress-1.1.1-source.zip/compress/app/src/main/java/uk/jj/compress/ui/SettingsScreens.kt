package uk.jj.compress.ui

import uk.jj.compress.TorusLinks

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect
import kotlinx.coroutines.launch
import uk.jj.compress.BuildConfig
import uk.jj.compress.Nav
import uk.jj.compress.Screen
import uk.jj.compress.Update
import uk.jj.compress.data.Ledger
import uk.jj.compress.data.MediaRepo
import uk.jj.compress.data.Settings
import uk.jj.compress.data.SettingsStore
import uk.jj.compress.engine.AudioMode
import uk.jj.compress.engine.Codec
import uk.jj.compress.engine.Codecs
import uk.jj.compress.engine.Engine
import uk.jj.compress.engine.Format
import uk.jj.compress.engine.HdrMode
import uk.jj.compress.engine.Preset
import uk.jj.compress.engine.SoftEngine
import uk.jj.compress.service.AutoWorker
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Page(title: String, content: @Composable (PaddingValues) -> Unit) {
    Scaffold(
        containerColor = C.Bg,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.Bg),
                title = { Text(title) },
                navigationIcon = { IconButton(onClick = { Nav.back() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") } },
            )
        },
        content = content,
    )
}

private fun open(ctx: Context, url: String) {
    runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

private fun unrestricted(ctx: Context) = ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

private fun folderLabel(s: Settings) = if (s.outputFolder == Settings.BESIDE) "Beside the original" else s.outputFolder

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by SettingsStore.flow.collectAsState()
    val bin by Ledger.binFlow.collectAsState()
    val history by Ledger.historyFlow.collectAsState()
    val softReady = remember { SoftEngine(ctx).isAvailable() }
    var dialog by remember { mutableStateOf("") }
    var background by remember { mutableStateOf(unrestricted(ctx)) }
    var updateNote by remember { mutableStateOf("") }
    LifecycleResumeEffect(Unit) { background = unrestricted(ctx); onPauseOrDispose { } }
    fun set(change: (Settings) -> Settings) = SettingsStore.update(change)
    fun askBackground() {
        runCatching {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}")))
        }
    }

    Page("Settings") { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item { SectionTitle("Starting choices") }
            item {
                Card {
                    Hint("What the Options screen starts on each time. You can still change anything per video.")
                    ValueRow("Quality", s.preset.label) { dialog = "preset" }
                    ValueRow("Format", s.codec.label) { dialog = "codec" }
                    ValueRow("Engine", s.engine.label) { dialog = "engine" }
                    ValueRow("Sound", s.audio.label) { dialog = "audio" }
                    ValueRow("HDR videos", s.hdr.label) { dialog = "hdr" }
                    SwitchRow("Keep date and details", "Copies sort beside their originals in Gallery", s.keepInfo) { v -> set { it.copy(keepInfo = v) } }
                    SwitchRow("Remove location", "Take out where each video was filmed", s.stripLocation) { v -> set { it.copy(stripLocation = v) } }
                }
            }

            item { SectionTitle("Saving") }
            item {
                Card {
                    ValueRow("Save new videos to", folderLabel(s), "Android only allows folders inside Movies, DCIM or Pictures") { dialog = "folder" }
                    ValueRow("Name ending", s.nameSuffix.ifEmpty { "None" }, "Added to the original's name, e.g. holiday${s.nameSuffix}.mp4") { dialog = "suffix" }
                    SwitchRow("Continue even if the file gets bigger",
                        "Normally a video is skipped when compressing would not make it smaller. Turn on if you are compressing for another reason, such as changing the format.",
                        s.continueIfBigger) { v -> set { it.copy(continueIfBigger = v) } }
                }
            }

            item { SectionTitle("Originals") }
            item {
                Card {
                    SwitchRow("Replace originals",
                        if (Build.VERSION.SDK_INT >= 30) "After each video is compressed and checked, you are asked once to move the originals to Android's bin, where they stay for 30 days. Off keeps every original."
                        else "Needs Android 11 or later.",
                        s.replaceOriginals && Build.VERSION.SDK_INT >= 30, enabled = Build.VERSION.SDK_INT >= 30) { v -> set { it.copy(replaceOriginals = v) } }
                    if (Build.VERSION.SDK_INT >= 30) ValueRow("Bin", if (bin.isEmpty()) "Empty" else "${bin.size}", "Put originals back, or delete them now") { Nav.push(Screen.Bin) }
                }
            }

            item { SectionTitle("Running by itself") }
            item {
                Card {
                    SwitchRow("Overnight mode", "Videos you queue wait until the phone is on charge, then run by themselves.", s.overnight) { v ->
                        set { it.copy(overnight = v) }
                        if (v && !unrestricted(ctx)) dialog = "background"
                    }
                    SwitchRow("Automatic mode",
                        "New camera videos are compressed while the phone charges, using the starting choices above. Originals are kept.",
                        s.autoMode) { v ->
                        if (v && !MediaRepo.canReadAll(ctx)) { dialog = "needAccess"; return@SwitchRow }
                        set { it.copy(autoMode = v, autoSeenUpTo = if (v) System.currentTimeMillis() / 1000 else it.autoSeenUpTo) }
                        if (v) { AutoWorker.schedule(ctx); if (!unrestricted(ctx)) dialog = "background" } else AutoWorker.cancel(ctx)
                    }
                    if (s.autoMode) ValueRow("Only videos over", "${s.autoMinMb} MB") { dialog = "autoMin" }
                    ValueRow("Background running", if (background) "Allowed" else "Limited",
                        if (background) "Compress can start by itself when the phone is on charge."
                        else "Android may hold Compress back until you tap a notification. Tap to allow.") { if (!background) askBackground() }
                    SwitchRow("Protect the phone", "Pauses if the phone gets hot, and waits for the charger when the battery is under 15%.", s.pauseWhenHotOrLow) { v ->
                        set { it.copy(pauseWhenHotOrLow = v) }
                    }
                }
            }

            item { SectionTitle("Space saved") }
            item {
                Card {
                    SwitchRow("Keep a tally", "A running total of space saved, with a list of what was compressed. Off by default; kept only on this phone.", s.tally) { v ->
                        set { it.copy(tally = v) }
                    }
                    if (s.tally || history.isNotEmpty()) {
                        ValueRow("Tally and history", Format.size(history.sumOf { (it.before - it.after).coerceAtLeast(0) })) { Nav.push(Screen.History) }
                    }
                }
            }

            item { SectionTitle("About") }
            item {
                Card {
                    SwitchRow("Check for updates", "Looks at torusapps.com once a day. Nothing about you or your phone is sent.", s.updateCheck) { v ->
                        set { it.copy(updateCheck = v) }
                    }
                    ValueRow("Check now", updateNote, "This is version ${BuildConfig.VERSION_NAME}") {
                        updateNote = "Checking…"
                        scope.launch {
                            updateNote = when (Update.check(force = true)) {
                                "newer" -> "Update available"; "current" -> "Up to date"; else -> "Could not check"
                            }
                            if (Update.available.value != null) open(ctx, Update.APK)
                        }
                    }
                    HorizontalDivider(color = C.Outline)
                    ValueRow("More apps", "") { open(ctx, Update.MORE_APPS) }
                    ValueRow("Website", "torusapps.com/compress") { open(ctx, Update.SITE) }
                    ValueRow("Privacy policy", "") { open(ctx, Update.PRIVACY) }
                    ValueRow("Email", TorusLinks.EMAIL) { open(ctx, "mailto:" + TorusLinks.EMAIL) }
                    ValueRow("Licences and source code", "") { Nav.push(Screen.Licences) }
                }
            }
            item { Hint("Compress ${BuildConfig.VERSION_NAME} · Developed by Jonathan Jackson · Free, no adverts, no tracking", Modifier.padding(8.dp)) }
        }
    }

    when (dialog) {
        "preset" -> ChoiceDialog("Quality", Preset.entries.map { it to it.label }, s.preset, { it.blurb }, { dialog = "" }) { v -> set { it.copy(preset = v) }; dialog = "" }
        "codec" -> ChoiceDialog("Format", Codec.entries.filter { it != Codec.AV1 || Codecs.onChip(Codec.AV1) }.map { it to it.label }, s.codec, { it.blurb }, { dialog = "" }) { v ->
            set { it.copy(codec = v) }; dialog = ""
        }
        "engine" -> ChoiceDialog("Engine", Engine.entries.filter { it == Engine.FAST || softReady }.map { it to it.label }, s.engine, {
            if (it == Engine.FAST) "The phone's video chip. Quick and cool." else "Software encoder. About a quarter smaller for the same look, many times slower."
        }, { dialog = "" }) { v -> set { it.copy(engine = v, codec = if (v == Engine.MAX && it.codec == Codec.AV1) Codec.HEVC else it.codec) }; dialog = "" }
        "audio" -> ChoiceDialog("Sound", AudioMode.entries.map { it to it.label }, s.audio, {
            when (it) { AudioMode.KEEP -> "Sound is copied across untouched."; AudioMode.SHRINK -> "Sound is re-made at 128 kbps."; AudioMode.REMOVE -> "The copy is silent." }
        }, { dialog = "" }) { v -> set { it.copy(audio = v) }; dialog = "" }
        "hdr" -> ChoiceDialog("HDR videos", HdrMode.entries.map { it to it.label }, s.hdr, {
            if (it == HdrMode.KEEP) "Stays bright and vivid on HDR screens." else "Looks right on every screen."
        }, { dialog = "" }) { v -> set { it.copy(hdr = v) }; dialog = "" }
        "folder" -> ChoiceDialog("Save new videos to",
            listOf("Movies/Compress" to "Movies/Compress", "DCIM/Compress" to "DCIM/Compress", Settings.BESIDE to "Beside the original", "custom" to "A folder I name"),
            if (s.outputFolder in listOf("Movies/Compress", "DCIM/Compress", Settings.BESIDE)) s.outputFolder else "custom", {
                when (it) {
                    "Movies/Compress" -> "Its own album, away from your camera roll."
                    "DCIM/Compress" -> "Its own album, treated as camera footage by backup apps."
                    Settings.BESIDE -> "Same album as the original where Android allows it, otherwise Movies/Compress."
                    else -> "A new album inside Movies."
                }
            }, { dialog = "" }) { v -> if (v == "custom") dialog = "folderName" else { set { it.copy(outputFolder = v) }; dialog = "" } }
        "folderName" -> TextDialog("Folder name", s.outputFolder.substringAfter("Movies/", "").ifEmpty { "Compressed" }, "Created inside Movies.", { dialog = "" }) { v ->
            val clean = v.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
            if (clean.isNotEmpty()) set { it.copy(outputFolder = "Movies/$clean") }
            dialog = ""
        }
        "suffix" -> TextDialog("Name ending", s.nameSuffix, "Leave empty to keep the same name. Android adds (1) if the name is taken.", { dialog = "" }) { v ->
            set { it.copy(nameSuffix = v.replace(Regex("[\\\\/:*?\"<>|]"), "")) }; dialog = ""
        }
        "autoMin" -> NumberDialog("Only videos over", "MB", s.autoMinMb.toString(), "Smaller videos are left alone by automatic mode.", { dialog = "" }) { v ->
            set { it.copy(autoMinMb = v.coerceIn(1, 10_000)) }; dialog = ""
        }
        "background" -> androidx.compose.material3.AlertDialog(
            onDismissRequest = { dialog = "" }, containerColor = C.Surface,
            title = { Text("Allow background running?") },
            text = { Text("Android only lets an app start heavy work by itself if it is allowed to run in the background without limits. Without this, Compress sends a notification when the phone is on charge and waits for your tap.") },
            confirmButton = { TextButton(onClick = { dialog = ""; askBackground() }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { dialog = "" }) { Text("Not now") } },
        )
        "needAccess" -> androidx.compose.material3.AlertDialog(
            onDismissRequest = { dialog = "" }, containerColor = C.Surface,
            title = { Text("Access to all videos needed") },
            text = { Text("Automatic mode has to see new camera videos as they arrive. Allow access to all videos from the home screen first.") },
            confirmButton = { TextButton(onClick = { dialog = "" }) { Text("OK") } },
        )
    }
}

@Composable
fun HistoryScreen() {
    val history by Ledger.historyFlow.collectAsState()
    val on = SettingsStore.flow.collectAsState().value.tally
    var confirm by remember { mutableStateOf(false) }
    val df = remember { SimpleDateFormat("d MMM yyyy, HH:mm", Locale.UK) }
    Page("Space saved") { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card {
                    Text(Format.size(history.sumOf { (it.before - it.after).coerceAtLeast(0) }), style = MaterialTheme.typography.headlineMedium, color = C.Accent)
                    Hint("saved across ${history.size} video${if (history.size == 1) "" else "s"}" + if (!on) " · the tally is switched off" else "")
                    if (history.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(onClick = { confirm = true }) { Text("Clear", color = C.Error) }
                    }
                }
            }
            items(history) { e ->
                Card {
                    Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Hint("${Format.size(e.before)} to ${Format.size(e.after)} · ${Format.percentSaved(e.before, e.after)}% smaller · ${df.format(Date(e.at))}")
                }
            }
        }
    }
    if (confirm) androidx.compose.material3.AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = C.Surface,
        title = { Text("Clear the tally?") },
        text = { Text("The total and the list are wiped. Your videos are not touched.") },
        confirmButton = { TextButton(onClick = { Ledger.clearHistory(); confirm = false }) { Text("Clear", color = C.Error) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
    )
}

@Composable
fun BinScreen() {
    val ctx = LocalContext.current
    val bin by Ledger.binFlow.collectAsState()
    val now = System.currentTimeMillis()
    val live = bin.filter { now - it.at < 30L * 24 * 3600_000 }
    var acting by remember { mutableStateOf<List<String>>(emptyList()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) Ledger.removeBin(acting)
        acting = emptyList()
    }
    fun run(uris: List<String>, restore: Boolean) {
        if (Build.VERSION.SDK_INT < 30 || uris.isEmpty()) return
        acting = uris
        runCatching {
            val list = uris.map(Uri::parse)
            val pi = if (restore) MediaStore.createTrashRequest(ctx.contentResolver, list, false) else MediaStore.createDeleteRequest(ctx.contentResolver, list)
            launcher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        }.onFailure { Ledger.removeBin(uris) }
    }
    Page("Bin") { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card {
                    Text(if (live.isEmpty()) "The bin is empty" else "${live.size} original${if (live.size == 1) "" else "s"} · ${Format.size(live.sumOf { it.size })}",
                        style = MaterialTheme.typography.titleMedium)
                    Hint("Originals that Compress moved to Android's bin. Android deletes each one for good 30 days after it was binned.", Modifier.padding(top = 4.dp))
                    if (live.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Row {
                            Button(onClick = { run(live.map { it.uri }, true) }, colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.OnAccent)) { Text("Put all back") }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = { run(live.map { it.uri }, false) }) { Text("Delete all now", color = C.Error) }
                        }
                    }
                }
            }
            items(live, key = { it.uri }) { e ->
                val daysLeft = (30 - (now - e.at) / (24 * 3600_000L)).coerceAtLeast(0)
                Card {
                    Text(e.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Hint("${Format.size(e.size)} · $daysLeft day${if (daysLeft == 1L) "" else "s"} left")
                    Row(Modifier.padding(top = 6.dp)) {
                        TextButton(onClick = { run(listOf(e.uri), true) }) { Text("Put back") }
                        TextButton(onClick = { run(listOf(e.uri), false) }) { Text("Delete now", color = C.Error) }
                    }
                }
            }
        }
    }
}


@Composable
fun LicencesScreen() {
    val ctx = LocalContext.current
    Page("Licences") { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card {
                    Text("Compress", style = MaterialTheme.typography.titleMedium)
                    Hint("© 2026 Jonathan Jackson. Compress is free software: you can redistribute it and change it under the GNU General Public License, version 3 or later. " +
                        "It comes with no warranty. The full source code, including the build script for the encoder below, is public.", Modifier.padding(top = 4.dp))
                    TextButton(onClick = { open(ctx, Update.SOURCE) }) { Text("Source code") }
                }
            }
            item {
                Card {
                    Text("FFmpeg, x264 and x265", style = MaterialTheme.typography.titleMedium)
                    Hint("The Max quality engine and the GIF maker use FFmpeg 8.0 (ffmpeg.org) built with the x264 and x265 encoders (videolan.org, x265.org). " +
                        "These are licensed under the GNU General Public License, version 2 or later. They are shipped as a separate program inside the app and are unmodified.",
                        Modifier.padding(top = 4.dp))
                    TextButton(onClick = { open(ctx, "https://www.gnu.org/licenses/gpl-3.0.html") }) { Text("Read the licence") }
                }
            }
            item {
                Card {
                    Text("AndroidX, Media3, Jetpack Compose and Kotlin", style = MaterialTheme.typography.titleMedium)
                    Hint("The Fast engine uses AndroidX Media3. The screens are built with Jetpack Compose and Material 3. Written in Kotlin with kotlinx.coroutines. " +
                        "All are licensed under the Apache License, version 2.0, by Google and JetBrains.", Modifier.padding(top = 4.dp))
                    TextButton(onClick = { open(ctx, "https://www.apache.org/licenses/LICENSE-2.0") }) { Text("Read the licence") }
                }
            }
        }
    }
}

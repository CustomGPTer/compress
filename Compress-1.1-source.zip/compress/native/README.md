# The Max quality encoder

`app/src/main/jniLibs/arm64-v8a/libffmpeg.so` is FFmpeg with the x264 and x265 encoders, built as one
arm64 Android program. The app runs it as a separate process for the Max quality engine and the GIF maker.
It is built from unmodified upstream source:

| Part   | Version | Source | Commit |
|--------|---------|--------|--------|
| FFmpeg | n8.0    | https://github.com/FFmpeg/FFmpeg (tag n8.0) | 140fd653aed8cad774f991ba083e2d01e86420c7 |
| x264   | stable  | https://github.com/mirror/x264 | c24e06c2e184345ceb33eb20a15d1024d9fd3497 |
| x265   | 4.1     | https://bitbucket.org/multicoreware/x265_git (tag 4.1) | 1d117bed4747758b51bd2c124d738527e30392cb |

## Rebuilding it

1. Install the Android NDK (29.0.14206865 was used), plus cmake, ninja, make, nasm and pkg-config.
2. Unpack the three archives from compress-encoder-sources.zip into `native/src/ffmpeg`, `native/src/x264` and `native/src/x265`.
3. Run `NDK=/path/to/ndk ./build.sh`.
4. Copy `native/out/libffmpeg.so` over the file in `jniLibs`.

All three are licensed under the GNU General Public License, version 2 or later. See `LICENSE` in the project root.

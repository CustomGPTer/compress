# Compress

Compress is a free video compressor for Android. It makes videos smaller without a difference you can see,
keeps running with the screen off, and does all of its work on the phone. Nothing is uploaded.
It has no adverts, no accounts and no paid version.

- Website: https://customgpter.github.io/compress/
- Latest app file: https://github.com/CustomGPTer/compress/releases/latest

## What it does

- Compresses up to three videos per go, one after another, with the screen off or the app closed
- Fast engine (the phone's video chip) writing HEVC, H.264 or, where the chip supports it, AV1
- Max quality engine (x264 / x265) for the smallest files at a given quality
- Quality presets, size targets (WhatsApp, Discord, Gmail, your own), and a manual bitrate
- Predicted size and time before you start; videos that would not shrink are skipped
- Resolution, frame rate, trim, crop, rotate, mirror, speed, volume
- Join clips, make a GIF, or save the sound on its own
- Keeps HDR, or converts it for older screens
- Keeps the date and details, with a switch to remove the location
- Optional: replace originals (via Android's 30-day bin), overnight mode, automatic mode, a space-saved tally

## Building

Needs JDK 21 and the Android SDK (platform 37). The encoder for the Max quality engine is already in
`app/src/main/jniLibs`; see `native/README.md` to rebuild it.

    ./gradlew testDebugUnitTest assembleDebug

A release build needs your own `signing.properties` and keystore in the project root.

## Licence

Copyright (C) 2026 Jonathan Jackson

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General
Public License as published by the Free Software Foundation, either version 3 of the License, or (at your
option) any later version. It is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.
See `LICENSE` for the full text.

The app includes FFmpeg, x264 and x265 (GPL v2 or later) and AndroidX, Media3, Jetpack Compose and Kotlin
libraries (Apache License 2.0).

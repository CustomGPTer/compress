package uk.jj.compress

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import uk.jj.compress.engine.AudioMode
import uk.jj.compress.engine.Codec
import uk.jj.compress.engine.CropRect
import uk.jj.compress.engine.Engine
import uk.jj.compress.engine.Format
import uk.jj.compress.engine.HdrMode
import uk.jj.compress.engine.Options
import uk.jj.compress.engine.Planner
import uk.jj.compress.engine.Preset
import uk.jj.compress.engine.SourceInfo
import uk.jj.compress.engine.Tool

class PlannerTest {
    private fun src(w: Int, h: Int, seconds: Double, mbps: Double, fps: Float = 30f, audio: Int = 128_000) = SourceInfo(
        width = w, height = h, fps = fps, durationMs = (seconds * 1000).toLong(),
        sizeBytes = ((mbps * 1_000_000 + audio) * seconds / 8).toLong(),
        videoBitrate = (mbps * 1_000_000).toInt(), audioBitrate = audio, videoMime = "video/avc", audioMime = "audio/mp4a-latm",
    )
    private val MB = 1_000_000L

    @Test fun cameraClipAtFullResolution() {
        // The 35 MB, 3504x2336, three-second camera clip from the brief.
        val s = src(3504, 2336, 3.0, 93.0)
        val p = Planner.plan(s, Options())
        assertNull(p.skipReason)
        assertEquals(3504, p.width); assertEquals(2336, p.height)
        assertTrue("predicted ${p.predictedBytes}", p.predictedBytes in 4 * MB..(6.5 * MB).toLong())
    }

    @Test fun presetsGetSmallerInOrder() {
        val s = src(1920, 1080, 60.0, 17.0)
        val sizes = Preset.entries.map { Planner.plan(s, Options(preset = it)).predictedBytes }
        assertEquals(sizes.sortedDescending(), sizes)
        assertTrue(sizes.first() < s.sizeBytes)
    }

    @Test fun h264NeedsMoreThanHevcAndAv1Less() {
        val h = Planner.presetBitrate(Codec.HEVC, Preset.HIGH, 1920, 1080, 30f)
        assertEquals(5_000_000, h)
        assertTrue(Planner.presetBitrate(Codec.H264, Preset.HIGH, 1920, 1080, 30f) > h)
        assertTrue(Planner.presetBitrate(Codec.AV1, Preset.HIGH, 1920, 1080, 30f) < h)
        // Four times the pixels should need well under four times the bits.
        val uhd = Planner.presetBitrate(Codec.HEVC, Preset.HIGH, 3840, 2160, 30f)
        assertTrue(uhd in (2.5 * h).toInt()..(3.2 * h).toInt())
    }

    @Test fun alreadyEfficientVideoIsSkipped() {
        val s = src(1920, 1080, 60.0, 3.0)
        assertNotNull(Planner.plan(s, Options(preset = Preset.HIGH)).skipReason)
        assertNull(Planner.plan(s, Options(preset = Preset.HIGH), allowBigger = true).skipReason)
        // Asking for a smaller picture is a real change, so it is not skipped.
        assertNull(Planner.plan(s, Options(preset = Preset.HIGH, shortSide = 720)).skipReason)
    }

    @Test fun neverPlansAboveTheSourceBitrate() {
        val s = src(1920, 1080, 60.0, 3.0)
        val p = Planner.plan(s, Options(preset = Preset.IDENTICAL), allowBigger = true)
        assertTrue(p.videoBitrate <= s.videoBitrate)
    }

    @Test fun sizeTargetIsRespectedAndPictureDropsWhenStarved() {
        val s = src(3840, 2160, 300.0, 45.0)
        val p = Planner.plan(s, Options(targetBytes = 16 * MB))
        assertTrue(p.predictedBytes <= 16 * MB)
        assertTrue("should have dropped the picture size", p.autoShortSide in 1 until 2160)
        assertTrue(minOf(p.width, p.height) == p.autoShortSide)
        // A short clip fits at full size.
        val q = Planner.plan(src(1920, 1080, 10.0, 17.0), Options(targetBytes = 16 * MB))
        assertEquals(0, q.autoShortSide); assertEquals(1080, q.height)
        assertTrue(q.predictedBytes <= 16 * MB)
    }

    @Test fun sizeTargetSkipsWhenAlreadyUnder() {
        val s = src(1920, 1080, 5.0, 8.0)
        assertTrue(s.sizeBytes < 16 * MB)
        assertNotNull(Planner.plan(s, Options(targetBytes = 16 * MB)).skipReason)
    }

    @Test fun userChosenResolutionIsNotOverridden() {
        val s = src(3840, 2160, 300.0, 45.0)
        val p = Planner.plan(s, Options(targetBytes = 16 * MB, shortSide = 1080))
        assertEquals(0, p.autoShortSide); assertEquals(1080, p.height); assertEquals(1920, p.width)
    }

    @Test fun pictureSizeMaths() {
        val s = src(3504, 2336, 3.0, 93.0)
        assertEquals(1620 to 1080, Planner.outputSize(s, Options(shortSide = 1080)))
        assertEquals(3504 to 2336, Planner.outputSize(s, Options(shortSide = 4320)))   // never bigger
        assertEquals(2336 to 3504, Planner.outputSize(s, Options(rotate = 90)))
        val (w, h) = Planner.outputSize(s, Options(crop = CropRect(0.25f, 0f, 0.75f, 1f)))
        assertEquals(1752, w); assertEquals(2336, h)
        val odd = Planner.outputSize(src(1001, 563, 1.0, 5.0), Options())
        assertEquals(0, odd.first % 2); assertEquals(0, odd.second % 2)
    }

    @Test fun trimAndSpeedChangeTheLength() {
        val s = src(1920, 1080, 60.0, 17.0)
        assertEquals(10_000, Planner.outputDurationMs(s, Options(trimStartMs = 5_000, trimEndMs = 15_000)))
        assertEquals(30_000, Planner.outputDurationMs(s, Options(speed = 2f)))
        assertEquals(120_000, Planner.outputDurationMs(s, Options(speed = 0.5f)))
        assertEquals(55_000, Planner.outputDurationMs(s, Options(trimStartMs = 5_000)))
        // Speeding up must not push the frame rate above the original.
        assertEquals(30f, Planner.outputFps(s, Options(speed = 2f)), 0.01f)
        assertEquals(15f, Planner.outputFps(s, Options(speed = 0.5f)), 0.01f)
        assertEquals(24f, Planner.outputFps(s, Options(fps = 24)), 0.01f)
        assertEquals(30f, Planner.outputFps(s, Options(fps = 60)), 0.01f)
    }

    @Test fun soundChoices() {
        val s = src(1920, 1080, 60.0, 17.0, audio = 256_000)
        assertTrue(Planner.plan(s, Options()).audioCopied)
        assertFalse(Planner.plan(s, Options(volume = 1.5f)).audioCopied)
        assertFalse(Planner.plan(s, Options(speed = 2f)).audioCopied)
        assertEquals(0, Planner.plan(s, Options(audio = AudioMode.REMOVE)).audioBitrate)
        assertEquals(96_000, Planner.plan(s, Options(audio = AudioMode.SHRINK, audioBitrate = 96_000)).audioBitrate)
        // Shrinking never raises the bitrate.
        assertEquals(64_000, Planner.plan(src(1920, 1080, 60.0, 17.0, audio = 64_000), Options(audio = AudioMode.SHRINK, audioBitrate = 128_000)).audioBitrate)
        val audioOnly = Planner.plan(s, Options(tool = Tool.AUDIO_ONLY))
        assertEquals(0, audioOnly.width)
        assertTrue(audioOnly.predictedBytes in 1_800_000L..2_100_000L)
    }

    @Test fun maxEngineIsPredictedSmallerAndUsesSaneQualityNumbers() {
        val s = src(1920, 1080, 60.0, 17.0)
        val fast = Planner.plan(s, Options()).predictedBytes
        val max = Planner.plan(s, Options(engine = Engine.MAX)).predictedBytes
        assertTrue(max < fast)
        assertEquals(23, Planner.crf(Codec.HEVC, Preset.HIGH))
        assertEquals(21, Planner.crf(Codec.H264, Preset.HIGH))
        assertTrue(Planner.crf(Codec.HEVC, Preset.IDENTICAL) < Planner.crf(Codec.HEVC, Preset.SMALL))
    }

    @Test fun timeEstimateScalesWithTheWork() {
        val s = src(1920, 1080, 60.0, 17.0)
        val p = Planner.plan(s, Options())
        val quick = Planner.estimateSeconds(p, s, 180.0)
        val slow = Planner.estimateSeconds(p, s, 12.0)
        assertTrue(quick in 15..30)
        assertTrue(slow > quick * 10)
    }

    @Test fun optionsSurviveSavingAndLoading() {
        val o = Options(
            tool = Tool.GIF, codec = Codec.AV1, engine = Engine.MAX, preset = Preset.SMALL, targetBytes = 25 * MB,
            manualBitrate = 1_234_000, shortSide = 720, fps = 24, audio = AudioMode.SHRINK, audioBitrate = 96_000, volume = 1.5f,
            trimStartMs = 1200, trimEndMs = 9800, crop = CropRect(0.1f, 0.2f, 0.9f, 0.8f), rotate = 270, flip = true, speed = 0.5f,
            keepInfo = false, stripLocation = true, hdr = HdrMode.TO_SDR, gifFps = 15, gifWidth = 640,
        )
        assertEquals(o, Options.fromJson(JSONObject(o.toJson().toString())))
        assertEquals(Options(), Options.fromJson(JSONObject("{}")))
        assertEquals(Options(), Options.fromJson(JSONObject("{\"codec\":\"NOPE\",\"preset\":\"??\"}")))
    }

    @Test fun wording() {
        assertEquals("35 MB", Format.size(35 * MB))
        assertEquals("5.2 MB", Format.size(5_200_000))
        assertEquals("146 KB", Format.size(146_000))
        assertEquals("1.5 GB", Format.size(1_500_000_000))
        assertEquals("412 MB", Format.size(412_300_000))
        assertEquals("0:03", Format.duration(3000))
        assertEquals("10:31", Format.duration(631_000))
        assertEquals("1:02:03", Format.duration(3_723_000))
        assertEquals(85, Format.percentSaved(100, 15))
        assertEquals("about 2 minutes", Format.eta(110))
        assertEquals("about 1 minute", Format.eta(61))
        assertEquals("21 Mbps", Format.bitrate(21_000_000))
    }

    @Test fun versionComparison() {
        assertTrue(Update.isNewer("v1.1", "1.0"))
        assertTrue(Update.isNewer("1.10", "1.9"))
        assertTrue(Update.isNewer("2.0", "1.99"))
        assertFalse(Update.isNewer("v1.0", "1.0"))
        assertFalse(Update.isNewer("1.0", "1.1"))
        assertFalse(Update.isNewer("", "1.0"))
    }
}

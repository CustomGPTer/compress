package uk.jj.compress

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.BeforeClass
import org.junit.Test
import uk.jj.compress.engine.AudioMode
import uk.jj.compress.engine.Codec
import uk.jj.compress.engine.CropRect
import uk.jj.compress.engine.Engine
import uk.jj.compress.engine.Options
import uk.jj.compress.engine.Planner
import uk.jj.compress.engine.SoftCommand
import uk.jj.compress.engine.SourceInfo
import java.io.File

/**
 * Runs the real command lines through a desktop copy of FFmpeg, when one is installed,
 * so a typo in a filter or flag is caught here and not on a phone.
 */
class SoftCommandTest {
    companion object {
        private val dir = File(System.getProperty("java.io.tmpdir"), "compress-soft-test")
        private val input = File(dir, "in.mp4")
        private var haveFfmpeg = false
        private val src = SourceInfo(640, 360, 30f, 4000, 0, 800_000, 128_000, "video/avc", "audio/mp4a-latm")

        private fun exec(vararg cmd: String): Pair<Int, String> {
            val p = ProcessBuilder(*cmd).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            return p.waitFor() to out
        }

        @BeforeClass @JvmStatic fun makeInput() {
            haveFfmpeg = runCatching { exec("ffmpeg", "-version").first == 0 && exec("ffprobe", "-version").first == 0 }.getOrDefault(false)
            if (!haveFfmpeg) return
            dir.deleteRecursively(); dir.mkdirs()
            val (code, out) = exec("ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc2=size=640x360:rate=30", "-f", "lavfi", "-i", "sine=frequency=440",
                "-t", "4", "-c:v", "libx264", "-b:v", "800k", "-c:a", "aac", "-b:a", "128k", "-metadata", "location=+53.4808-002.2426/", input.absolutePath)
            check(code == 0) { out }
        }
    }

    private fun run(args: List<String>): String {
        val (code, out) = exec("ffmpeg", *args.toTypedArray())
        assertEquals("ffmpeg failed:\n${args.joinToString(" ")}\n$out", 0, code)
        return out
    }

    private fun probe(f: File, entries: String, stream: String = "v:0"): String =
        exec("ffprobe", "-v", "error", "-select_streams", stream, "-show_entries", entries, "-of", "csv=p=0", f.absolutePath).second.trim()

    private fun duration(f: File) = exec("ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f.absolutePath).second.trim().toDouble()

    @Test fun qualityRunHevc() {
        assumeTrue(haveFfmpeg)
        val opt = Options(engine = Engine.MAX)
        val plan = Planner.plan(src, opt, allowBigger = true)
        val out = File(dir, "hevc.mp4")
        val log = run(SoftCommand.video(input.absolutePath, out.absolutePath, src, opt, plan))
        assertTrue("progress lines expected", log.contains("out_time_us=") || log.contains("out_time_ms="))
        assertEquals("hevc,640,360", probe(out, "stream=codec_name,width,height"))
        assertEquals("hvc1", probe(out, "stream=codec_tag_string"))
        assertEquals("aac", probe(out, "stream=codec_name", "a:0"))
        assertEquals(4.0, duration(out), 0.2)
    }

    @Test fun qualityRunH264WithEdits() {
        assumeTrue(haveFfmpeg)
        val opt = Options(engine = Engine.MAX, codec = Codec.H264, crop = CropRect(0.25f, 0f, 0.75f, 1f), rotate = 90, flip = true,
            speed = 2f, volume = 1.5f, trimStartMs = 1000, trimEndMs = 3000, shortSide = 240, fps = 15, stripLocation = true)
        val plan = Planner.plan(src, opt, allowBigger = true)
        val out = File(dir, "h264.mp4")
        run(SoftCommand.video(input.absolutePath, out.absolutePath, src, opt, plan))
        // 640x360 cropped to the middle half is 320x360; turned on its side 360x320; short side to 240 gives 270x240.
        assertEquals("h264,${plan.width},${plan.height}", probe(out, "stream=codec_name,width,height"))
        assertEquals(270, plan.width); assertEquals(240, plan.height)
        assertEquals(1.0, duration(out), 0.25)          // two seconds played at double speed
        assertEquals("15/1", probe(out, "stream=r_frame_rate"))
        val tags = exec("ffprobe", "-v", "error", "-show_entries", "format_tags", "-of", "default=nw=1", out.absolutePath).second
        assertTrue("location should be gone: $tags", !tags.contains("53.48"))
    }

    @Test fun twoRunsToHitASize() {
        assumeTrue(haveFfmpeg)
        for (codec in listOf(Codec.HEVC, Codec.H264)) {
            val target = 150_000L
            val opt = Options(engine = Engine.MAX, codec = codec, targetBytes = target, audio = AudioMode.SHRINK, audioBitrate = 64_000)
            val plan = Planner.plan(src.copy(sizeBytes = 500_000), opt, allowBigger = true)
            val out = File(dir, "target-$codec.mp4")
            val log = File(dir, "pass-$codec").absolutePath
            run(SoftCommand.video(input.absolutePath, out.absolutePath, src, opt, plan, 1, log))
            run(SoftCommand.video(input.absolutePath, out.absolutePath, src, opt, plan, 2, log))
            assertTrue("$codec came out at ${out.length()}", out.length() in 60_000..(target * 1.1).toLong())
        }
    }

    @Test fun silentAndKeptSound() {
        assumeTrue(haveFfmpeg)
        val mute = Options(engine = Engine.MAX, audio = AudioMode.REMOVE)
        val a = File(dir, "mute.mp4")
        run(SoftCommand.video(input.absolutePath, a.absolutePath, src, mute, Planner.plan(src, mute, true)))
        assertEquals("", probe(a, "stream=codec_name", "a:0"))
        val keep = Options(engine = Engine.MAX)
        val args = SoftCommand.video(input.absolutePath, File(dir, "keep.mp4").absolutePath, src, keep, Planner.plan(src, keep, true))
        assertTrue("sound should be copied untouched", args.zipWithNext().contains("-c:a" to "copy"))
    }

    @Test fun gif() {
        assumeTrue(haveFfmpeg)
        val opt = Options(trimStartMs = 500, trimEndMs = 2500, gifFps = 12, gifWidth = 320, rotate = 180)
        val out = File(dir, "out.gif")
        run(SoftCommand.gif(input.absolutePath, out.absolutePath, src, opt))
        assertEquals("gif,320,180", probe(out, "stream=codec_name,width,height"))
        assertTrue(out.length() > 1000)
    }
}

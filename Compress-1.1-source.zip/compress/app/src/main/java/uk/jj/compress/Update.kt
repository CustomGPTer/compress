package uk.jj.compress

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import uk.jj.compress.data.SettingsStore
import java.net.HttpURLConnection
import java.net.URL

/** Looks at the app's public release page for a newer version. Nothing about the phone is sent. */
object Update {
    const val SITE = "https://customgpter.github.io/compress/"
    const val RELEASES = "https://customgpter.github.io/compress/releases.html"
    const val PRIVACY = "https://customgpter.github.io/compress/privacy.html"
    const val SOURCE = "https://github.com/CustomGPTer/compress"
    const val APK = "https://github.com/CustomGPTer/compress/releases/latest/download/Compress.apk"
    private const val API = "https://api.github.com/repos/CustomGPTer/compress/releases/latest"

    /** The newer version's name, or null. */
    val available = MutableStateFlow<String?>(null)

    fun isNewer(latest: String, current: String): Boolean {
        fun parts(v: String) = v.trim().removePrefix("v").split('.', '-').map { it.toIntOrNull() ?: 0 }
        val a = parts(latest); val b = parts(current)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    /** @return "newer", "current" or "failed". */
    suspend fun check(force: Boolean = false): String = withContext(Dispatchers.IO) {
        val s = SettingsStore.value
        val now = System.currentTimeMillis()
        if (!force && (!s.updateCheck || now - s.lastUpdateCheck < 24 * 3600_000L)) return@withContext "current"
        try {
            val c = URL(API).openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            c.setRequestProperty("Accept", "application/vnd.github+json")
            c.setRequestProperty("User-Agent", "Compress-Android")
            if (c.responseCode != 200) { c.disconnect(); return@withContext "failed" }
            val body = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            SettingsStore.update { it.copy(lastUpdateCheck = now) }
            val tag = JSONObject(body).optString("tag_name")
            if (tag.isNotBlank() && isNewer(tag, BuildConfig.VERSION_NAME)) {
                available.value = tag.removePrefix("v"); "newer"
            } else { available.value = null; "current" }
        } catch (e: Exception) {
            "failed"
        }
    }
}

package uk.jj.compress.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import uk.jj.compress.data.Job
import uk.jj.compress.data.Jobs
import uk.jj.compress.data.Ledger
import uk.jj.compress.data.MediaRepo
import uk.jj.compress.data.SettingsStore
import java.util.concurrent.TimeUnit

/** Starts the waiting queue once the phone is put on charge. */
class ChargeWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        if (Jobs.hasWork && !CompressService.running) {
            if (!CompressService.start(applicationContext)) {
                Notifier.nudge(applicationContext, "On charge and ready", "Tap to start compressing your queued videos.")
            }
        }
        return Result.success()
    }

    companion object {
        fun schedule(ctx: Context) {
            val req = OneTimeWorkRequestBuilder<ChargeWorker>()
                .setConstraints(Constraints.Builder().setRequiresCharging(true).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniqueWork("charge", ExistingWorkPolicy.REPLACE, req)
        }
    }
}

/** Automatic mode: notices new camera videos and queues them while the phone is on charge. */
class AutoWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val s = SettingsStore.value
        if (!s.autoMode) return Result.success()
        if (MediaRepo.canReadAll(ctx)) {
            val now = System.currentTimeMillis() / 1000
            val queued = Jobs.value.filter { !it.finished }.map { it.sourceId }.toSet()
            val fresh = MediaRepo.query(
                ctx,
                "${MediaStore.Video.Media.DATE_ADDED} > ? AND ${MediaStore.Video.Media.DATE_ADDED} < ? AND " +
                    "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Video.Media.SIZE} >= ?",
                arrayOf(s.autoSeenUpTo.toString(), (now - 60).toString(), "DCIM/%", (s.autoMinMb * 1_000_000L).toString()),
            ).filter { !Ledger.isSource(it.id) && !Ledger.isOutput(it.id) && it.id !in queued }
            if (fresh.isNotEmpty()) {
                val batch = System.currentTimeMillis()
                Jobs.add(fresh.sortedBy { it.dateAdded }.map {
                    Job(
                        batch = batch, sources = listOf(it.uri.toString()), sourceId = it.id, name = it.name,
                        srcSize = it.size, srcWidth = it.width, srcHeight = it.height, srcDurationMs = it.durationMs,
                        srcPath = it.path, srcRelPath = it.relPath, srcDateTaken = it.sortDate,
                        options = s.defaultOptions(), auto = true,
                    )
                })
                SettingsStore.update { st -> st.copy(autoSeenUpTo = fresh.maxOf { it.dateAdded }) }
                if (!CompressService.running && !CompressService.start(ctx)) {
                    Notifier.nudge(ctx, "${fresh.size} new video${if (fresh.size == 1) "" else "s"} to compress",
                        "Tap to start. Allow background use in Settings to make this fully automatic.")
                }
            }
        }
        schedule(ctx)
        return Result.success()
    }

    companion object {
        private const val NAME = "auto"

        fun schedule(ctx: Context) {
            val constraints = Constraints.Builder()
                .setRequiresCharging(true)
                .addContentUriTrigger(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true)
                .setTriggerContentUpdateDelay(2, TimeUnit.MINUTES)
                .setTriggerContentMaxDelay(15, TimeUnit.MINUTES)
                .build()
            val req = OneTimeWorkRequestBuilder<AutoWorker>().setConstraints(constraints).build()
            WorkManager.getInstance(ctx).enqueueUniqueWork(NAME, ExistingWorkPolicy.REPLACE, req)
        }

        fun cancel(ctx: Context) { WorkManager.getInstance(ctx).cancelUniqueWork(NAME) }
    }
}

/** After a restart or an app update, picks the queue back up (or asks for a tap if Android insists). */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        Jobs.requeueInterrupted()
        if (SettingsStore.value.autoMode) AutoWorker.schedule(ctx)
        if (Jobs.hasWork) {
            if (SettingsStore.value.overnight) ChargeWorker.schedule(ctx)
            else if (!CompressService.start(ctx)) {
                val n = Jobs.value.count { !it.finished }
                Notifier.nudge(ctx, "$n video${if (n == 1) "" else "s"} did not finish", "Tap to carry on compressing.")
            }
        }
    }
}

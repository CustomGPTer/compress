package uk.jj.compress.engine

import android.content.Context
import android.system.Os
import android.system.OsConstants
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.concurrent.thread

/**
 * The slow engine: FFmpeg with the x264 / x265 software encoders, shipped inside the app
 * as a separate program and run as a child process.
 */
class SoftEngine(private val ctx: Context) {

    @Volatile private var process: Process? = null
    @Volatile private var paused = false

    private val binary: File get() = File(ctx.applicationInfo.nativeLibraryDir, "libffmpeg.so")

    fun isAvailable(): Boolean = binary.exists() && binary.canExecute()

    private fun pid(p: Process): Int {
        Regex("pid=(\\d+)").find(p.toString())?.let { return it.groupValues[1].toInt() }
        return runCatching {
            val f = p.javaClass.getDeclaredField("pid"); f.isAccessible = true; f.getInt(p)
        }.getOrDefault(-1)
    }

    /** Freezes the encoder where it is. Nothing is lost; [resume] carries on from the same frame. */
    fun pause() {
        val p = process ?: return
        val id = pid(p)
        if (id > 0 && !paused) runCatching { Os.kill(id, OsConstants.SIGSTOP); paused = true }
    }

    fun resume() {
        val p = process ?: return
        val id = pid(p)
        if (id > 0 && paused) runCatching { Os.kill(id, OsConstants.SIGCONT) }
        paused = false
    }

    /**
     * @param outDurationMs length of the finished video, used to turn FFmpeg's clock into a percentage.
     * @param onProgress called with 0..1.
     */
    suspend fun run(args: List<String>, outDurationMs: Long, onProgress: (Float) -> Unit): EngineResult =
        withContext(Dispatchers.IO) {
            if (!isAvailable()) return@withContext EngineResult(false, "The Max quality encoder is missing from this install.")
            val cmd = listOf(binary.absolutePath) + args
            val pb = ProcessBuilder(cmd).directory(ctx.cacheDir)
            pb.environment()["HOME"] = ctx.cacheDir.absolutePath
            pb.environment()["TMPDIR"] = ctx.cacheDir.absolutePath
            val p = try { pb.start() } catch (e: Exception) {
                return@withContext EngineResult(false, "The Max quality encoder could not be started on this phone.")
            }
            process = p; paused = false
            val watcher = launch {
                try { awaitCancellation() } finally {
                    runCatching { resume() }
                    runCatching { p.destroy() }
                }
            }
            val errTail = StringBuilder()
            val errThread = thread(name = "soft-err") {
                runCatching {
                    p.errorStream.bufferedReader().forEachLine { line ->
                        synchronized(errTail) {
                            errTail.append(line).append('\n')
                            if (errTail.length > 6000) errTail.delete(0, errTail.length - 4000)
                        }
                    }
                }
            }
            runCatching {
                p.inputStream.bufferedReader().forEachLine { line ->
                    if (line.startsWith("out_time_us=") || line.startsWith("out_time_ms=")) {
                        val us = line.substringAfter('=').trim().toLongOrNull()
                        if (us != null && us > 0 && outDurationMs > 0) {
                            onProgress((us / 1000f / outDurationMs).coerceIn(0f, 1f))
                        }
                    }
                }
            }
            val code = runCatching { p.waitFor() }.getOrDefault(-1)
            runCatching { errThread.join(1500) }
            watcher.cancel()
            process = null
            if (code == 0) EngineResult(true)
            else {
                val tail = synchronized(errTail) { errTail.toString() }
                EngineResult(false, explain(tail))
            }
        }

    private fun explain(log: String): String {
        val l = log.lowercase()
        return when {
            "no such file" in l || "permission denied" in l -> "The Max quality encoder could not read this video."
            "no space left" in l -> "The phone ran out of storage space."
            "invalid data" in l || "moov atom not found" in l -> "This video file looks damaged."
            else -> {
                val last = log.trim().lines().lastOrNull { it.isNotBlank() }?.take(140)
                "The Max quality encoder stopped" + if (last != null) ": $last" else "."
            }
        }
    }
}

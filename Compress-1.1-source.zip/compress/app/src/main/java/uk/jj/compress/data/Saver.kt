package uk.jj.compress.data

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Moves a finished file out of the app's work folder into the phone's shared storage. */
object Saver {

    fun workDir(ctx: Context): File {
        val d = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "work")
        d.mkdirs()
        return d
    }

    fun clearWorkDir(ctx: Context) {
        workDir(ctx).listFiles()?.forEach { runCatching { it.deleteRecursively() } }
    }

    fun freeBytes(ctx: Context): Long = runCatching { workDir(ctx).usableSpace }.getOrDefault(Long.MAX_VALUE)

    private val videoRoots = listOf(Environment.DIRECTORY_MOVIES, Environment.DIRECTORY_DCIM, Environment.DIRECTORY_PICTURES)

    /** Android only lets apps add videos under Movies, DCIM or Pictures. */
    fun videoFolder(setting: String, srcRelPath: String): String {
        val wanted = if (setting == Settings.BESIDE) srcRelPath else setting
        val clean = wanted.trim().trim('/').replace(Regex("/+"), "/")
        val root = clean.substringBefore('/')
        return if (clean.isNotEmpty() && videoRoots.any { it.equals(root, ignoreCase = true) }) clean
        else Settings.DEFAULT_FOLDER
    }

    fun outputName(source: String, suffix: String, extension: String): String {
        val base = source.substringBeforeLast('.', source).ifBlank { "video" }
        val safe = base.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(120)
        return safe + suffix.replace(Regex("[\\\\/:*?\"<>|]"), "_") + "." + extension
    }

    data class Saved(val uri: Uri, val id: Long, val size: Long, val name: String)

    /**
     * @param kind "video", "audio" or "image" (for GIFs).
     * @param dateTakenMs when the original was shot, so the copy sorts beside it in Gallery.
     */
    fun publish(ctx: Context, temp: File, name: String, mime: String, folder: String, kind: String, dateTakenMs: Long): Saved? {
        val resolver = ctx.contentResolver
        val collection = when (kind) {
            "audio" -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            "image" -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
            if (dateTakenMs > 0 && kind != "audio") put(MediaStore.MediaColumns.DATE_TAKEN, dateTakenMs)
        }
        val uri = runCatching { resolver.insert(collection, values) }.getOrNull() ?: return null
        return try {
            resolver.openOutputStream(uri, "w")!!.use { out -> temp.inputStream().use { it.copyTo(out, 1 shl 20) } }
            val done = ContentValues().apply {
                put(MediaStore.MediaColumns.IS_PENDING, 0)
                if (dateTakenMs > 0 && kind != "audio") put(MediaStore.MediaColumns.DATE_TAKEN, dateTakenMs)
            }
            resolver.update(uri, done, null, null)
            var shown = name
            resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) shown = it.getString(0) ?: name
            }
            Saved(uri, ContentUris.parseId(uri), temp.length(), shown)
        } catch (e: Exception) {
            runCatching { resolver.delete(uri, null, null) }
            null
        }
    }

    /**
     * Opens the new file the way a player would: reads its length and decodes a frame.
     * @return null when it is fine, otherwise what is wrong.
     */
    fun verify(file: File, expectDurationMs: Long, expectVideo: Boolean): String? {
        if (!file.exists() || file.length() < 512) return "The new file is empty."
        if (file.name.endsWith(".gif")) return null
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0
            if (dur <= 0) return "The new file has no length."
            if (expectDurationMs > 2000) {
                val slack = maxOf(1500L, expectDurationMs / 20)
                if (dur < expectDurationMs - slack) return "The new file is shorter than it should be."
            }
            if (expectVideo) {
                if (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) != "yes") return "The new file has no picture."
                val frame = r.getFrameAtTime(minOf(dur, 1000L) * 500, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: return "The new file could not be played back."
                frame.recycle()
            }
            null
        } catch (e: Exception) {
            "The new file could not be opened."
        } finally {
            runCatching { r.release() }
        }
    }
}

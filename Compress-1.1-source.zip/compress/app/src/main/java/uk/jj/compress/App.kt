package uk.jj.compress

import android.app.Application
import uk.jj.compress.data.Jobs
import uk.jj.compress.data.Ledger
import uk.jj.compress.data.SettingsStore
import uk.jj.compress.service.Notifier

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        SettingsStore.init(this)
        Jobs.init(this)
        Ledger.init(this)
        Notifier.createChannels(this)
    }
}

package uk.jj.compress.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import uk.jj.compress.engine.AudioMode
import uk.jj.compress.engine.Codec
import uk.jj.compress.engine.Engine
import uk.jj.compress.engine.HdrMode
import uk.jj.compress.engine.Options
import uk.jj.compress.engine.Preset

data class Settings(
    val codec: Codec = Codec.HEVC,
    val engine: Engine = Engine.FAST,
    val preset: Preset = Preset.HIGH,
    val audio: AudioMode = AudioMode.KEEP,
    val keepInfo: Boolean = true,
    val stripLocation: Boolean = false,
    val hdr: HdrMode = HdrMode.KEEP,
    /** A folder such as "Movies/Compress", or [BESIDE] to save next to the original. */
    val outputFolder: String = DEFAULT_FOLDER,
    val nameSuffix: String = "_compressed",
    val replaceOriginals: Boolean = false,
    val continueIfBigger: Boolean = false,
    /** Queue only runs while the phone is on charge. */
    val overnight: Boolean = false,
    /** New camera videos are compressed by themselves while on charge. */
    val autoMode: Boolean = false,
    val autoMinMb: Int = 50,
    val pauseWhenHotOrLow: Boolean = true,
    val tally: Boolean = false,
    val updateCheck: Boolean = true,
    /** Megapixels a second this phone manages, learned from finished jobs. */
    val speedFast: Float = 180f,
    val speedMax: Float = 12f,
    val lastUpdateCheck: Long = 0,
    /** Newest camera video (seconds since 1970) already looked at by automatic mode. */
    val autoSeenUpTo: Long = 0,
    val introSeen: Boolean = false,
) {
    fun defaultOptions() = Options(
        codec = codec, engine = engine, preset = preset, audio = audio,
        keepInfo = keepInfo, stripLocation = stripLocation, hdr = hdr,
    )

    companion object {
        const val DEFAULT_FOLDER = "Movies/Compress"
        const val BESIDE = "beside"
    }
}

object SettingsStore {
    private const val FILE = "settings"
    private val state = MutableStateFlow(Settings())
    val flow: StateFlow<Settings> get() = state
    val value: Settings get() = state.value
    private lateinit var app: Context

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val raw = app.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("json", null)
        if (raw != null) runCatching { state.value = parse(JSONObject(raw)) }
    }

    @Synchronized
    fun update(change: (Settings) -> Settings) {
        val next = change(state.value)
        state.value = next
        app.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("json", write(next).toString()).apply()
    }

    private inline fun <reified T : Enum<T>> JSONObject.e(key: String, d: T): T =
        runCatching { enumValueOf<T>(optString(key, d.name)) }.getOrDefault(d)

    private fun parse(o: JSONObject): Settings {
        val d = Settings()
        return Settings(
            codec = o.e("codec", d.codec), engine = o.e("engine", d.engine), preset = o.e("preset", d.preset),
            audio = o.e("audio", d.audio), keepInfo = o.optBoolean("keepInfo", d.keepInfo),
            stripLocation = o.optBoolean("stripLocation", d.stripLocation), hdr = o.e("hdr", d.hdr),
            outputFolder = o.optString("outputFolder", d.outputFolder).ifBlank { d.outputFolder },
            nameSuffix = o.optString("nameSuffix", d.nameSuffix),
            replaceOriginals = o.optBoolean("replaceOriginals", false),
            continueIfBigger = o.optBoolean("continueIfBigger", false),
            overnight = o.optBoolean("overnight", false),
            autoMode = o.optBoolean("autoMode", false),
            autoMinMb = o.optInt("autoMinMb", d.autoMinMb),
            pauseWhenHotOrLow = o.optBoolean("pauseWhenHotOrLow", true),
            tally = o.optBoolean("tally", false),
            updateCheck = o.optBoolean("updateCheck", true),
            speedFast = o.optDouble("speedFast", d.speedFast.toDouble()).toFloat(),
            speedMax = o.optDouble("speedMax", d.speedMax.toDouble()).toFloat(),
            lastUpdateCheck = o.optLong("lastUpdateCheck", 0),
            autoSeenUpTo = o.optLong("autoSeenUpTo", 0),
            introSeen = o.optBoolean("introSeen", false),
        )
    }

    private fun write(s: Settings) = JSONObject().apply {
        put("codec", s.codec.name); put("engine", s.engine.name); put("preset", s.preset.name)
        put("audio", s.audio.name); put("keepInfo", s.keepInfo); put("stripLocation", s.stripLocation)
        put("hdr", s.hdr.name); put("outputFolder", s.outputFolder); put("nameSuffix", s.nameSuffix)
        put("replaceOriginals", s.replaceOriginals); put("continueIfBigger", s.continueIfBigger)
        put("overnight", s.overnight); put("autoMode", s.autoMode); put("autoMinMb", s.autoMinMb)
        put("pauseWhenHotOrLow", s.pauseWhenHotOrLow); put("tally", s.tally); put("updateCheck", s.updateCheck)
        put("speedFast", s.speedFast.toDouble()); put("speedMax", s.speedMax.toDouble())
        put("lastUpdateCheck", s.lastUpdateCheck); put("autoSeenUpTo", s.autoSeenUpTo); put("introSeen", s.introSeen)
    }
}

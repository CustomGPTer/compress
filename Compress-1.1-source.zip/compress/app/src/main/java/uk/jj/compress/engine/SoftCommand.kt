package uk.jj.compress.engine

import java.util.Locale

/**
 * Builds the command lines for the software encoder (FFmpeg with x264 / x265).
 * Pure string work, so it is unit tested against a desktop copy of FFmpeg.
 */
object SoftCommand {

    private fun n(v: Double) = String.format(Locale.US, "%.4f", v)
    private fun secs(ms: Long) = String.format(Locale.US, "%.3f", ms / 1000.0)

    private val mp4Audio = setOf("audio/mp4a-latm", "audio/ac3", "audio/eac3", "audio/mpeg", "audio/opus")

    private fun head(input: String, src: SourceInfo, opt: Options): MutableList<String> {
        val a = mutableListOf("-hide_banner", "-nostdin", "-y")
        if (opt.hasTrim) {
            val end = if (opt.trimEndMs > 0) minOf(opt.trimEndMs, src.durationMs) else src.durationMs
            val start = opt.trimStartMs.coerceIn(0, end)
            a += listOf("-ss", secs(start), "-t", secs(end - start))
        }
        a += listOf("-i", input)
        return a
    }

    /** Picture filters in the order they are applied to the upright frame. */
    fun videoFilters(opt: Options, plan: Plan, src: SourceInfo): String {
        val f = mutableListOf<String>()
        opt.crop?.takeIf { !it.isFull }?.let {
            f += "crop=iw*${n(it.widthFraction.toDouble())}:ih*${n(it.heightFraction.toDouble())}:" +
                "iw*${n(it.left.toDouble())}:ih*${n(it.top.toDouble())}"
        }
        when (opt.rotate) {
            90 -> f += "transpose=1"
            180 -> { f += "hflip"; f += "vflip" }
            270 -> f += "transpose=2"
        }
        if (opt.flip) f += "hflip"
        if (opt.speed != 1f) f += "setpts=PTS/${n(opt.speed.toDouble())}"
        val srcFps = if (src.fps > 1f) src.fps else 30f
        if (opt.fps > 0 || opt.speed != 1f || plan.fps < srcFps - 0.5f) f += "fps=${n(plan.fps.toDouble())}"
        f += "scale=${plan.width}:${plan.height}:flags=lanczos"
        f += "format=yuv420p"
        return f.joinToString(",")
    }

    fun audioFilters(opt: Options): String {
        val f = mutableListOf<String>()
        if (opt.volume != 1f) f += "volume=${n(opt.volume.toDouble())}"
        var s = opt.speed.toDouble()
        if (s != 1.0) {
            // atempo is happiest between 0.5 and 2, so chain it for bigger changes.
            while (s > 2.0) { f += "atempo=2.0"; s /= 2.0 }
            while (s < 0.5) { f += "atempo=0.5"; s /= 0.5 }
            f += "atempo=${n(s)}"
        }
        return f.joinToString(",")
    }

    /**
     * @param pass 0 for a single quality-based run; 1 or 2 for the two runs used to hit a size.
     */
    fun video(
        input: String, output: String, src: SourceInfo, opt: Options, plan: Plan,
        pass: Int = 0, passLog: String = "",
    ): List<String> {
        val a = head(input, src, opt)
        a += listOf("-map", "0:v:0")
        val sound = plan.audioBitrate > 0 && pass != 1
        if (sound) a += listOf("-map", "0:a:0?")
        a += listOf("-vf", videoFilters(opt, plan, src))

        val byBitrate = pass != 0
        if (opt.codec == Codec.H264) {
            a += listOf("-c:v", "libx264", "-preset", "medium", "-profile:v", "high")
            if (byBitrate) a += listOf("-b:v", plan.videoBitrate.toString(), "-pass", pass.toString(), "-passlogfile", passLog)
            else a += listOf("-crf", plan.crf.toString())
        } else {
            a += listOf("-c:v", "libx265", "-preset", "medium", "-tag:v", "hvc1")
            if (byBitrate) a += listOf("-b:v", plan.videoBitrate.toString(), "-x265-params", "pass=$pass:stats=$passLog:log-level=error")
            else a += listOf("-crf", plan.crf.toString(), "-x265-params", "log-level=error")
        }

        if (!sound) {
            a += "-an"
        } else {
            val af = audioFilters(opt)
            val canCopy = plan.audioCopied && af.isEmpty() && src.audioMime in mp4Audio
            if (canCopy) a += listOf("-c:a", "copy")
            else {
                if (af.isNotEmpty()) a += listOf("-af", af)
                a += listOf("-c:a", "aac", "-b:a", plan.audioBitrate.toString())
            }
        }

        if (opt.keepInfo) a += listOf("-map_metadata", "0") else a += listOf("-map_metadata", "-1")
        if (opt.stripLocation || !opt.keepInfo) {
            a += listOf("-metadata", "location=", "-metadata", "location-eng=",
                "-metadata", "com.apple.quicktime.location.ISO6709=")
        }
        a += listOf("-progress", "pipe:1", "-nostats")
        if (pass == 1) a += listOf("-f", "null", "/dev/null")
        else a += listOf("-movflags", "+faststart", output)
        return a
    }

    fun gif(input: String, output: String, src: SourceInfo, opt: Options): List<String> {
        val a = head(input, src, opt)
        val f = mutableListOf<String>()
        opt.crop?.takeIf { !it.isFull }?.let {
            f += "crop=iw*${n(it.widthFraction.toDouble())}:ih*${n(it.heightFraction.toDouble())}:" +
                "iw*${n(it.left.toDouble())}:ih*${n(it.top.toDouble())}"
        }
        when (opt.rotate) {
            90 -> f += "transpose=1"
            180 -> { f += "hflip"; f += "vflip" }
            270 -> f += "transpose=2"
        }
        if (opt.flip) f += "hflip"
        if (opt.speed != 1f) f += "setpts=PTS/${n(opt.speed.toDouble())}"
        f += "fps=${opt.gifFps.coerceIn(2, 30)}"
        f += "scale='min(${opt.gifWidth.coerceIn(120, 1280)},iw)':-2:flags=lanczos"
        val chain = f.joinToString(",") +
            ",split[a][b];[a]palettegen=stats_mode=diff[p];[b][p]paletteuse=dither=bayer:bayer_scale=5"
        a += listOf("-filter_complex", chain, "-an", "-loop", "0", "-progress", "pipe:1", "-nostats", output)
        return a
    }
}

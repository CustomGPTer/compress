package uk.jj.compress.data

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.LruCache
import android.util.Size
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val size: Long,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    /** Seconds since 1970. */
    val dateAdded: Long,
    /** Milliseconds since 1970, 0 if unknown. */
    val dateTaken: Long,
    val bucket: String,
    val bucketId: Long,
    val relPath: String,
    val path: String?,
) {
    val shortSide get() = minOf(width, height)
    val longSide get() = maxOf(width, height)
    /** Overall bits per second. */
    val bitrate: Long get() = if (durationMs > 0) size * 8000 / durationMs else 0
    val sortDate get() = if (dateTaken > 0) dateTaken else dateAdded * 1000
}

data class Album(val id: Long, val name: String, val count: Int, val size: Long, val cover: VideoItem)

object MediaRepo {

    val collection: Uri
        get() = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)

    @Suppress("DEPRECATION")
    private val projection = arrayOf(
        MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME, MediaStore.Video.Media.SIZE,
        MediaStore.Video.Media.DURATION, MediaStore.Video.Media.WIDTH, MediaStore.Video.Media.HEIGHT,
        MediaStore.Video.Media.DATE_ADDED, MediaStore.Video.Media.DATE_TAKEN,
        MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media.BUCKET_ID,
        MediaStore.Video.Media.RELATIVE_PATH, MediaStore.Video.Media.DATA,
    )

    suspend fun loadAll(ctx: Context): List<VideoItem> = withContext(Dispatchers.IO) { query(ctx, null, null) }

    fun find(ctx: Context, id: Long): VideoItem? =
        query(ctx, "${MediaStore.Video.Media._ID}=?", arrayOf(id.toString())).firstOrNull()

    /** Looks up the library entry behind any video address, when there is one. */
    fun findByUri(ctx: Context, uri: Uri): VideoItem? {
        val id = runCatching { ContentUris.parseId(uri) }.getOrDefault(-1)
        if (id <= 0 || uri.authority != MediaStore.AUTHORITY) return null
        return find(ctx, id)
    }

    fun query(ctx: Context, where: String?, args: Array<String>?): List<VideoItem> {
        val out = ArrayList<VideoItem>()
        runCatching {
            ctx.contentResolver.query(collection, projection, where, args, "${MediaStore.Video.Media.DATE_ADDED} DESC")?.use { c ->
                while (c.moveToNext()) {
                    val id = c.getLong(0)
                    val size = c.getLong(2)
                    if (size <= 0) continue
                    out += VideoItem(
                        id = id,
                        uri = ContentUris.withAppendedId(collection, id),
                        name = c.getString(1) ?: "video",
                        size = size,
                        durationMs = c.getLong(3),
                        width = c.getInt(4), height = c.getInt(5),
                        dateAdded = c.getLong(6), dateTaken = c.getLong(7),
                        bucket = c.getString(8) ?: "Other",
                        bucketId = c.getLong(9),
                        relPath = c.getString(10) ?: "",
                        path = c.getString(11),
                    )
                }
            }
        }
        return out
    }

    fun albums(videos: List<VideoItem>): List<Album> =
        videos.groupBy { it.bucketId }.map { (id, list) ->
            Album(id, list.first().bucket, list.size, list.sumOf { it.size }, list.maxBy { it.sortDate })
        }.sortedBy { it.name.lowercase() }

    private val thumbs = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }

    suspend fun thumbnail(ctx: Context, uri: Uri, px: Int = 320): Bitmap? {
        val key = "$uri@$px"
        thumbs.get(key)?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching { ctx.contentResolver.loadThumbnail(uri, Size(px, px), null) }.getOrNull()
                ?.also { thumbs.put(key, it) }
        }
    }

    fun canReadAll(ctx: Context): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_VIDEO
        else android.Manifest.permission.READ_EXTERNAL_STORAGE
        return ctx.checkSelfPermission(p) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    fun canReadSome(ctx: Context): Boolean = canReadAll(ctx) ||
        (Build.VERSION.SDK_INT >= 34 && ctx.checkSelfPermission(android.Manifest.permission.READ_MEDIA_VISUAL_USER_SELECTED) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED)
}

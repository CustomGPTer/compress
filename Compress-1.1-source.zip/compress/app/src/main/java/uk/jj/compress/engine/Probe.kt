package uk.jj.compress.engine

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns

/** Reads what the app needs to know about a video before planning the job. */
object Probe {

    private fun MediaFormat.int(key: String, fallback: Int = 0): Int = try {
        if (containsKey(key)) getInteger(key) else fallback
    } catch (e: Exception) {
        try { getFloat(key).toInt() } catch (e2: Exception) { fallback }
    }

    private fun MediaFormat.float(key: String, fallback: Float = 0f): Float = try {
        if (containsKey(key)) getFloat(key) else fallback
    } catch (e: Exception) {
        try { getInteger(key).toFloat() } catch (e2: Exception) { fallback }
    }

    private fun MediaFormat.long(key: String, fallback: Long = 0): Long = try {
        if (containsKey(key)) getLong(key) else fallback
    } catch (e: Exception) { fallback }

    fun fileSize(ctx: Context, uri: Uri): Long {
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
            }
        }
        return runCatching {
            ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: 0L
        }.getOrDefault(0L).coerceAtLeast(0)
    }

    fun read(ctx: Context, uri: Uri, sizeHint: Long = 0): SourceInfo? {
        var w = 0; var h = 0; var rot = 0; var fps = 0f; var durMs = 0L
        var vBit = 0; var aBit = 0; var vMime = ""; var aMime = ""; var hdr = false; var hasAudio = false

        val ex = MediaExtractor()
        try {
            ex.setDataSource(ctx, uri, null)
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && vMime.isEmpty()) {
                    vMime = mime
                    w = f.int(MediaFormat.KEY_WIDTH); h = f.int(MediaFormat.KEY_HEIGHT)
                    rot = f.int(MediaFormat.KEY_ROTATION)
                    fps = f.float(MediaFormat.KEY_FRAME_RATE)
                    durMs = f.long(MediaFormat.KEY_DURATION) / 1000
                    vBit = f.int(MediaFormat.KEY_BIT_RATE)
                    val transfer = f.int(MediaFormat.KEY_COLOR_TRANSFER)
                    hdr = transfer == MediaFormat.COLOR_TRANSFER_ST2084 || transfer == MediaFormat.COLOR_TRANSFER_HLG ||
                        mime == "video/dolby-vision"
                } else if (mime.startsWith("audio/") && aMime.isEmpty()) {
                    aMime = mime; hasAudio = true
                    aBit = f.int(MediaFormat.KEY_BIT_RATE)
                    if (durMs == 0L) durMs = f.long(MediaFormat.KEY_DURATION) / 1000
                }
            }
        } catch (e: Exception) {
            // fall through to the retriever
        } finally {
            runCatching { ex.release() }
        }

        var totalBit = 0
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            fun meta(k: Int) = r.extractMetadata(k)
            if (w == 0) w = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            if (h == 0) h = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            if (rot == 0) rot = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (durMs == 0L) durMs = meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0
            totalBit = meta(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 0
            if (fps < 1f && durMs > 0) {
                val frames = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toIntOrNull() ?: 0
                if (frames > 0) fps = frames * 1000f / durMs
            }
            if (fps < 1f) fps = meta(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull() ?: 0f
            if (vMime.isEmpty() && meta(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes") vMime = "video/unknown"
            if (!hasAudio) hasAudio = meta(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
        } catch (e: Exception) {
        } finally {
            runCatching { r.release() }
        }

        if (durMs <= 0 || (vMime.isEmpty() && !hasAudio)) return null
        val size = if (sizeHint > 0) sizeHint else fileSize(ctx, uri)
        if (vBit <= 0) {
            val overall = if (totalBit > 0) totalBit.toLong() else if (size > 0) size * 8000 / durMs else 0
            vBit = (overall - aBit).coerceIn(0, Int.MAX_VALUE.toLong()).toInt()
        }
        if (fps < 1f || fps > 480f) fps = 30f
        val sideways = rot == 90 || rot == 270
        return SourceInfo(
            width = if (sideways) h else w,
            height = if (sideways) w else h,
            fps = fps, durationMs = durMs, sizeBytes = size,
            videoBitrate = vBit, audioBitrate = aBit,
            videoMime = vMime, audioMime = aMime, hasAudio = hasAudio, isHdr = hdr,
        )
    }
}

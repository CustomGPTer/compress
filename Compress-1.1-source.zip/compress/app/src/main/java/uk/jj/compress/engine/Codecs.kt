package uk.jj.compress.engine

import android.media.MediaCodecList

/** Which formats this phone's video chip can write. */
object Codecs {
    private val cache by lazy {
        val infos = runCatching { MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.toList() }.getOrDefault(emptyList())
        Codec.entries.associateWith { codec ->
            infos.any { info ->
                info.isEncoder && info.supportedTypes.any { it.equals(codec.mime, ignoreCase = true) } &&
                    (codec == Codec.H264 || info.isHardwareAccelerated)
            }
        }
    }

    fun onChip(codec: Codec): Boolean = cache[codec] == true

    /** Formats offered for an engine. The software encoder writes HEVC and H.264 only. */
    fun available(engine: Engine): List<Codec> = when (engine) {
        Engine.MAX -> listOf(Codec.HEVC, Codec.H264)
        Engine.FAST -> Codec.entries.filter { onChip(it) }.ifEmpty { listOf(Codec.H264) }
    }

    fun bestFor(wanted: Codec, engine: Engine): Codec {
        val list = available(engine)
        return if (wanted in list) wanted else if (Codec.HEVC in list) Codec.HEVC else list.first()
    }
}

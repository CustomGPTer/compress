package uk.jj.compress.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import uk.jj.compress.engine.Options
import java.io.File
import java.util.UUID

enum class JobState { QUEUED, RUNNING, DONE, SKIPPED, FAILED, CANCELLED }

data class Job(
    val id: String = UUID.randomUUID().toString(),
    /** Jobs started together share a batch number (the time they were queued). */
    val batch: Long,
    /** One address, or several when clips are being joined. */
    val sources: List<String>,
    val sourceId: Long = -1,
    val name: String,
    val srcSize: Long,
    val srcWidth: Int = 0,
    val srcHeight: Int = 0,
    val srcDurationMs: Long = 0,
    val srcPath: String? = null,
    val srcRelPath: String = "",
    val srcDateTaken: Long = 0,
    val options: Options,
    val state: JobState = JobState.QUEUED,
    val progress: Int = 0,
    val message: String? = null,
    val note: String? = null,
    val outUri: String? = null,
    val outName: String? = null,
    val outSize: Long = 0,
    val outWidth: Int = 0,
    val outHeight: Int = 0,
    val startedAt: Long = 0,
    val finishedAt: Long = 0,
    val auto: Boolean = false,
    val predictedBytes: Long = 0,
    /** The original is waiting to be moved to the bin (needs a tap from the user). */
    val replacePending: Boolean = false,
    val originalBinned: Boolean = false,
) {
    val finished get() = state != JobState.QUEUED && state != JobState.RUNNING
    val saved get() = if (state == JobState.DONE && options.tool == uk.jj.compress.engine.Tool.COMPRESS) (srcSize - outSize).coerceAtLeast(0) else 0

    fun toJson() = JSONObject().apply {
        put("id", id); put("batch", batch); put("sources", JSONArray(sources)); put("sourceId", sourceId)
        put("name", name); put("srcSize", srcSize); put("srcWidth", srcWidth); put("srcHeight", srcHeight)
        put("srcDurationMs", srcDurationMs); put("srcPath", srcPath ?: JSONObject.NULL); put("srcRelPath", srcRelPath)
        put("srcDateTaken", srcDateTaken); put("options", options.toJson()); put("state", state.name)
        put("message", message ?: JSONObject.NULL); put("note", note ?: JSONObject.NULL)
        put("outUri", outUri ?: JSONObject.NULL); put("outName", outName ?: JSONObject.NULL)
        put("outSize", outSize); put("outWidth", outWidth); put("outHeight", outHeight)
        put("startedAt", startedAt); put("finishedAt", finishedAt); put("auto", auto)
        put("predictedBytes", predictedBytes); put("replacePending", replacePending); put("originalBinned", originalBinned)
    }

    companion object {
        private fun JSONObject.str(k: String): String? = if (isNull(k)) null else optString(k)
        fun fromJson(o: JSONObject): Job {
            val src = o.optJSONArray("sources") ?: JSONArray()
            return Job(
                id = o.getString("id"), batch = o.optLong("batch"),
                sources = (0 until src.length()).map { src.getString(it) },
                sourceId = o.optLong("sourceId", -1), name = o.optString("name"),
                srcSize = o.optLong("srcSize"), srcWidth = o.optInt("srcWidth"), srcHeight = o.optInt("srcHeight"),
                srcDurationMs = o.optLong("srcDurationMs"), srcPath = o.str("srcPath"),
                srcRelPath = o.optString("srcRelPath"), srcDateTaken = o.optLong("srcDateTaken"),
                options = Options.fromJson(o.optJSONObject("options") ?: JSONObject()),
                state = runCatching { JobState.valueOf(o.optString("state")) }.getOrDefault(JobState.FAILED),
                message = o.str("message"), note = o.str("note"), outUri = o.str("outUri"), outName = o.str("outName"),
                outSize = o.optLong("outSize"), outWidth = o.optInt("outWidth"), outHeight = o.optInt("outHeight"),
                startedAt = o.optLong("startedAt"), finishedAt = o.optLong("finishedAt"), auto = o.optBoolean("auto"),
                predictedBytes = o.optLong("predictedBytes"), replacePending = o.optBoolean("replacePending"),
                originalBinned = o.optBoolean("originalBinned"),
            )
        }
    }
}

/** The work queue. Kept on disk so a crash, a call or a restart does not lose it. */
object Jobs {
    private val state = MutableStateFlow<List<Job>>(emptyList())
    val flow: StateFlow<List<Job>> get() = state
    val value: List<Job> get() = state.value
    private lateinit var file: File

    /** What the service is doing right now, in words, for the progress screen and notification. */
    val status = MutableStateFlow("")
    /** Seconds left on the current video, or -1. */
    val etaSeconds = MutableStateFlow(-1L)

    fun init(ctx: Context) {
        file = File(ctx.filesDir, "jobs.json")
        state.value = runCatching {
            val a = JSONArray(file.readText())
            (0 until a.length()).map { Job.fromJson(a.getJSONObject(it)) }
        }.getOrDefault(emptyList())
    }

    @Synchronized private fun save() {
        runCatching {
            val a = JSONArray(); state.value.forEach { a.put(it.toJson()) }
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(a.toString()); tmp.renameTo(file)
        }
    }

    @Synchronized fun add(jobs: List<Job>) { state.value = state.value + jobs; save() }

    @Synchronized fun update(id: String, persist: Boolean = true, change: (Job) -> Job) {
        state.value = state.value.map { if (it.id == id) change(it) else it }
        if (persist) save()
    }

    fun get(id: String): Job? = state.value.firstOrNull { it.id == id }

    fun next(): Job? = state.value.firstOrNull { it.state == JobState.QUEUED }

    val hasWork: Boolean get() = state.value.any { !it.finished }

    /** After a crash or restart nothing is really running, so put those jobs back in the queue. */
    @Synchronized fun requeueInterrupted() {
        if (state.value.any { it.state == JobState.RUNNING }) {
            state.value = state.value.map { if (it.state == JobState.RUNNING) it.copy(state = JobState.QUEUED, progress = 0) else it }
            save()
        }
    }

    @Synchronized fun cancelAll() {
        state.value = state.value.map {
            if (!it.finished) it.copy(state = JobState.CANCELLED, message = "Cancelled", finishedAt = System.currentTimeMillis()) else it
        }
        save()
    }

    /** Drops finished jobs from earlier batches, keeping any still waiting on a "move to bin" tap. */
    @Synchronized fun forgetOldBatches(keepBatch: Long) {
        state.value = state.value.filter { !it.finished || it.batch == keepBatch || it.replacePending }
        save()
    }

    @Synchronized fun clearFinished() {
        state.value = state.value.filter { !it.finished }
        save()
    }

    fun latestBatch(): Long = state.value.filter { !it.auto }.maxOfOrNull { it.batch } ?: 0
}

/** One line of the optional space-saved history. */
data class HistoryEntry(val at: Long, val name: String, val before: Long, val after: Long)

/**
 * Remembers which library videos have been compressed (so they can be badged and filtered),
 * the optional space-saved history, and what the app has moved to the bin.
 */
object Ledger {
    private lateinit var dir: File
    private val compressed = MutableStateFlow<Map<Long, Long>>(emptyMap())   // source id -> output id
    val compressedFlow: StateFlow<Map<Long, Long>> get() = compressed
    private val history = MutableStateFlow<List<HistoryEntry>>(emptyList())
    val historyFlow: StateFlow<List<HistoryEntry>> get() = history
    private val bin = MutableStateFlow<List<BinEntry>>(emptyList())
    val binFlow: StateFlow<List<BinEntry>> get() = bin

    data class BinEntry(val uri: String, val name: String, val size: Long, val at: Long)

    fun init(ctx: Context) {
        dir = ctx.filesDir
        runCatching {
            val o = JSONObject(File(dir, "ledger.json").readText())
            val c = o.optJSONObject("compressed") ?: JSONObject()
            compressed.value = c.keys().asSequence().associate { it.toLong() to c.optLong(it) }
            val h = o.optJSONArray("history") ?: JSONArray()
            history.value = (0 until h.length()).map { h.getJSONObject(it) }.map {
                HistoryEntry(it.optLong("at"), it.optString("name"), it.optLong("before"), it.optLong("after"))
            }
            val b = o.optJSONArray("bin") ?: JSONArray()
            bin.value = (0 until b.length()).map { b.getJSONObject(it) }.map {
                BinEntry(it.optString("uri"), it.optString("name"), it.optLong("size"), it.optLong("at"))
            }
        }
    }

    @Synchronized private fun save() {
        runCatching {
            val o = JSONObject()
            o.put("compressed", JSONObject().apply { compressed.value.forEach { (k, v) -> put(k.toString(), v) } })
            o.put("history", JSONArray().apply {
                history.value.forEach { put(JSONObject().put("at", it.at).put("name", it.name).put("before", it.before).put("after", it.after)) }
            })
            o.put("bin", JSONArray().apply {
                bin.value.forEach { put(JSONObject().put("uri", it.uri).put("name", it.name).put("size", it.size).put("at", it.at)) }
            })
            File(dir, "ledger.json").writeText(o.toString())
        }
    }

    @Synchronized fun markCompressed(sourceId: Long, outputId: Long) {
        if (sourceId <= 0) return
        var m = compressed.value + (sourceId to outputId)
        if (m.size > 5000) m = m.entries.drop(m.size - 5000).associate { it.key to it.value }
        compressed.value = m; save()
    }

    fun isSource(id: Long) = compressed.value.containsKey(id)
    fun isOutput(id: Long) = compressed.value.containsValue(id)

    @Synchronized fun addHistory(e: HistoryEntry) {
        history.value = (listOf(e) + history.value).take(500); save()
    }

    @Synchronized fun clearHistory() { history.value = emptyList(); save() }

    @Synchronized fun addBin(entries: List<BinEntry>) {
        val fresh = entries.distinctBy { it.uri }
        val uris = fresh.map { it.uri }.toSet()
        bin.value = fresh + bin.value.filter { it.uri !in uris }; save()
    }
    @Synchronized fun removeBin(uris: Collection<String>) { bin.value = bin.value.filter { it.uri !in uris }; save() }
}

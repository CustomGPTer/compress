package uk.jj.compress.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Icon

object C {
    val Bg = Color(0xFF0D1014)
    val Surface = Color(0xFF161A20)
    val SurfaceHigh = Color(0xFF1F252D)
    val Outline = Color(0xFF2B333D)
    val Accent = Color(0xFF3DDC97)
    val OnAccent = Color(0xFF04130C)
    val AccentDim = Color(0xFF14382A)
    val Blue = Color(0xFF7CC4FF)
    val Warn = Color(0xFFFFC857)
    val Error = Color(0xFFFF7A7A)
    val Text = Color(0xFFE9EEF3)
    val Muted = Color(0xFF9AA6B2)
    val Before = Color(0xFF3A2326)
    val BeforeText = Color(0xFFFFB3B3)
}

private val scheme = darkColorScheme(
    primary = C.Accent, onPrimary = C.OnAccent,
    primaryContainer = C.AccentDim, onPrimaryContainer = C.Accent,
    secondary = C.Blue, onSecondary = Color(0xFF04121F),
    secondaryContainer = C.SurfaceHigh, onSecondaryContainer = C.Text,
    background = C.Bg, onBackground = C.Text,
    surface = C.Bg, onSurface = C.Text,
    surfaceVariant = C.Surface, onSurfaceVariant = C.Muted,
    surfaceContainer = C.Surface, surfaceContainerHigh = C.SurfaceHigh, surfaceContainerHighest = C.SurfaceHigh,
    surfaceContainerLow = C.Surface, surfaceContainerLowest = C.Bg,
    outline = C.Outline, outlineVariant = C.Outline,
    error = C.Error, onError = Color(0xFF2A0606),
)

private val type = Typography().let {
    it.copy(
        headlineSmall = it.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
        titleLarge = it.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = it.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        titleSmall = it.titleSmall.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = it.labelLarge.copy(fontWeight = FontWeight.SemiBold),
    )
}

@Composable
fun CompressTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = type, content = content)
}

@Composable
fun Card(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val m = modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(C.Surface)
        .let { if (onClick != null) it.clickable(onClick = onClick) else it }
    Column(m.padding(16.dp), content = content)
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), modifier = modifier.padding(start = 4.dp, top = 8.dp, bottom = 2.dp),
        style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp), color = C.Muted)
}

@Composable
fun Hint(text: String, modifier: Modifier = Modifier, color: Color = C.Muted) {
    Text(text, modifier = modifier, style = MaterialTheme.typography.bodySmall, color = color)
}

/** A selectable pill. */
@Composable
fun Pill(label: String, selected: Boolean, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Surface(
        modifier = modifier,
        onClick = onClick, enabled = enabled,
        shape = RoundedCornerShape(50),
        color = if (selected) C.Accent else C.SurfaceHigh,
        contentColor = if (selected) C.OnAccent else if (enabled) C.Text else C.Muted.copy(alpha = 0.5f),
        border = if (selected) null else BorderStroke(1.dp, C.Outline),
    ) {
        Text(label, Modifier.padding(horizontal = 14.dp, vertical = 8.dp), style = MaterialTheme.typography.labelLarge, maxLines = 1)
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String? = null, checked: Boolean, enabled: Boolean = true, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!checked) }.padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = if (enabled) C.Text else C.Muted)
            if (subtitle != null) Hint(subtitle, Modifier.padding(top = 2.dp))
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled,
            colors = SwitchDefaults.colors(checkedTrackColor = C.Accent, checkedThumbColor = C.OnAccent,
                uncheckedTrackColor = C.SurfaceHigh, uncheckedBorderColor = C.Outline, uncheckedThumbColor = C.Muted))
    }
}

@Composable
fun ValueRow(title: String, value: String, subtitle: String? = null, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) { Icon(icon, null, tint = C.Muted, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(14.dp)) }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            if (subtitle != null) Hint(subtitle, Modifier.padding(top = 2.dp))
        }
        if (value.isNotEmpty()) {
            Spacer(Modifier.width(12.dp))
            Text(value, style = MaterialTheme.typography.bodyMedium, color = C.Accent, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun Dot(color: Color, modifier: Modifier = Modifier) {
    Spacer(modifier.size(8.dp).clip(CircleShape).background(color))
}

@Composable
fun PillRow(content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
    ) { content() }
}

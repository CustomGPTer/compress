package uk.jj.compress

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.mutableStateListOf
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import uk.jj.compress.data.Jobs
import uk.jj.compress.data.SettingsStore
import uk.jj.compress.service.AutoWorker
import uk.jj.compress.service.CompressService
import uk.jj.compress.ui.AppModel
import uk.jj.compress.ui.BinScreen
import uk.jj.compress.ui.CompareScreen
import uk.jj.compress.ui.CompressTheme
import uk.jj.compress.ui.HistoryScreen
import uk.jj.compress.ui.HomeScreen
import uk.jj.compress.ui.LicencesScreen
import uk.jj.compress.ui.MoreAppsScreen
import uk.jj.compress.ui.OptionsScreen
import uk.jj.compress.ui.ProgressScreen
import uk.jj.compress.ui.ResultsScreen
import uk.jj.compress.ui.SettingsScreen

sealed class Screen {
    data object Home : Screen()
    data object Options : Screen()
    data object Progress : Screen()
    data object Results : Screen()
    data class Compare(val jobId: String) : Screen()
    data object Settings : Screen()
    data object History : Screen()
    data object Bin : Screen()
    data object MoreApps : Screen()
    data object Licences : Screen()
}

/** A small back stack. Home is always at the bottom. */
object Nav {
    val stack = mutableStateListOf<Screen>(Screen.Home)
    val current: Screen get() = stack.last()
    fun push(s: Screen) { if (stack.last() != s) stack.add(s) }
    fun back(): Boolean = if (stack.size > 1) { stack.removeAt(stack.lastIndex); true } else false
    fun home() { while (stack.size > 1) stack.removeAt(stack.lastIndex) }
    /** Home with one screen on top of it. */
    fun show(s: Screen) { home(); if (s != Screen.Home) stack.add(s) }
    fun replace(s: Screen) { if (stack.size > 1) stack.removeAt(stack.lastIndex); push(s) }
}

class MainActivity : ComponentActivity() {

    companion object {
        const val ACTION_PROGRESS = "uk.jj.compress.SHOW_PROGRESS"
        const val ACTION_RESULTS = "uk.jj.compress.SHOW_RESULTS"
        const val ACTION_COMPARE = "uk.jj.compress.SHOW_COMPARE"
        const val ACTION_RESUME = "uk.jj.compress.RESUME"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        // The app is always dark, so the status bar icons are always light.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            // Pick the queue back up if the app was closed or crashed part-way through.
            if (!CompressService.running) Jobs.requeueInterrupted()
            if (Jobs.hasWork && !CompressService.running && !SettingsStore.value.overnight) CompressService.start(this)
            if (SettingsStore.value.autoMode) AutoWorker.schedule(this)
            handle(intent)
        }
        setContent {
            CompressTheme {
                BackHandler(enabled = Nav.stack.size > 1) { Nav.back() }
                AnimatedContent(targetState = Nav.current, transitionSpec = { fadeIn() togetherWith fadeOut() }, label = "nav") { screen ->
                    when (screen) {
                        Screen.Home -> HomeScreen()
                        Screen.Options -> OptionsScreen()
                        Screen.Progress -> ProgressScreen()
                        Screen.Results -> ResultsScreen()
                        is Screen.Compare -> CompareScreen(screen.jobId)
                        Screen.Settings -> SettingsScreen()
                        Screen.History -> HistoryScreen()
                        Screen.Bin -> BinScreen()
                        Screen.MoreApps -> MoreAppsScreen()
                        Screen.Licences -> LicencesScreen()
                    }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch { AppModel.refresh(this@MainActivity) }
    }

    @Suppress("DEPRECATION")
    private fun sharedUris(intent: Intent): List<Uri> = when (intent.action) {
        Intent.ACTION_SEND -> listOfNotNull(
            if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else intent.getParcelableExtra(Intent.EXTRA_STREAM)
        )
        Intent.ACTION_SEND_MULTIPLE ->
            (if (Build.VERSION.SDK_INT >= 33) intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
            else intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)) ?: emptyList()
        else -> emptyList()
    }

    private fun handle(intent: Intent?) {
        when (intent?.action) {
            Intent.ACTION_SEND, Intent.ACTION_SEND_MULTIPLE -> {
                val uris = sharedUris(intent)
                if (uris.isNotEmpty()) lifecycleScope.launch {
                    val offered = AppModel.setExternal(this@MainActivity, uris)
                    if (offered > AppModel.MAX_PICKS) {
                        Toast.makeText(this@MainActivity, "Three videos at most per go, so the first three were taken.", Toast.LENGTH_LONG).show()
                    }
                    AppModel.resetDraft()
                    Nav.show(Screen.Options)
                }
            }
            ACTION_PROGRESS -> Nav.show(if (Jobs.hasWork) Screen.Progress else Screen.Results)
            ACTION_RESULTS -> Nav.show(Screen.Results)
            ACTION_COMPARE -> {
                val id = intent.getStringExtra("job")
                Nav.show(Screen.Results)
                if (id != null && Jobs.get(id) != null) Nav.push(Screen.Compare(id))
            }
            ACTION_RESUME -> {
                if (Jobs.hasWork) { CompressService.start(this); Nav.show(Screen.Progress) }
            }
        }
    }
}

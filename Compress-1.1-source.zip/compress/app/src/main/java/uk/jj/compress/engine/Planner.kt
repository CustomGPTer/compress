package uk.jj.compress.engine

import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.roundToLong

/**
 * Works out the picture size, bitrates and expected file size for a job.
 * Pure arithmetic with no Android classes, so it can be unit tested.
 */
object Planner {

    const val MIN_VIDEO_BITRATE = 150_000
    private const val PIXELS_1080P = 1920.0 * 1080.0

    /** Megabits per second for HEVC at 1080p, 30 frames a second. */
    private fun baseMbps(p: Preset) = when (p) {
        Preset.IDENTICAL -> 8.0
        Preset.HIGH -> 5.0
        Preset.BALANCED -> 3.0
        Preset.SMALL -> 1.8
    }

    private fun codecFactor(c: Codec) = when (c) {
        Codec.HEVC -> 1.0
        Codec.H264 -> 1.6
        Codec.AV1 -> 0.85
    }

    /** Bigger pictures need fewer bits per pixel, so the bitrate grows slower than the pixel count. */
    fun presetBitrate(codec: Codec, preset: Preset, width: Int, height: Int, fps: Float): Int {
        val pixels = (width.toDouble() * height).coerceAtLeast(1.0)
        val sizeFactor = (pixels / PIXELS_1080P).pow(0.75)
        val fpsFactor = (fps.coerceIn(10f, 120f) / 30.0).pow(0.5)
        val bps = baseMbps(preset) * 1_000_000 * sizeFactor * fpsFactor * codecFactor(codec)
        return bps.roundToInt().coerceAtLeast(MIN_VIDEO_BITRATE)
    }

    fun crf(codec: Codec, preset: Preset): Int {
        val hevc = when (preset) {
            Preset.IDENTICAL -> 20; Preset.HIGH -> 23; Preset.BALANCED -> 26; Preset.SMALL -> 29
        }
        return if (codec == Codec.H264) hevc - 2 else hevc
    }

    private fun even(v: Double) = ((v / 2.0).roundToInt() * 2).coerceAtLeast(2)

    /** Picture size after crop, rotation and scaling. Never scales up. */
    fun outputSize(src: SourceInfo, opt: Options, shortSideOverride: Int = 0): Pair<Int, Int> {
        var w = src.width.toDouble()
        var h = src.height.toDouble()
        opt.crop?.takeIf { !it.isFull }?.let { w *= it.widthFraction; h *= it.heightFraction }
        if (opt.rotate == 90 || opt.rotate == 270) { val t = w; w = h; h = t }
        val wanted = if (shortSideOverride > 0) shortSideOverride else opt.shortSide
        val short = minOf(w, h)
        if (wanted > 0 && wanted < short) {
            val k = wanted / short
            w *= k; h *= k
        }
        return even(w) to even(h)
    }

    fun outputDurationMs(src: SourceInfo, opt: Options): Long {
        val end = if (opt.trimEndMs > 0) minOf(opt.trimEndMs, src.durationMs) else src.durationMs
        val start = opt.trimStartMs.coerceIn(0, end)
        val speed = opt.speed.coerceIn(0.1f, 10f)
        return ((end - start) / speed).roundToLong().coerceAtLeast(1)
    }

    fun outputFps(src: SourceInfo, opt: Options): Float {
        val srcFps = if (src.fps > 1f) src.fps else 30f
        val natural = if (opt.speed < 1f) srcFps * opt.speed else srcFps
        val wanted = if (opt.fps > 0) opt.fps.toFloat() else natural
        return minOf(natural, wanted).coerceAtLeast(1f)
    }

    private val ladder = intArrayOf(2160, 1440, 1080, 720, 540, 480, 360, 240)

    /**
     * @param allowBigger the "Continue even if the file gets bigger" setting.
     */
    fun plan(src: SourceInfo, opt: Options, allowBigger: Boolean = false): Plan {
        val durationMs = outputDurationMs(src, opt)
        val seconds = durationMs / 1000.0
        val fps = outputFps(src, opt)
        var (w, h) = outputSize(src, opt)
        var autoShort = 0

        // Sound
        val audioTouched = opt.volume != 1f || opt.speed != 1f
        val srcAudio = if (src.audioBitrate > 0) src.audioBitrate else 128_000
        val audioBitrate: Int
        val audioCopied: Boolean
        when {
            !src.hasAudio || opt.audio == AudioMode.REMOVE || opt.tool == Tool.GIF -> { audioBitrate = 0; audioCopied = false }
            opt.audio == AudioMode.SHRINK -> { audioBitrate = minOf(opt.audioBitrate, srcAudio); audioCopied = false }
            audioTouched -> { audioBitrate = srcAudio.coerceIn(96_000, 256_000); audioCopied = false }
            else -> { audioBitrate = srcAudio; audioCopied = true }
        }

        if (opt.tool == Tool.AUDIO_ONLY) {
            val bytes = (audioBitrate / 8.0 * seconds * 1.02).roundToLong()
            return Plan(0, 0, 0f, durationMs, 0, audioBitrate, audioCopied, bytes, 0)
        }

        val srcVideo = when {
            src.videoBitrate > 0 -> src.videoBitrate
            src.durationMs > 0 -> ((src.sizeBytes * 8.0 / (src.durationMs / 1000.0)) - srcAudio).roundToInt().coerceAtLeast(0)
            else -> 0
        }
        val changesPicture = opt.hasEdits || opt.fps > 0 || (opt.shortSide > 0 && opt.shortSide < src.shortSide)

        var skip: String? = null
        val videoBitrate: Int
        when {
            opt.manualBitrate > 0 -> videoBitrate = opt.manualBitrate.coerceAtLeast(MIN_VIDEO_BITRATE)

            opt.targetBytes > 0 -> {
                val totalBps = opt.targetBytes * 8.0 / seconds
                // 3% held back for the file wrapper and for encoders that overshoot a little.
                var v = (totalBps * 0.97 - audioBitrate).roundToInt()
                if (!changesPicture && src.sizeBytes in 1..opt.targetBytes) {
                    skip = "Already under ${Format.size(opt.targetBytes)}"
                }
                if (opt.shortSide == 0) {
                    // Too few bits for the picture size looks worse than a smaller, sharper picture.
                    val floor = { ww: Int, hh: Int -> presetBitrate(opt.codec, Preset.SMALL, ww, hh, fps) * 0.6 }
                    if (v < floor(w, h)) {
                        for (step in ladder) {
                            if (step >= minOf(w, h)) continue
                            val (sw, sh) = outputSize(src, opt, step)
                            autoShort = step; w = sw; h = sh
                            if (v >= floor(sw, sh)) break
                        }
                    }
                }
                videoBitrate = v.coerceAtLeast(MIN_VIDEO_BITRATE)
            }

            else -> {
                val wanted = presetBitrate(opt.codec, opt.preset, w, h, fps)
                if (srcVideo > 0 && wanted >= srcVideo * 0.9) {
                    if (!changesPicture && !allowBigger) skip = "Already small for its quality"
                    videoBitrate = minOf(wanted, srcVideo).coerceAtLeast(MIN_VIDEO_BITRATE)
                } else {
                    videoBitrate = wanted
                }
            }
        }

        // The software encoder works to a quality level, and lands a little under the chip's size.
        val effectiveVideo = if (opt.engine == Engine.MAX && opt.targetBytes == 0L && opt.manualBitrate == 0)
            (videoBitrate * 0.75).roundToInt() else videoBitrate
        val bytes = ((effectiveVideo + audioBitrate) / 8.0 * seconds * 1.01).roundToLong()

        if (skip == null && !allowBigger && !changesPicture && opt.targetBytes == 0L &&
            src.sizeBytes > 0 && bytes >= src.sizeBytes * 0.95) {
            skip = "Would not come out smaller"
        }

        return Plan(w, h, fps, durationMs, videoBitrate, audioBitrate, audioCopied, bytes,
            crf(opt.codec, opt.preset), autoShort, skip)
    }

    /** Rough time for the job in seconds, from megapixels handled per second on this phone. */
    fun estimateSeconds(plan: Plan, src: SourceInfo, megapixelsPerSecond: Double): Long {
        if (plan.width == 0) return (plan.durationMs / 1000.0 / 40.0).roundToLong().coerceAtLeast(1)
        val frames = plan.durationMs / 1000.0 * (if (src.fps > 1f) src.fps else 30f)
        // Decoding the original costs time too, so count the larger of the two picture sizes.
        val mp = maxOf(plan.width.toLong() * plan.height, src.width.toLong() * src.height) / 1_000_000.0
        return (frames * mp / megapixelsPerSecond.coerceAtLeast(0.5)).roundToLong().coerceAtLeast(1)
    }
}

object Format {
    fun size(bytes: Long): String {
        val b = bytes.coerceAtLeast(0).toDouble()
        return when {
            b >= 1_000_000_000 -> trim1(b / 1_000_000_000) + " GB"
            b >= 1_000_000 -> (if (b >= 100_000_000) (b / 1_000_000).roundToInt().toString() else trim1(b / 1_000_000)) + " MB"
            b >= 1_000 -> (b / 1_000).roundToInt().toString() + " KB"
            else -> "${bytes.coerceAtLeast(0)} B"
        }
    }

    private fun trim1(v: Double): String {
        val r = (v * 10).roundToInt() / 10.0
        return if (r == r.toLong().toDouble()) r.toLong().toString() else r.toString()
    }

    fun duration(ms: Long): String {
        val total = (ms / 1000).coerceAtLeast(0)
        val h = total / 3600; val m = (total % 3600) / 60; val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    fun eta(seconds: Long): String = when {
        seconds < 5 -> "a few seconds"
        seconds < 60 -> "about ${((seconds + 4) / 5) * 5} seconds"
        seconds < 3600 -> { val m = (seconds + 30) / 60; "about $m minute${if (m == 1L) "" else "s"}" }
        else -> { val h = seconds / 3600; val m = (seconds % 3600) / 60; "about $h h $m min" }
    }

    fun bitrate(bps: Int): String =
        if (bps >= 1_000_000) trim1(bps / 1_000_000.0) + " Mbps" else "${bps / 1000} kbps"

    fun percentSaved(before: Long, after: Long): Int =
        if (before <= 0) 0 else (((before - after) * 100.0) / before).roundToInt()
}

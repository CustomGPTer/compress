package uk.jj.compress.engine

import org.json.JSONObject

/** Video formats the app can write. */
enum class Codec(val mime: String, val label: String, val blurb: String) {
    HEVC("video/hevc", "HEVC", "Half the size of H.264. Plays on phones from about 2017 on."),
    H264("video/avc", "H.264", "Plays on everything. Files about twice the size."),
    AV1("video/av01", "AV1", "Newest and smallest. Needs a recent phone or browser to play."),
}

enum class Preset(val label: String, val blurb: String) {
    IDENTICAL("Visually identical", "Safest. No difference you can see."),
    HIGH("High", "Recommended. Very hard to tell apart."),
    BALANCED("Balanced", "Good for sharing. Slight softening."),
    SMALL("Small", "Smallest file. Visible softening."),
}

/** FAST uses the phone's video chip. MAX uses the slow software encoder. */
enum class Engine(val label: String) { FAST("Fast"), MAX("Max quality") }

enum class AudioMode(val label: String) { KEEP("Keep as it is"), SHRINK("Shrink"), REMOVE("Remove") }

enum class HdrMode(val label: String) { KEEP("Keep HDR"), TO_SDR("Convert to normal") }

enum class Tool { COMPRESS, JOIN, GIF, AUDIO_ONLY }

/** Crop as fractions of the upright picture, 0..1 from the top-left corner. */
data class CropRect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val widthFraction get() = (right - left).coerceIn(0.01f, 1f)
    val heightFraction get() = (bottom - top).coerceIn(0.01f, 1f)
    val isFull get() = left <= 0.001f && top <= 0.001f && right >= 0.999f && bottom >= 0.999f
}

data class Options(
    val tool: Tool = Tool.COMPRESS,
    val codec: Codec = Codec.HEVC,
    val engine: Engine = Engine.FAST,
    val preset: Preset = Preset.HIGH,
    /** Size to aim for in bytes, 0 for none. Wins over [preset]. */
    val targetBytes: Long = 0,
    /** Video bitrate set by hand in bits per second, 0 for none. Wins over everything. */
    val manualBitrate: Int = 0,
    /** Short side of the picture in pixels (the "p" number), 0 keeps the original. */
    val shortSide: Int = 0,
    /** Frames per second, 0 keeps the original. */
    val fps: Int = 0,
    val audio: AudioMode = AudioMode.KEEP,
    val audioBitrate: Int = 128_000,
    val volume: Float = 1f,
    val trimStartMs: Long = 0,
    /** 0 means "to the end". */
    val trimEndMs: Long = 0,
    val crop: CropRect? = null,
    /** Clockwise quarter turns: 0, 90, 180 or 270. */
    val rotate: Int = 0,
    val flip: Boolean = false,
    val speed: Float = 1f,
    val keepInfo: Boolean = true,
    val stripLocation: Boolean = false,
    val hdr: HdrMode = HdrMode.KEEP,
    val gifFps: Int = 12,
    val gifWidth: Int = 480,
) {
    val hasTrim get() = trimStartMs > 0 || trimEndMs > 0
    val hasCrop get() = crop != null && !crop.isFull
    val hasEdits get() = hasTrim || hasCrop || rotate != 0 || flip || speed != 1f

    fun toJson(): JSONObject = JSONObject().apply {
        put("tool", tool.name); put("codec", codec.name); put("engine", engine.name)
        put("preset", preset.name); put("targetBytes", targetBytes); put("manualBitrate", manualBitrate)
        put("shortSide", shortSide); put("fps", fps); put("audio", audio.name)
        put("audioBitrate", audioBitrate); put("volume", volume.toDouble())
        put("trimStartMs", trimStartMs); put("trimEndMs", trimEndMs)
        crop?.let {
            put("crop", JSONObject().put("l", it.left.toDouble()).put("t", it.top.toDouble())
                .put("r", it.right.toDouble()).put("b", it.bottom.toDouble()))
        }
        put("rotate", rotate); put("flip", flip); put("speed", speed.toDouble())
        put("keepInfo", keepInfo); put("stripLocation", stripLocation); put("hdr", hdr.name)
        put("gifFps", gifFps); put("gifWidth", gifWidth)
    }

    companion object {
        private inline fun <reified T : Enum<T>> JSONObject.enumOr(key: String, fallback: T): T =
            runCatching { enumValueOf<T>(optString(key, fallback.name)) }.getOrDefault(fallback)

        fun fromJson(o: JSONObject): Options {
            val d = Options()
            val c = o.optJSONObject("crop")
            return Options(
                tool = o.enumOr("tool", d.tool),
                codec = o.enumOr("codec", d.codec),
                engine = o.enumOr("engine", d.engine),
                preset = o.enumOr("preset", d.preset),
                targetBytes = o.optLong("targetBytes", 0),
                manualBitrate = o.optInt("manualBitrate", 0),
                shortSide = o.optInt("shortSide", 0),
                fps = o.optInt("fps", 0),
                audio = o.enumOr("audio", d.audio),
                audioBitrate = o.optInt("audioBitrate", d.audioBitrate),
                volume = o.optDouble("volume", 1.0).toFloat(),
                trimStartMs = o.optLong("trimStartMs", 0),
                trimEndMs = o.optLong("trimEndMs", 0),
                crop = c?.let {
                    CropRect(it.optDouble("l", 0.0).toFloat(), it.optDouble("t", 0.0).toFloat(),
                        it.optDouble("r", 1.0).toFloat(), it.optDouble("b", 1.0).toFloat())
                },
                rotate = o.optInt("rotate", 0),
                flip = o.optBoolean("flip", false),
                speed = o.optDouble("speed", 1.0).toFloat(),
                keepInfo = o.optBoolean("keepInfo", true),
                stripLocation = o.optBoolean("stripLocation", false),
                hdr = o.enumOr("hdr", d.hdr),
                gifFps = o.optInt("gifFps", d.gifFps),
                gifWidth = o.optInt("gifWidth", d.gifWidth),
            )
        }
    }
}

/** What is known about a video before it is compressed. Width and height are as the video is shown (upright). */
data class SourceInfo(
    val width: Int,
    val height: Int,
    val fps: Float,
    val durationMs: Long,
    val sizeBytes: Long,
    /** Bits per second, 0 if unknown. */
    val videoBitrate: Int,
    val audioBitrate: Int,
    val videoMime: String = "",
    val audioMime: String = "",
    val hasAudio: Boolean = true,
    val isHdr: Boolean = false,
) {
    val shortSide get() = minOf(width, height)
}

/** The planner's answer: what will be written and how big it should come out. */
data class Plan(
    val width: Int,
    val height: Int,
    val fps: Float,
    val durationMs: Long,
    val videoBitrate: Int,
    /** 0 when there is no sound in the result. */
    val audioBitrate: Int,
    /** True when the sound track is copied across without re-encoding. */
    val audioCopied: Boolean,
    val predictedBytes: Long,
    /** Quality number for the software encoder (lower is better). */
    val crf: Int,
    /** Short side the planner dropped to so a size target stays watchable, or 0. */
    val autoShortSide: Int = 0,
    /** Set when compressing would be pointless; the job is skipped with this reason. */
    val skipReason: String? = null,
)

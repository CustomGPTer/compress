package uk.jj.compress.service

import android.app.Service
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.SystemClock
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uk.jj.compress.data.HistoryEntry
import uk.jj.compress.data.Job
import uk.jj.compress.data.JobState
import uk.jj.compress.data.Jobs
import uk.jj.compress.data.Ledger
import uk.jj.compress.data.Saver
import uk.jj.compress.data.Settings
import uk.jj.compress.data.SettingsStore
import uk.jj.compress.engine.Codec
import uk.jj.compress.engine.Codecs
import uk.jj.compress.engine.Engine
import uk.jj.compress.engine.EngineInput
import uk.jj.compress.engine.EngineResult
import uk.jj.compress.engine.FastEngine
import uk.jj.compress.engine.Format
import uk.jj.compress.engine.HdrMode
import uk.jj.compress.engine.Options
import uk.jj.compress.engine.Plan
import uk.jj.compress.engine.Planner
import uk.jj.compress.engine.Probe
import uk.jj.compress.engine.SoftCommand
import uk.jj.compress.engine.SoftEngine
import uk.jj.compress.engine.SourceInfo
import uk.jj.compress.engine.Tool
import java.io.File
import kotlin.math.roundToInt

/**
 * Runs the queue, one video after another, as a foreground service with a wake lock,
 * so it keeps going with the screen off or the app closed.
 */
class CompressService : Service() {

    companion object {
        const val ACTION_RUN = "uk.jj.compress.RUN"
        const val ACTION_CANCEL = "uk.jj.compress.CANCEL"

        @Volatile var running = false
            private set

        /** @return false when Android refused to start the service from the background. */
        fun start(ctx: Context): Boolean = try {
            ctx.startForegroundService(Intent(ctx, CompressService::class.java).setAction(ACTION_RUN))
            true
        } catch (e: Exception) {
            Jobs.status.value = "Android would not let Compress start (${e.javaClass.simpleName})"
            Jobs.status.value = "Android would not let Compress start (${e.javaClass.simpleName})"
            false
        }

        fun cancel(ctx: Context) {
            Jobs.cancelAll()
            runCatching { ctx.startService(Intent(ctx, CompressService::class.java).setAction(ACTION_CANCEL)) }
        }
    }

    private enum class Gate { CHARGER, HEAT }
    private class Interrupted(val gate: Gate) : Exception()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var loop: kotlinx.coroutines.Job? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private lateinit var fast: FastEngine
    private lateinit var soft: SoftEngine
    private var lastNotify = 0L
    private var position = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        fast = FastEngine(applicationContext)
        soft = SoftEngine(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            Jobs.cancelAll()
            loop?.cancel()
            if (loop == null) { stopSelf(); return START_NOT_STICKY }
            return START_NOT_STICKY
        }
        // Call Android directly here. The support library's helper strips the newer "media processing"
        // type, which makes Android 15 and later refuse to start the service at all.
        val types = buildList {
            if (Build.VERSION.SDK_INT >= 35) add(ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROCESSING)
            add(ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        }
        var shown = false
        var refusal = ""
        for (type in types) {
            try {
                startForeground(Notifier.ID_PROGRESS, Notifier.progress(this, "Getting ready", "Compress", 0, indeterminate = true), type)
                shown = true
                break
            } catch (e: Exception) {
                refusal = e.javaClass.simpleName
            }
        }
        if (!shown) {
            // Android would not let the service run from the background. Ask for a tap instead.
            Jobs.requeueInterrupted()
            Jobs.status.value = "Android would not let Compress start in the background ($refusal)"
            if (Jobs.hasWork) Notifier.nudge(this, "Videos waiting", "Tap to carry on compressing.")
            stopSelf()
            return START_NOT_STICKY
        }
        if (loop?.isActive != true) {
            running = true
            loop = scope.launch { runQueue() }
        }
        return START_STICKY
    }

    override fun onTimeout(startId: Int, fgsType: Int) {
        // Android limits how long this kind of service may run in a day.
        loop?.cancel()
        Jobs.requeueInterrupted()
        if (Jobs.hasWork) Notifier.nudge(this, "Paused by Android", "Tap to carry on compressing.")
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        scope.cancel()
        runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
        super.onDestroy()
    }

    // ---- gates -------------------------------------------------------------------------------

    private fun battery(): Pair<Int, Boolean> {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val plugged = (i?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 100
        return pct to plugged
    }

    private fun tooHot(): Boolean {
        val pm = getSystemService(PowerManager::class.java)
        return pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE
    }

    private fun gate(settings: Settings): Gate? {
        val (pct, plugged) = battery()
        if (settings.overnight && !plugged) return Gate.CHARGER
        if (settings.pauseWhenHotOrLow) {
            if (!plugged && pct < 15) return Gate.CHARGER
            if (tooHot()) return Gate.HEAT
        }
        return null
    }

    private suspend fun waitToCool() {
        Jobs.status.value = "Paused to cool down"
        Jobs.etaSeconds.value = -1
        notifyProgress("Paused to cool down", "Carries on by itself when the phone is cooler", 0, force = true)
        val pm = getSystemService(PowerManager::class.java)
        delay(60_000)
        while (pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) delay(10_000)
    }

    // ---- queue -------------------------------------------------------------------------------

    private suspend fun runQueue() {
        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "compress:queue").apply {
            setReferenceCounted(false); acquire(6 * 60 * 60 * 1000L)
        }
        Notifier.cancel(this, Notifier.ID_NUDGE)
        Jobs.requeueInterrupted()
        var waitingForCharger = false
        val touched = mutableListOf<String>()
        try {
            while (true) {
                val job = Jobs.next() ?: break
                val settings = SettingsStore.value
                when (gate(settings)) {
                    Gate.CHARGER -> { waitingForCharger = true; break }
                    Gate.HEAT -> waitToCool()
                    null -> {}
                }
                runCatching { wakeLock?.acquire(6 * 60 * 60 * 1000L) }   // fresh six hours for each video
                val batchJobs = Jobs.value.filter { it.batch == job.batch }
                position = "${batchJobs.indexOfFirst { it.id == job.id } + 1} of ${batchJobs.size}"
                touched += job.id
                try {
                    process(job)
                } catch (e: Interrupted) {
                    Jobs.update(job.id) { it.copy(state = JobState.QUEUED, progress = 0, message = null) }
                    if (e.gate == Gate.CHARGER) { waitingForCharger = true; break }
                    waitToCool()
                }
            }
        } catch (e: CancellationException) {
            // cancelled by the user: states were already set by cancelAll()
        } finally {
            withContext(kotlinx.coroutines.NonCancellable) {
                Saver.clearWorkDir(applicationContext)
                Jobs.status.value = ""
                Jobs.etaSeconds.value = -1
                runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
                if (waitingForCharger) {
                    ChargeWorker.schedule(applicationContext)
                    val (pct, _) = battery()
                    val why = if (SettingsStore.value.overnight) "Overnight mode is on." else "Battery is at $pct%."
                    Jobs.status.value = "Waiting for the charger"
                    Notifier.nudge(applicationContext, "Waiting for the charger", "$why Compressing starts when the phone is plugged in.")
                } else {
                    val done = Jobs.value.filter { it.id in touched && it.finished && it.state != JobState.CANCELLED }
                    if (done.isNotEmpty()) Notifier.done(applicationContext, done)
                }
                running = false
                ServiceCompat.stopForeground(this@CompressService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun notifyProgress(title: String, text: String, percent: Int, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastNotify < 1000) return
        lastNotify = now
        Notifier.notify(this, Notifier.ID_PROGRESS, Notifier.progress(this, title, text, percent))
    }

    private fun fail(job: Job, message: String) {
        Jobs.update(job.id) { it.copy(state = JobState.FAILED, message = message, finishedAt = System.currentTimeMillis()) }
    }

    private fun skip(job: Job, message: String) {
        Jobs.update(job.id) { it.copy(state = JobState.SKIPPED, message = message, finishedAt = System.currentTimeMillis()) }
    }

    private fun reportProgress(job: Job, percent: Int, startedAt: Long) {
        val p = percent.coerceIn(0, 100)
        Jobs.update(job.id, persist = false) { it.copy(progress = p) }
        val elapsed = (SystemClock.elapsedRealtime() - startedAt) / 1000.0
        val eta = if (p >= 3 && elapsed >= 2) (elapsed * (100 - p) / p).toLong() else -1
        Jobs.etaSeconds.value = eta
        val left = if (eta >= 0) " · ${Format.eta(eta)} left" else ""
        notifyProgress("Compressing $position", "${job.name} · $p%$left", p)
    }

    /** Runs [work] while watching the battery and temperature. */
    private suspend fun guarded(usesSoft: Boolean, work: suspend () -> EngineResult): EngineResult = coroutineScope {
        var interrupted: Gate? = null
        val task = async { work() }
        val monitor = launch {
            while (true) {
                delay(4000)
                val g = gate(SettingsStore.value) ?: continue
                if (g == Gate.HEAT && usesSoft) {
                    // The software encoder can be frozen in place and woken later with nothing lost.
                    soft.pause()
                    waitToCool()
                    soft.resume()
                    Jobs.status.value = "Compressing"
                } else {
                    interrupted = g
                    task.cancel()
                    return@launch
                }
            }
        }
        try {
            task.await()
        } catch (e: CancellationException) {
            ensureActive()
            throw Interrupted(interrupted ?: Gate.HEAT)
        } finally {
            monitor.cancel()
        }
    }

    private suspend fun process(job: Job) {
        val ctx = applicationContext
        val settings = SettingsStore.value
        val startedAt = SystemClock.elapsedRealtime()
        Jobs.update(job.id) { it.copy(state = JobState.RUNNING, progress = 0, message = null, startedAt = System.currentTimeMillis()) }
        Jobs.status.value = "Getting ready"
        Jobs.etaSeconds.value = -1
        notifyProgress("Compressing $position", job.name, 0, force = true)

        // 1. Read the originals.
        val inputs = withContext(Dispatchers.IO) {
            job.sources.map { Uri.parse(it) }.mapNotNull { uri -> Probe.read(ctx, uri)?.let { EngineInput(uri, it) } }
        }
        if (inputs.size != job.sources.size || inputs.isEmpty()) {
            return fail(job, "The video could not be read. It may have been moved or deleted.")
        }
        var opt = job.options
        val joining = opt.tool == Tool.JOIN && inputs.size > 1
        val first = inputs.first().info
        if (opt.tool != Tool.AUDIO_ONLY && first.videoMime.isEmpty()) return fail(job, "This file has no picture to compress.")
        if (opt.tool == Tool.AUDIO_ONLY && !first.hasAudio) return fail(job, "This video has no sound to save.")

        // 2. Choose the engine and make sure the format can be written.
        val wantsSoft = opt.tool == Tool.GIF || (opt.engine == Engine.MAX && opt.tool == Tool.COMPRESS)
        var note: String? = null
        var useSoft = wantsSoft && soft.isAvailable()
        if (opt.tool == Tool.GIF && !useSoft) return fail(job, "GIFs cannot be made on this phone.")
        if (useSoft && opt.tool == Tool.COMPRESS && first.isHdr && opt.hdr == HdrMode.KEEP) {
            useSoft = false
            note = "This is an HDR video, so the Fast engine was used to keep the HDR."
        }
        if (wantsSoft && !useSoft && note == null && opt.tool == Tool.COMPRESS) {
            note = "Max quality is not available on this phone, so the Fast engine was used."
        }
        val engine = if (useSoft) Engine.MAX else Engine.FAST
        val codec = Codecs.bestFor(opt.codec, engine)
        if (codec != opt.codec && opt.tool != Tool.GIF && opt.tool != Tool.AUDIO_ONLY) {
            note = listOfNotNull(note, "${opt.codec.label} is not available here, so ${codec.label} was used.").joinToString(" ")
        }
        opt = opt.copy(engine = engine, codec = codec)

        // 3. Plan it.
        val source: SourceInfo = if (joining) first.copy(
            durationMs = inputs.sumOf { it.info.durationMs }, sizeBytes = inputs.sumOf { it.info.sizeBytes },
            videoBitrate = 0, hasAudio = inputs.any { it.info.hasAudio },
        ) else first
        if (joining) opt = opt.copy(trimStartMs = 0, trimEndMs = 0, crop = null, rotate = 0, flip = false, speed = 1f)
        var plan = Planner.plan(source, opt, allowBigger = settings.continueIfBigger || opt.tool != Tool.COMPRESS)
        if (joining && plan.audioCopied) plan = plan.copy(audioCopied = false, audioBitrate = plan.audioBitrate.coerceIn(96_000, 192_000))
        if (opt.tool == Tool.COMPRESS && plan.skipReason != null) return skip(job, plan.skipReason ?: "Skipped")
        Jobs.update(job.id) { it.copy(predictedBytes = plan.predictedBytes, srcWidth = first.width, srcHeight = first.height, srcDurationMs = source.durationMs) }

        val needed = plan.predictedBytes * 2 + 50_000_000L
        if (Saver.freeBytes(ctx) < needed) {
            return fail(job, "Not enough free space. About ${Format.size(needed)} is needed while compressing.")
        }

        // 4. Compress.
        val work = Saver.workDir(ctx)
        val ext = when (opt.tool) { Tool.GIF -> "gif"; Tool.AUDIO_ONLY -> "m4a"; else -> "mp4" }
        val temp = File(work, "${job.id}.$ext")
        Jobs.status.value = "Compressing"
        var result: EngineResult
        var softInput: File? = null
        var softCopied = false

        if (useSoft) {
            softInput = job.srcPath?.let { File(it) }?.takeIf { it.canRead() }
            if (softInput == null) {
                // The software encoder needs a plain file, so take a private copy first.
                Jobs.status.value = "Copying the video in"
                softInput = File(work, "${job.id}.in")
                softCopied = true
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        contentResolver.openInputStream(inputs.first().uri)!!.use { i -> softInput.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
                    }.isSuccess
                }
                if (!ok) return fail(job, "The video could not be copied in for the Max quality encoder.")
                Jobs.status.value = "Compressing"
            }
            val inPath = softInput.absolutePath
            result = when {
                opt.tool == Tool.GIF -> guarded(true) {
                    soft.run(SoftCommand.gif(inPath, temp.absolutePath, first, opt), plan.durationMs) { reportProgress(job, (it * 100).roundToInt(), startedAt) }
                }
                opt.targetBytes > 0 || opt.manualBitrate > 0 -> {
                    // Two runs: the first measures the video, the second spends the bits where they matter.
                    val log = File(work, "${job.id}.pass").absolutePath
                    val one = guarded(true) {
                        soft.run(SoftCommand.video(inPath, temp.absolutePath, first, opt, plan, 1, log), plan.durationMs) {
                            reportProgress(job, (it * 45).roundToInt(), startedAt)
                        }
                    }
                    if (!one.ok) one else guarded(true) {
                        soft.run(SoftCommand.video(inPath, temp.absolutePath, first, opt, plan, 2, log), plan.durationMs) {
                            reportProgress(job, 45 + (it * 55).roundToInt(), startedAt)
                        }
                    }
                }
                else -> guarded(true) {
                    soft.run(SoftCommand.video(inPath, temp.absolutePath, first, opt, plan), plan.durationMs) { reportProgress(job, (it * 100).roundToInt(), startedAt) }
                }
            }
        } else {
            val run: suspend (Plan, Boolean) -> EngineResult = { p, compat ->
                guarded(false) { fast.run(inputs, temp, opt, p, compat) { reportProgress(job, it, startedAt) } }
            }
            result = run(plan, false)
            if (!result.ok && fast.isMuxError(result.message)) {
                temp.delete()
                result = run(plan, true)
            }
            // Size targets: the chip can overshoot, so check and go again a little lower if it did.
            var tries = 0
            while (result.ok && opt.targetBytes > 0 && temp.length() > opt.targetBytes && tries < 2) {
                tries++
                val scale = opt.targetBytes.toDouble() / temp.length() * 0.96
                plan = plan.copy(videoBitrate = (plan.videoBitrate * scale).roundToInt().coerceAtLeast(Planner.MIN_VIDEO_BITRATE))
                Jobs.status.value = "Trimming to fit the size"
                temp.delete()
                result = run(plan, false)
            }
        }
        if (softCopied) softInput?.delete()
        coroutineScopeActive()

        if (!result.ok) { temp.delete(); return fail(job, result.message ?: "Compressing failed.") }
        note = listOfNotNull(note, result.note).joinToString(" ").ifBlank { null }

        // 5. Check the new file really plays.
        Jobs.status.value = "Checking the new file"
        notifyProgress("Compressing $position", "${job.name} · checking", 100, force = true)
        val expectVideo = opt.tool == Tool.COMPRESS || opt.tool == Tool.JOIN
        val problem = withContext(Dispatchers.IO) { Saver.verify(temp, plan.durationMs, expectVideo) }
        if (problem != null) { temp.delete(); return fail(job, "$problem The original has not been touched.") }

        val outSize = temp.length()
        if (opt.tool == Tool.COMPRESS && !settings.continueIfBigger && !opt.hasEdits && outSize >= job.srcSize && job.srcSize > 0) {
            temp.delete()
            return skip(job, "Came out no smaller, so the original was kept")
        }

        var outW = plan.width; var outH = plan.height
        if (expectVideo) withContext(Dispatchers.IO) {
            val r = MediaMetadataRetriever()
            runCatching {
                r.setDataSource(temp.absolutePath)
                val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (w > 0 && h > 0) { if (rot == 90 || rot == 270) { outW = h; outH = w } else { outW = w; outH = h } }
            }
            runCatching { r.release() }
        }

        // 6. Save it where the user can see it.
        Jobs.status.value = "Saving"
        val suffix = when (opt.tool) { Tool.JOIN -> "_joined"; Tool.GIF, Tool.AUDIO_ONLY -> ""; else -> settings.nameSuffix }
        val name = Saver.outputName(job.name, suffix, ext)
        val saved = withContext(Dispatchers.IO) {
            when (opt.tool) {
                Tool.GIF -> Saver.publish(ctx, temp, name, "image/gif", "Pictures/Compress", "image", job.srcDateTaken)
                Tool.AUDIO_ONLY -> Saver.publish(ctx, temp, name, "audio/mp4", "Music/Compress", "audio", 0)
                else -> Saver.publish(ctx, temp, name, "video/mp4", Saver.videoFolder(settings.outputFolder, job.srcRelPath),
                    "video", if (opt.keepInfo) job.srcDateTaken else 0)
            }
        }
        temp.delete()
        if (saved == null) return fail(job, "The new file could not be saved to your storage.")

        // 7. Book-keeping.
        val seconds = (SystemClock.elapsedRealtime() - startedAt) / 1000.0
        if (expectVideo && seconds > 3 && !joining) {
            val frames = plan.durationMs / 1000.0 * first.fps
            val mp = maxOf(plan.width.toLong() * plan.height, first.width.toLong() * first.height) / 1_000_000.0
            val rate = (frames * mp / seconds).toFloat()
            if (rate > 0.5f) SettingsStore.update { s ->
                if (useSoft) s.copy(speedMax = (s.speedMax * 0.5f + rate * 0.5f)) else s.copy(speedFast = (s.speedFast * 0.5f + rate * 0.5f))
            }
        }
        if (opt.tool == Tool.COMPRESS) {
            Ledger.markCompressed(job.sourceId, saved.id)
            if (settings.tally) Ledger.addHistory(HistoryEntry(System.currentTimeMillis(), job.name, job.srcSize, outSize))
        }
        val replace = settings.replaceOriginals && opt.tool == Tool.COMPRESS && job.sourceId > 0 && !opt.hasEdits && Build.VERSION.SDK_INT >= 30
        Jobs.update(job.id) {
            it.copy(
                state = JobState.DONE, progress = 100, message = null, note = note,
                outUri = saved.uri.toString(), outName = saved.name, outSize = outSize, outWidth = outW, outHeight = outH,
                finishedAt = System.currentTimeMillis(), replacePending = replace, options = opt,
            )
        }
    }

    private suspend fun coroutineScopeActive() = coroutineScope { ensureActive() }
}

package uk.jj.compress.ui

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import uk.jj.compress.engine.CropRect
import uk.jj.compress.engine.SourceInfo
import kotlin.math.roundToInt

/** One upright frame of a video, shrunk to fit [maxSide]. */
suspend fun loadFrame(ctx: Context, uri: Uri, timeMs: Long, maxSide: Int = 1600, exact: Boolean = false): Bitmap? =
    withContext(Dispatchers.IO) {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            r.getScaledFrameAtTime(
                timeMs.coerceAtLeast(0) * 1000,
                if (exact) MediaMetadataRetriever.OPTION_CLOSEST else MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                maxSide, maxSide,
            )
        } catch (e: Exception) {
            null
        } finally {
            runCatching { r.release() }
        }
    }

private val shapes = listOf("16:9" to 16f / 9f, "9:16" to 9f / 16f, "1:1" to 1f, "4:3" to 4f / 3f, "3:4" to 3f / 4f)

@Composable
fun CropDialog(uri: Uri, info: SourceInfo, initial: CropRect?, atMs: Long, onDismiss: () -> Unit, onDone: (CropRect?) -> Unit) {
    val ctx = LocalContext.current
    val frame by produceState<Bitmap?>(null, uri) { value = loadFrame(ctx, uri, if (atMs > 0) atMs else minOf(1000L, info.durationMs / 2), 1280) }
    var l by remember { mutableFloatStateOf(initial?.left ?: 0f) }
    var t by remember { mutableFloatStateOf(initial?.top ?: 0f) }
    var r by remember { mutableFloatStateOf(initial?.right ?: 1f) }
    var b by remember { mutableFloatStateOf(initial?.bottom ?: 1f) }
    val pictureShape = if (info.height > 0) info.width.toFloat() / info.height else 16f / 9f

    fun setShape(shape: Float) {
        // Largest centred box of the wanted shape that fits inside the picture.
        if (shape > pictureShape) { val h = pictureShape / shape; l = 0f; r = 1f; t = (1 - h) / 2; b = t + h }
        else { val w = shape / pictureShape; t = 0f; b = 1f; l = (1 - w) / 2; r = l + w }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(C.Bg).systemBarsPadding().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Crop", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
                TextButton(onClick = { l = 0f; t = 0f; r = 1f; b = 1f }) { Text("Reset") }
            }
            Hint("Drag a corner to resize, or drag inside the box to move it.")
            Spacer(Modifier.size(12.dp))
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val boxShape = maxWidth.value / maxHeight.value
                val w = if (pictureShape > boxShape) maxWidth else maxHeight * pictureShape
                val h = if (pictureShape > boxShape) maxWidth / pictureShape else maxHeight
                Box(Modifier.size(w, h)) {
                    val f = frame
                    if (f != null) Image(f.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                    else Box(Modifier.fillMaxSize().background(C.Surface), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = C.Accent) }
                    Canvas(
                        Modifier.fillMaxSize().pointerInput(Unit) {
                            var mode = 0
                            detectDragGestures(
                                onDragStart = { p ->
                                    val sw = size.width.toFloat(); val sh = size.height.toFloat()
                                    val corners = listOf(Offset(l * sw, t * sh) to 1, Offset(r * sw, t * sh) to 2, Offset(l * sw, b * sh) to 3, Offset(r * sw, b * sh) to 4)
                                    val near = corners.minBy { (it.first - p).getDistance() }
                                    mode = when {
                                        (near.first - p).getDistance() < 44.dp.toPx() -> near.second
                                        p.x in (l * sw)..(r * sw) && p.y in (t * sh)..(b * sh) -> 5
                                        else -> 0
                                    }
                                },
                                onDrag = { change, drag ->
                                    change.consume()
                                    val dx = drag.x / size.width; val dy = drag.y / size.height
                                    val min = 0.1f
                                    when (mode) {
                                        1 -> { l = (l + dx).coerceIn(0f, r - min); t = (t + dy).coerceIn(0f, b - min) }
                                        2 -> { r = (r + dx).coerceIn(l + min, 1f); t = (t + dy).coerceIn(0f, b - min) }
                                        3 -> { l = (l + dx).coerceIn(0f, r - min); b = (b + dy).coerceIn(t + min, 1f) }
                                        4 -> { r = (r + dx).coerceIn(l + min, 1f); b = (b + dy).coerceIn(t + min, 1f) }
                                        5 -> {
                                            val mx = dx.coerceIn(-l, 1f - r); val my = dy.coerceIn(-t, 1f - b)
                                            l += mx; r += mx; t += my; b += my
                                        }
                                    }
                                },
                            )
                        },
                    ) {
                        val sw = size.width; val sh = size.height
                        val shade = Color(0xAA000000)
                        drawRect(shade, Offset.Zero, Size(sw, t * sh))
                        drawRect(shade, Offset(0f, b * sh), Size(sw, sh - b * sh))
                        drawRect(shade, Offset(0f, t * sh), Size(l * sw, (b - t) * sh))
                        drawRect(shade, Offset(r * sw, t * sh), Size(sw - r * sw, (b - t) * sh))
                        drawRect(C.Accent, Offset(l * sw, t * sh), Size((r - l) * sw, (b - t) * sh), style = Stroke(2.dp.toPx()))
                        for (i in 1..2) {
                            val x = (l + (r - l) * i / 3f) * sw; val y = (t + (b - t) * i / 3f) * sh
                            drawLine(Color(0x66FFFFFF), Offset(x, t * sh), Offset(x, b * sh), 1.dp.toPx())
                            drawLine(Color(0x66FFFFFF), Offset(l * sw, y), Offset(r * sw, y), 1.dp.toPx())
                        }
                        listOf(Offset(l * sw, t * sh), Offset(r * sw, t * sh), Offset(l * sw, b * sh), Offset(r * sw, b * sh)).forEach {
                            drawCircle(C.Accent, 9.dp.toPx(), it)
                            drawCircle(C.Bg, 4.dp.toPx(), it)
                        }
                    }
                }
            }
            Spacer(Modifier.size(12.dp))
            val outW = ((r - l) * info.width / 2).roundToInt() * 2
            val outH = ((b - t) * info.height / 2).roundToInt() * 2
            Hint("Keeps $outW×$outH of ${info.width}×${info.height}")
            Spacer(Modifier.size(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                shapes.forEach { (label, shape) -> Pill(label, false) { setShape(shape) } }
            }
            Spacer(Modifier.size(16.dp))
            Row {
                TextButton(onClick = onDismiss) { Text("Cancel", color = C.Muted) }
                Spacer(Modifier.weight(1f))
                Button(
                    onClick = {
                        val rect = CropRect(l, t, r, b)
                        onDone(if (rect.isFull) null else rect)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.OnAccent),
                ) { Text("Done") }
                Spacer(Modifier.width(4.dp))
            }
        }
    }
}

package uk.jj.compress.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import uk.jj.compress.Nav
import uk.jj.compress.Screen
import uk.jj.compress.data.SettingsStore
import uk.jj.compress.engine.AudioMode
import uk.jj.compress.engine.Codec
import uk.jj.compress.engine.Codecs
import uk.jj.compress.engine.Engine
import uk.jj.compress.engine.Format
import uk.jj.compress.engine.HdrMode
import uk.jj.compress.engine.Options
import uk.jj.compress.engine.Plan
import uk.jj.compress.engine.Planner
import uk.jj.compress.engine.Preset
import uk.jj.compress.engine.SoftEngine
import uk.jj.compress.engine.SourceInfo
import uk.jj.compress.engine.Tool
import java.util.Locale
import kotlin.math.roundToInt

private val sizeTargets = listOf("WhatsApp" to 16, "Discord" to 10, "Gmail" to 25)
private val heights = listOf(2160, 1440, 1080, 720, 540, 480, 360, 240)
private val frameRates = listOf(60, 30, 25, 24, 15)
private val speeds = listOf(0.25f, 0.5f, 1f, 1.5f, 2f, 4f)

private fun clock(ms: Long): String {
    val s = ms / 1000.0
    return String.format(Locale.UK, "%d:%04.1f", (s / 60).toInt(), s % 60)
}

/** The options as they will really be used for one of the ticked videos. */
private fun effective(opt: Options, single: Boolean): Options {
    val tool = if (opt.tool == Tool.JOIN) Tool.COMPRESS else opt.tool
    return if (single) opt.copy(tool = tool) else opt.copy(tool = tool, trimStartMs = 0, trimEndMs = 0, crop = null)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OptionsScreen() {
    val ctx = LocalContext.current
    val picks by AppModel.picks.collectAsState()
    val opt by AppModel.draft.collectAsState()
    val infos by AppModel.infos.collectAsState()
    val settings by SettingsStore.flow.collectAsState()
    val softReady = remember { SoftEngine(ctx).isAvailable() }
    fun set(change: (Options) -> Options) { AppModel.draft.value = change(AppModel.draft.value) }

    LaunchedEffect(picks) {
        if (picks.isEmpty()) { if (Nav.current == Screen.Options) Nav.back() } else AppModel.probePicks(ctx)
    }
    if (picks.isEmpty()) return

    val single = picks.size == 1
    val firstInfo: SourceInfo? = infos[picks.first().uri.toString()]
    val known = picks.mapNotNull { p -> infos[p.uri.toString()]?.let { p to it } }
    val reading = picks.any { !infos.containsKey(it.uri.toString()) }
    val unreadable = picks.filter { infos.containsKey(it.uri.toString()) && infos[it.uri.toString()] == null }
    val eff = effective(opt, single)
    val allowBigger = settings.continueIfBigger || opt.tool != Tool.COMPRESS
    val plans: List<Triple<Pick, SourceInfo, Plan>> = known.map { (p, i) -> Triple(p, i, Planner.plan(i, eff, allowBigger)) }
    val anyHdr = known.any { it.second.isHdr }
    val minShort = known.minOfOrNull { it.second.shortSide } ?: 0
    val maxFps = known.maxOfOrNull { it.second.fps } ?: 0f

    var customSize by remember { mutableStateOf(false) }
    var customHeight by remember { mutableStateOf(false) }
    var cropOpen by remember { mutableStateOf(false) }
    var advanced by remember { mutableStateOf(opt.manualBitrate > 0) }

    val joining = opt.tool == Tool.JOIN && picks.size > 1
    val runnable = if (joining) known.size == picks.size else plans.any { opt.tool != Tool.COMPRESS || it.third.skipReason == null }

    Scaffold(
        containerColor = C.Bg,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.Bg),
                title = { Text("Options") },
                navigationIcon = { IconButton(onClick = { Nav.back() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") } },
            )
        },
        bottomBar = {
            Surface(color = C.Surface) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp)) {
                    val before = if (joining) picks.sumOf { it.size } else plans.filter { opt.tool != Tool.COMPRESS || it.third.skipReason == null }.sumOf { it.first.size }
                    val after = if (joining) {
                        known.firstOrNull()?.let { (_, i) ->
                            Planner.plan(i.copy(durationMs = known.sumOf { it.second.durationMs }, sizeBytes = before, videoBitrate = 0),
                                opt.copy(trimStartMs = 0, trimEndMs = 0, crop = null, rotate = 0, flip = false, speed = 1f), true).predictedBytes
                        } ?: 0
                    } else plans.filter { opt.tool != Tool.COMPRESS || it.third.skipReason == null }.sumOf { it.third.predictedBytes }
                    val speed = if (eff.engine == Engine.MAX && softReady && opt.tool == Tool.COMPRESS) settings.speedMax else settings.speedFast
                    val seconds = plans.filter { opt.tool != Tool.COMPRESS || it.third.skipReason == null }
                        .sumOf { Planner.estimateSeconds(it.third, it.second, speed.toDouble()) }
                    when {
                        reading -> Hint("Reading the video…")
                        !runnable && plans.isNotEmpty() -> Text(plans.first().third.skipReason ?: "Nothing to do with these settings",
                            style = MaterialTheme.typography.titleSmall, color = C.Warn)
                        after > 0 && opt.tool == Tool.COMPRESS -> {
                            Text("${Format.size(before)} to about ${Format.size(after)}", style = MaterialTheme.typography.titleMedium)
                            Hint("${Format.percentSaved(before, after)}% smaller · ${Format.eta(seconds)}")
                        }
                        after > 0 -> {
                            Text("About ${Format.size(after)}", style = MaterialTheme.typography.titleMedium)
                            Hint(Format.eta(seconds).replaceFirstChar { it.uppercase() })
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = { AppModel.startBatch(ctx); Nav.show(Screen.Progress) },
                        enabled = runnable && !reading,
                        modifier = Modifier.fillMaxWidth().height(52.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.OnAccent),
                    ) {
                        Text(when (opt.tool) {
                            Tool.JOIN -> "Join ${picks.size} videos"; Tool.GIF -> "Make GIF"; Tool.AUDIO_ONLY -> "Save audio"
                            else -> if (picks.size == 1) "Compress" else "Compress ${picks.size} videos"
                        }, style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
        },
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            // The ticked videos
            item {
                Card {
                    picks.forEachIndexed { n, p ->
                        if (n > 0) HorizontalDivider(Modifier.padding(vertical = 10.dp), color = C.Outline)
                        val info = infos[p.uri.toString()]
                        val plan = plans.firstOrNull { it.first.uri == p.uri }?.third
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Thumb(p.uri, Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(p.name, style = MaterialTheme.typography.bodyLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Hint(buildString {
                                    append(Format.size(p.size))
                                    if (info != null) {
                                        append(" · ${info.width}×${info.height} · ${Format.duration(info.durationMs)}")
                                        if (info.isHdr) append(" · HDR")
                                    }
                                })
                                when {
                                    p in unreadable -> Hint("This video could not be read.", color = C.Error)
                                    plan?.skipReason != null && opt.tool == Tool.COMPRESS -> Hint("Will be skipped: ${plan.skipReason}", color = C.Warn)
                                    plan != null && opt.tool == Tool.COMPRESS && !joining ->
                                        Hint("About ${Format.size(plan.predictedBytes)} at ${plan.width}×${plan.height}", color = C.Accent)
                                }
                            }
                        }
                    }
                }
            }

            // What to do
            item {
                PillRow {
                    Pill("Compress", opt.tool == Tool.COMPRESS) { set { it.copy(tool = Tool.COMPRESS) } }
                    if (picks.size > 1) Pill("Join into one", opt.tool == Tool.JOIN) { set { it.copy(tool = Tool.JOIN) } }
                    Pill("Make a GIF", opt.tool == Tool.GIF) { set { it.copy(tool = Tool.GIF) } }
                    Pill("Audio only", opt.tool == Tool.AUDIO_ONLY) { set { it.copy(tool = Tool.AUDIO_ONLY, audio = if (it.audio == AudioMode.REMOVE) AudioMode.KEEP else it.audio) } }
                }
            }

            if (opt.tool == Tool.COMPRESS || opt.tool == Tool.JOIN) {
                // Quality
                item { SectionTitle("Quality") }
                item {
                    Card {
                        Preset.entries.forEach { p ->
                            val chosen = opt.targetBytes == 0L && opt.manualBitrate == 0 && opt.preset == p
                            val est = if (joining) 0L else known.sumOf { (_, i) ->
                                Planner.plan(i, eff.copy(preset = p, targetBytes = 0, manualBitrate = 0), true).predictedBytes
                            }
                            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable {
                                set { it.copy(preset = p, targetBytes = 0, manualBitrate = 0) }; advanced = false
                            }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (chosen) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null,
                                    tint = if (chosen) C.Accent else C.Muted)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(p.label, style = MaterialTheme.typography.bodyLarge)
                                    Hint(p.blurb)
                                }
                                if (est > 0) Text("≈ ${Format.size(est)}", style = MaterialTheme.typography.labelLarge, color = if (chosen) C.Accent else C.Muted)
                            }
                        }
                    }
                }

                // Fit a size
                if (!joining) {
                    item { SectionTitle("Or fit a size") }
                    item {
                        Card {
                            PillRow {
                                sizeTargets.forEach { (label, mb) ->
                                    val bytes = mb * 1_000_000L
                                    Pill("$label $mb MB", opt.targetBytes == bytes) {
                                        set { it.copy(targetBytes = if (it.targetBytes == bytes) 0 else bytes, manualBitrate = 0) }
                                    }
                                }
                                val custom = opt.targetBytes > 0 && sizeTargets.none { it.second * 1_000_000L == opt.targetBytes }
                                Pill(if (custom) "Custom ${Format.size(opt.targetBytes)}" else "Custom size", custom) { customSize = true }
                            }
                            if (opt.targetBytes > 0) {
                                Spacer(Modifier.height(8.dp))
                                val drop = plans.mapNotNull { it.third.autoShortSide.takeIf { s -> s > 0 } }.minOrNull()
                                if (drop != null) Hint("To stay sharp at this size the picture will drop to ${drop}p.", color = C.Warn)
                                else Hint("Each video is brought in just under ${Format.size(opt.targetBytes)}. If the first try lands over, it is redone automatically.")
                            }
                        }
                    }
                }

                // Picture size and frame rate
                item { SectionTitle("Picture") }
                item {
                    Card {
                        Text("Resolution", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        PillRow {
                            Pill("Original", opt.shortSide == 0) { set { it.copy(shortSide = 0) } }
                            heights.filter { minShort == 0 || it < minShort }.forEach { h ->
                                Pill("${h}p", opt.shortSide == h) { set { it.copy(shortSide = h) } }
                            }
                            val custom = opt.shortSide > 0 && opt.shortSide !in heights
                            Pill(if (custom) "Custom ${opt.shortSide}p" else "Custom", custom) { customHeight = true }
                        }
                        plans.firstOrNull()?.third?.let {
                            if (it.width > 0) Hint("Comes out at ${it.width}×${it.height}" + if (picks.size > 1 && !joining) " for the first video" else "", Modifier.padding(top = 8.dp))
                        }
                        HorizontalDivider(Modifier.padding(vertical = 12.dp), color = C.Outline)
                        Text("Frame rate", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        PillRow {
                            Pill("Original", opt.fps == 0) { set { it.copy(fps = 0) } }
                            frameRates.filter { maxFps < 1f || it < maxFps - 0.5f }.forEach { f ->
                                Pill("$f fps", opt.fps == f) { set { it.copy(fps = f) } }
                            }
                        }
                        if (maxFps > 1f) Hint("Original is ${maxFps.roundToInt()} frames a second. Halving 60 to 30 saves a lot on its own.", Modifier.padding(top = 8.dp))
                    }
                }

                // Format and engine
                item { SectionTitle("Format") }
                item {
                    Card {
                        val list = Codecs.available(if (opt.engine == Engine.MAX && softReady) Engine.MAX else Engine.FAST)
                        PillRow {
                            Codec.entries.forEach { c ->
                                Pill(c.label, opt.codec == c, enabled = c in list) { set { it.copy(codec = c) } }
                            }
                        }
                        Hint(opt.codec.blurb, Modifier.padding(top = 8.dp))
                        if (Codec.AV1 !in Codecs.available(Engine.FAST)) Hint("AV1 needs a newer video chip than this phone has.", Modifier.padding(top = 2.dp))
                        HorizontalDivider(Modifier.padding(vertical = 12.dp), color = C.Outline)
                        Text("Engine", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        PillRow {
                            Pill("Fast", opt.engine == Engine.FAST) { set { it.copy(engine = Engine.FAST) } }
                            Pill("Max quality", opt.engine == Engine.MAX, enabled = softReady && !joining) {
                                set { it.copy(engine = Engine.MAX, codec = if (it.codec == Codec.AV1) Codec.HEVC else it.codec) }
                            }
                        }
                        Hint(
                            if (opt.engine == Engine.MAX) "Slow and careful. Squeezes about a quarter smaller for the same look, but takes many times longer and warms the phone. Best left running on charge."
                            else "Uses the phone's video chip. Quick and cool. The right choice nearly every time.",
                            Modifier.padding(top = 8.dp),
                        )
                        if (opt.engine == Engine.MAX && anyHdr && opt.hdr == HdrMode.KEEP) {
                            Hint("HDR videos use the Fast engine so the HDR is kept.", Modifier.padding(top = 4.dp), color = C.Warn)
                        }
                    }
                }

                // Advanced
                item {
                    Card {
                        SwitchRow("Set the bitrate myself", "For people who know the number they want", advanced) { on ->
                            advanced = on
                            set { o -> if (on) o.copy(manualBitrate = plans.firstOrNull()?.third?.videoBitrate ?: 4_000_000, targetBytes = 0) else o.copy(manualBitrate = 0) }
                        }
                        if (advanced && opt.manualBitrate > 0) {
                            val top = (known.maxOfOrNull { it.second.videoBitrate } ?: 0).coerceAtLeast(8_000_000).toFloat()
                            Text(Format.bitrate(opt.manualBitrate), style = MaterialTheme.typography.titleMedium, color = C.Accent)
                            Slider(
                                value = opt.manualBitrate.toFloat().coerceIn(200_000f, top),
                                onValueChange = { v -> set { it.copy(manualBitrate = ((v / 50_000).roundToInt() * 50_000)) } },
                                valueRange = 200_000f..top,
                                colors = SliderDefaults.colors(thumbColor = C.Accent, activeTrackColor = C.Accent, inactiveTrackColor = C.SurfaceHigh),
                            )
                        }
                    }
                }
            }

            if (opt.tool == Tool.GIF) {
                item { SectionTitle("GIF") }
                item {
                    Card {
                        Text("Width", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        PillRow { listOf(320, 480, 640, 800).forEach { w -> Pill("$w px", opt.gifWidth == w) { set { it.copy(gifWidth = w) } } } }
                        HorizontalDivider(Modifier.padding(vertical = 12.dp), color = C.Outline)
                        Text("Smoothness", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        PillRow { listOf(8, 12, 15, 24).forEach { f -> Pill("$f fps", opt.gifFps == f) { set { it.copy(gifFps = f) } } } }
                        val len = firstInfo?.let { Planner.outputDurationMs(it, eff) } ?: 0
                        Hint(if (len > 15_000) "This is ${Format.duration(len)} long. GIFs get very big, so trim it to a few seconds below."
                        else "GIFs have no sound and are saved to Pictures/Compress.", Modifier.padding(top = 10.dp),
                            color = if (len > 15_000) C.Warn else C.Muted)
                    }
                }
            }

            // Sound
            if (opt.tool != Tool.GIF) {
                item { SectionTitle("Sound") }
                item {
                    Card {
                        PillRow {
                            AudioMode.entries.filter { opt.tool != Tool.AUDIO_ONLY || it != AudioMode.REMOVE }.forEach { m ->
                                Pill(m.label, opt.audio == m) { set { it.copy(audio = m) } }
                            }
                        }
                        if (opt.audio == AudioMode.SHRINK) {
                            Spacer(Modifier.height(10.dp))
                            PillRow { listOf(192, 128, 96, 64).forEach { k -> Pill("$k kbps", opt.audioBitrate == k * 1000) { set { it.copy(audioBitrate = k * 1000) } } } }
                            Hint("128 is fine for speech and most music. 64 is for speech only.", Modifier.padding(top = 8.dp))
                        }
                        if (opt.audio != AudioMode.REMOVE) {
                            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = C.Outline)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Volume", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                                Text("${(opt.volume * 100).roundToInt()}%", color = C.Accent, style = MaterialTheme.typography.labelLarge)
                                if (opt.volume != 1f) TextButton(onClick = { set { it.copy(volume = 1f) } }) { Text("Reset") }
                            }
                            Slider(
                                value = opt.volume, onValueChange = { v -> set { it.copy(volume = (v * 20).roundToInt() / 20f) } },
                                valueRange = 0f..3f,
                                colors = SliderDefaults.colors(thumbColor = C.Accent, activeTrackColor = C.Accent, inactiveTrackColor = C.SurfaceHigh),
                            )
                            if (opt.volume > 1.5f) Hint("Big boosts can make loud parts crackle.", color = C.Warn)
                        }
                    }
                }
            }

            // Edit
            if (!joining) {
                item { SectionTitle("Edit") }
                item {
                    Card {
                        if (single && firstInfo != null) {
                            val dur = firstInfo.durationMs
                            val end = if (opt.trimEndMs in 1..dur) opt.trimEndMs else dur
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Trim", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                                Text("${clock(opt.trimStartMs)} to ${clock(end)}", color = if (opt.hasTrim) C.Accent else C.Muted, style = MaterialTheme.typography.labelLarge)
                                if (opt.hasTrim) TextButton(onClick = { set { it.copy(trimStartMs = 0, trimEndMs = 0) } }) { Text("Reset") }
                            }
                            if (dur > 500) RangeSlider(
                                value = opt.trimStartMs.toFloat()..end.toFloat(),
                                onValueChange = { r ->
                                    val s = r.start.toLong().coerceIn(0, dur - 200)
                                    val e = r.endInclusive.toLong().coerceIn(s + 200, dur)
                                    set { it.copy(trimStartMs = if (s < 50) 0 else s, trimEndMs = if (e > dur - 50) 0 else e) }
                                },
                                valueRange = 0f..dur.toFloat(),
                                colors = SliderDefaults.colors(thumbColor = C.Accent, activeTrackColor = C.Accent, inactiveTrackColor = C.SurfaceHigh),
                            )
                            if (opt.tool != Tool.AUDIO_ONLY) {
                                HorizontalDivider(Modifier.padding(vertical = 8.dp), color = C.Outline)
                                ValueRow("Crop", if (opt.hasCrop) "On" else "Off",
                                    if (opt.hasCrop) "Tap to change" else "Cut the edges off the picture") { cropOpen = true }
                                HorizontalDivider(Modifier.padding(vertical = 8.dp), color = C.Outline)
                            }
                        } else if (!single) {
                            Hint("Trim and crop are set by eye, so they are offered when one video is ticked.")
                            HorizontalDivider(Modifier.padding(vertical = 10.dp), color = C.Outline)
                        }
                        if (opt.tool != Tool.AUDIO_ONLY) {
                            Text("Rotate", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(8.dp))
                            PillRow {
                                listOf(0 to "None", 90 to "Right", 180 to "Upside down", 270 to "Left").forEach { (deg, label) ->
                                    Pill(label, opt.rotate == deg) { set { it.copy(rotate = deg) } }
                                }
                                Pill("Mirror", opt.flip) { set { it.copy(flip = !it.flip) } }
                            }
                            HorizontalDivider(Modifier.padding(vertical = 12.dp), color = C.Outline)
                        }
                        Text("Speed", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(8.dp))
                        PillRow {
                            speeds.forEach { s ->
                                val label = if (s == 1f) "Normal" else (if (s % 1f == 0f) "${s.toInt()}×" else "$s×")
                                Pill(label, opt.speed == s) { set { it.copy(speed = s) } }
                            }
                        }
                        if (opt.speed != 1f) Hint("The sound keeps its pitch. Slowing down does not add frames, so it looks less smooth.", Modifier.padding(top = 8.dp))
                    }
                }
            }

            // Details
            if (opt.tool == Tool.COMPRESS || opt.tool == Tool.JOIN) {
                item { SectionTitle("Details") }
                item {
                    Card {
                        SwitchRow("Keep date and details", "The copy sits beside the original in Gallery", opt.keepInfo) { v -> set { it.copy(keepInfo = v) } }
                        SwitchRow("Remove location", "Takes out where it was filmed. Use before sharing.", opt.stripLocation || !opt.keepInfo, enabled = opt.keepInfo) { v ->
                            set { it.copy(stripLocation = v) }
                        }
                        if (anyHdr) {
                            HorizontalDivider(Modifier.padding(vertical = 8.dp), color = C.Outline)
                            Text("HDR", style = MaterialTheme.typography.titleSmall)
                            Spacer(Modifier.height(8.dp))
                            PillRow { HdrMode.entries.forEach { m -> Pill(m.label, opt.hdr == m) { set { it.copy(hdr = m) } } } }
                            Hint("HDR is the brighter, more vivid mode. Convert it if the video will be watched on older screens, where HDR looks washed out.",
                                Modifier.padding(top = 8.dp))
                            if (opt.hdr == HdrMode.KEEP && opt.codec == Codec.H264) Hint("H.264 cannot hold HDR, so it will be converted.", color = C.Warn)
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
    }

    if (customSize) NumberDialog("Size to fit", "MB", if (opt.targetBytes > 0) (opt.targetBytes / 1_000_000).toString() else "",
        "Each video is brought in just under this size.", { customSize = false }) { mb ->
        customSize = false
        if (mb in 1..100_000) set { it.copy(targetBytes = mb * 1_000_000L, manualBitrate = 0) }
    }
    if (customHeight) NumberDialog("Resolution", "p", if (opt.shortSide > 0) opt.shortSide.toString() else "",
        "The short side of the picture in pixels, for example 900. It is never made bigger than the original.", { customHeight = false }) { h ->
        customHeight = false
        if (h in 120..4320) set { it.copy(shortSide = (h / 2) * 2) }
    }
    if (cropOpen && single && firstInfo != null) {
        CropDialog(picks.first().uri, firstInfo, opt.crop, opt.trimStartMs, onDismiss = { cropOpen = false }) { rect ->
            cropOpen = false
            set { it.copy(crop = rect) }
        }
    }
}

@Composable
fun NumberDialog(title: String, unit: String, initial: String, help: String, onDismiss: () -> Unit, onDone: (Int) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.Surface,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = text, onValueChange = { v -> text = v.filter { it.isDigit() }.take(6) }, singleLine = true,
                    suffix = { Text(unit) }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                Hint(help, Modifier.padding(top = 10.dp))
            }
        },
        confirmButton = { TextButton(onClick = { onDone(text.toIntOrNull() ?: 0) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun TextDialog(title: String, initial: String, help: String, onDismiss: () -> Unit, onDone: (String) -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.Surface,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(value = text, onValueChange = { text = it.take(60) }, singleLine = true)
                Hint(help, Modifier.padding(top = 10.dp))
            }
        },
        confirmButton = { TextButton(onClick = { onDone(text.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun <T> ChoiceDialog(title: String, options: List<Pair<T, String>>, current: T, help: (T) -> String? = { null }, onDismiss: () -> Unit, onPick: (T) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = C.Surface,
        title = { Text(title) },
        text = {
            Column {
                options.forEach { (value, label) ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { onPick(value) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (value == current) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked, null,
                            tint = if (value == current) C.Accent else C.Muted)
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(label, style = MaterialTheme.typography.bodyLarge)
                            help(value)?.let { Hint(it) }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
fun Tag(text: String, modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(50)).background(C.SurfaceHigh).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Text(text, style = MaterialTheme.typography.labelMedium, color = C.Muted)
    }
}

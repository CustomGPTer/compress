package uk.jj.compress.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import uk.jj.compress.data.Job
import uk.jj.compress.data.Jobs
import uk.jj.compress.data.MediaRepo
import uk.jj.compress.data.SettingsStore
import uk.jj.compress.data.VideoItem
import uk.jj.compress.engine.Options
import uk.jj.compress.engine.Probe
import uk.jj.compress.engine.SourceInfo
import uk.jj.compress.engine.Tool
import uk.jj.compress.service.CompressService

/** A video the user has ticked. [item] is null when it came from outside the phone's library. */
data class Pick(val uri: Uri, val item: VideoItem?, val name: String, val size: Long)

/** Screen state shared across the app. */
object AppModel {
    const val MAX_PICKS = 3

    val videos = MutableStateFlow<List<VideoItem>>(emptyList())
    val loaded = MutableStateFlow(false)
    val picks = MutableStateFlow<List<Pick>>(emptyList())
    val draft = MutableStateFlow(Options())
    val infos = MutableStateFlow<Map<String, SourceInfo?>>(emptyMap())

    suspend fun refresh(ctx: Context) {
        if (!MediaRepo.canReadSome(ctx)) { videos.value = emptyList(); loaded.value = true; return }
        videos.value = MediaRepo.loadAll(ctx)
        loaded.value = true
    }

    /** @return false when the three-video limit stopped the tick. */
    fun toggle(item: VideoItem): Boolean {
        val cur = picks.value
        if (cur.any { it.uri == item.uri }) { picks.value = cur.filter { it.uri != item.uri }; return true }
        if (cur.size >= MAX_PICKS) return false
        picks.value = cur + Pick(item.uri, item, item.name, item.size)
        return true
    }

    fun clearPicks() { picks.value = emptyList() }

    /** Videos handed over by another app or the file picker. Only the first three are taken. */
    suspend fun setExternal(ctx: Context, uris: List<Uri>): Int = withContext(Dispatchers.IO) {
        val list = uris.distinct().take(MAX_PICKS).map { uri ->
            val item = MediaRepo.findByUri(ctx, uri)
            if (item != null) Pick(item.uri, item, item.name, item.size)
            else {
                var name = "video.mp4"
                runCatching {
                    ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                        if (it.moveToFirst()) name = it.getString(0) ?: name
                    }
                }
                Pick(uri, null, name, Probe.fileSize(ctx, uri))
            }
        }
        picks.value = list
        uris.distinct().size
    }

    fun resetDraft() { draft.value = SettingsStore.value.defaultOptions() }

    suspend fun probePicks(ctx: Context) {
        for (p in picks.value) {
            val key = p.uri.toString()
            if (infos.value.containsKey(key)) continue
            val info = withContext(Dispatchers.IO) { Probe.read(ctx, p.uri, p.size) }
            infos.value = infos.value + (key to info)
        }
    }

    /** Queues the ticked videos with the current options and starts the service. */
    fun startBatch(ctx: Context) {
        val opt = draft.value
        val list = picks.value
        if (list.isEmpty()) return
        val batch = System.currentTimeMillis()
        Jobs.forgetOldBatches(batch)
        val info = infos.value
        fun job(p: Pick, sources: List<String>, size: Long, o: Options) = Job(
            batch = batch, sources = sources, sourceId = p.item?.id ?: -1, name = p.name, srcSize = size,
            srcWidth = info[p.uri.toString()]?.width ?: p.item?.width ?: 0,
            srcHeight = info[p.uri.toString()]?.height ?: p.item?.height ?: 0,
            srcDurationMs = info[p.uri.toString()]?.durationMs ?: p.item?.durationMs ?: 0,
            srcPath = p.item?.path, srcRelPath = p.item?.relPath ?: "", srcDateTaken = p.item?.sortDate ?: 0, options = o,
        )
        val jobs = if (opt.tool == Tool.JOIN && list.size > 1) {
            listOf(job(list.first(), list.map { it.uri.toString() }, list.sumOf { it.size }, opt))
        } else {
            // Trim and crop are set by eye on one video, so they only apply when one is ticked.
            val o = if (list.size > 1) opt.copy(trimStartMs = 0, trimEndMs = 0, crop = null,
                tool = if (opt.tool == Tool.JOIN) Tool.COMPRESS else opt.tool) else
                opt.copy(tool = if (opt.tool == Tool.JOIN) Tool.COMPRESS else opt.tool)
            list.map { job(it, listOf(it.uri.toString()), it.size, o) }
        }
        Jobs.add(jobs)
        clearPicks()
        CompressService.start(ctx)
    }
}

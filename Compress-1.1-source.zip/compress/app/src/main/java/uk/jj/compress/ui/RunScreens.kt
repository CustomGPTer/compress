package uk.jj.compress.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.HourglassEmpty
import androidx.compose.material.icons.rounded.RemoveCircleOutline
import androidx.compose.material.icons.rounded.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import uk.jj.compress.Nav
import uk.jj.compress.Screen
import uk.jj.compress.data.Job
import uk.jj.compress.data.JobState
import uk.jj.compress.data.Jobs
import uk.jj.compress.data.Ledger
import uk.jj.compress.engine.Format
import uk.jj.compress.engine.Tool
import uk.jj.compress.service.CompressService
import uk.jj.compress.service.Notifier
import kotlin.math.roundToInt

@Composable
private fun StateIcon(job: Job) {
    when (job.state) {
        JobState.DONE -> Icon(Icons.Rounded.CheckCircle, null, tint = C.Accent)
        JobState.RUNNING -> Icon(Icons.Rounded.Sync, null, tint = C.Blue)
        JobState.QUEUED -> Icon(Icons.Rounded.HourglassEmpty, null, tint = C.Muted)
        JobState.SKIPPED -> Icon(Icons.Rounded.RemoveCircleOutline, null, tint = C.Warn)
        JobState.FAILED, JobState.CANCELLED -> Icon(Icons.Rounded.ErrorOutline, null, tint = C.Error)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProgressScreen() {
    val ctx = LocalContext.current
    val jobs by Jobs.flow.collectAsState()
    val status by Jobs.status.collectAsState()
    val eta by Jobs.etaSeconds.collectAsState()
    var confirm by remember { mutableStateOf(false) }

    val active = jobs.firstOrNull { it.state == JobState.RUNNING } ?: jobs.firstOrNull { it.state == JobState.QUEUED }
    val batch = active?.let { a -> jobs.filter { it.batch == a.batch } } ?: emptyList()

    LaunchedEffect(active == null) {
        if (active == null) { delay(300); if (!Jobs.hasWork && Nav.current == Screen.Progress) Nav.replace(Screen.Results) }
    }

    Scaffold(
        containerColor = C.Bg,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.Bg),
                title = { Text(if (active?.state == JobState.RUNNING) "Compressing" else "Waiting") },
                navigationIcon = { IconButton(onClick = { Nav.home() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") } },
            )
        },
        bottomBar = {
            Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp)) {
                OutlinedButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp)) {
                    Text("Cancel", color = C.Error)
                }
            }
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(12.dp))
            val p = active?.takeIf { it.state == JobState.RUNNING }?.progress ?: 0
            Box(Modifier.size(210.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val stroke = 14.dp.toPx()
                    val inset = stroke / 2
                    val arc = Size(size.width - stroke, size.height - stroke)
                    drawArc(C.SurfaceHigh, 0f, 360f, false, Offset(inset, inset), arc, style = Stroke(stroke))
                    drawArc(C.Accent, -90f, 360f * p / 100f, false, Offset(inset, inset), arc, style = Stroke(stroke, cap = StrokeCap.Round))
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("$p%", fontSize = 46.sp, fontWeight = FontWeight.Light)
                    if (batch.size > 1 && active != null) Hint("${batch.indexOf(active) + 1} of ${batch.size}")
                }
            }
            Spacer(Modifier.height(16.dp))
            Text(active?.name ?: "", style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(4.dp))
            val line = buildString {
                append(status.ifBlank { if (active?.state == JobState.QUEUED) "Waiting to start" else "Working" })
                if (eta >= 0 && active?.state == JobState.RUNNING) append(" · ${Format.eta(eta)} left")
            }
            Text(line, color = C.Muted, textAlign = TextAlign.Center)
            if (active?.state == JobState.QUEUED) {
                Spacer(Modifier.height(10.dp))
                Button(onClick = { CompressService.start(ctx) }, colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.OnAccent)) {
                    Text("Start now")
                }
            }
            Spacer(Modifier.height(18.dp))
            Card {
                Text("You can turn the screen off or leave the app.", style = MaterialTheme.typography.titleSmall)
                Hint("Compress keeps going in the background and tells you when it is done.", Modifier.padding(top = 2.dp))
            }
            Spacer(Modifier.height(12.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(batch, key = { it.id }) { j ->
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.Surface).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        StateIcon(j)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(j.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Hint(when (j.state) {
                                JobState.DONE -> "${Format.size(j.srcSize)} to ${Format.size(j.outSize)}"
                                JobState.RUNNING -> "${j.progress}%"
                                JobState.QUEUED -> "Waiting · ${Format.size(j.srcSize)}"
                                else -> j.message ?: ""
                            })
                        }
                    }
                }
            }
        }
    }

    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = C.Surface,
        title = { Text("Stop compressing?") },
        text = { Text("The video in progress is thrown away and anything waiting is removed. Finished videos and all originals are kept.") },
        confirmButton = { TextButton(onClick = { confirm = false; CompressService.cancel(ctx); Nav.home() }) { Text("Stop", color = C.Error) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Carry on") } },
    )
}

@Composable
private fun SizeBox(label: String, size: Long, dims: String, bg: Color, fg: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(bg).padding(12.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = fg.copy(alpha = 0.8f))
        Text(Format.size(size), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = fg)
        if (dims.isNotEmpty()) Text(dims, style = MaterialTheme.typography.bodySmall, color = fg.copy(alpha = 0.8f))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen() {
    val ctx = LocalContext.current
    val jobs by Jobs.flow.collectAsState()
    val finished = jobs.filter { it.finished }.sortedWith(compareByDescending<Job> { it.batch }.thenBy { it.finishedAt })
    val pending = finished.filter { it.replacePending && it.sourceId > 0 }

    val trash = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val now = System.currentTimeMillis()
            Ledger.addBin(pending.map { Ledger.BinEntry(it.sources.first(), it.name, it.srcSize, now) })
            pending.forEach { j -> Jobs.update(j.id) { it.copy(replacePending = false, originalBinned = true) } }
        }
    }

    Scaffold(
        containerColor = C.Bg,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.Bg),
                title = { Text("Results") },
                navigationIcon = { IconButton(onClick = { Nav.home() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") } },
            )
        },
        bottomBar = {
            Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp)) {
                Button(onClick = { Nav.home() }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.OnAccent)) { Text("Done") }
            }
        },
    ) { pad ->
        LazyColumn(Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (finished.isEmpty()) item {
                Text("Nothing has been compressed yet.", Modifier.fillMaxWidth().padding(top = 60.dp), color = C.Muted, textAlign = TextAlign.Center)
            }
            val saved = finished.sumOf { it.saved }
            if (saved > 0 && finished.count { it.state == JobState.DONE } > 1) item {
                Card {
                    Text("${Format.size(saved)} saved", style = MaterialTheme.typography.headlineSmall, color = C.Accent)
                    Hint("across ${finished.count { it.state == JobState.DONE }} videos")
                }
            }
            if (pending.isNotEmpty() && Build.VERSION.SDK_INT >= 30) item {
                Card {
                    Text("Move ${pending.size} original${if (pending.size == 1) "" else "s"} to the bin?", style = MaterialTheme.typography.titleMedium)
                    Hint("The new files have been checked and play. Android keeps binned videos for 30 days, and you can put them back from Settings, then Bin.",
                        Modifier.padding(top = 4.dp))
                    Spacer(Modifier.height(12.dp))
                    Row {
                        Button(
                            onClick = {
                                runCatching {
                                    val pi = MediaStore.createTrashRequest(ctx.contentResolver, pending.map { Uri.parse(it.sources.first()) }, true)
                                    trash.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = C.Accent, contentColor = C.OnAccent),
                        ) { Text("Move to bin") }
                        Spacer(Modifier.width(8.dp))
                        TextButton(onClick = { pending.forEach { j -> Jobs.update(j.id) { it.copy(replacePending = false) } } }) { Text("Keep originals", color = C.Muted) }
                    }
                }
            }
            items(finished, key = { it.id }) { j -> ResultCard(j) }
        }
    }
}

@Composable
private fun ResultCard(j: Job) {
    val ctx = LocalContext.current
    Card {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StateIcon(j)
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(when (j.state) {
                    JobState.DONE -> when (j.options.tool) {
                        Tool.GIF -> "GIF made"; Tool.AUDIO_ONLY -> "Audio saved"; Tool.JOIN -> "Joined"; else -> "Compressed"
                    }
                    JobState.SKIPPED -> "Skipped"; JobState.FAILED -> "Did not work"; JobState.CANCELLED -> "Cancelled"; else -> ""
                }, style = MaterialTheme.typography.titleMedium,
                    color = when (j.state) { JobState.DONE -> C.Accent; JobState.SKIPPED -> C.Warn; else -> C.Error })
                Text(j.outName ?: j.name, style = MaterialTheme.typography.bodyMedium, color = C.Muted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (j.state == JobState.DONE && j.options.tool == Tool.COMPRESS) {
                Text("${Format.percentSaved(j.srcSize, j.outSize)}% smaller", style = MaterialTheme.typography.labelLarge, color = C.Accent)
            }
        }
        if (j.state != JobState.DONE) {
            j.message?.let { Text(it, Modifier.padding(top = 10.dp), style = MaterialTheme.typography.bodyMedium) }
            if (j.state == JobState.SKIPPED) Hint("The original has not been touched.", Modifier.padding(top = 2.dp))
            return@Card
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SizeBox("Original", j.srcSize, if (j.srcWidth > 0) "${j.srcWidth}×${j.srcHeight}" else "", C.Before, C.BeforeText, Modifier.weight(1f))
            SizeBox(if (j.options.tool == Tool.COMPRESS) "Compressed" else "New file", j.outSize,
                if (j.outWidth > 0 && j.options.tool != Tool.AUDIO_ONLY && j.options.tool != Tool.GIF) "${j.outWidth}×${j.outHeight}" else "",
                C.AccentDim, C.Accent, Modifier.weight(1f))
        }
        j.note?.let { Hint(it, Modifier.padding(top = 10.dp), color = C.Warn) }
        if (j.originalBinned) Hint("Original moved to the bin.", Modifier.padding(top = 8.dp))
        Spacer(Modifier.height(12.dp))
        val uri = j.outUri?.let(Uri::parse)
        val mime = when (j.options.tool) { Tool.GIF -> "image/gif"; Tool.AUDIO_ONLY -> "audio/mp4"; else -> "video/mp4" }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (uri != null) {
                OutlinedButton(onClick = { runCatching { ctx.startActivity(Notifier.shareIntent(listOf(uri), mime)) } }, modifier = Modifier.weight(1f)) { Text("Share") }
                OutlinedButton(onClick = {
                    runCatching {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                    }
                }, modifier = Modifier.weight(1f)) { Text("Play") }
            }
            if (j.options.tool == Tool.COMPRESS && !j.originalBinned) {
                OutlinedButton(onClick = { Nav.push(Screen.Compare(j.id)) }, modifier = Modifier.weight(1f)) { Text("Compare") }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CompareScreen(jobId: String) {
    val ctx = LocalContext.current
    val job = remember(jobId) { Jobs.get(jobId) }
    var timeMs by remember { mutableFloatStateOf(((job?.srcDurationMs ?: 2000L) / 2).toFloat()) }
    var before by remember { mutableStateOf<Bitmap?>(null) }
    var after by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(true) }
    var failed by remember { mutableStateOf(false) }
    var split by remember { mutableFloatStateOf(0.5f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var pan by remember { mutableStateOf(Offset.Zero) }

    LaunchedEffect(timeMs) {
        if (job?.outUri == null) { failed = true; loading = false; return@LaunchedEffect }
        delay(180)
        loading = true
        val t = timeMs.toLong()
        val offset = job.options.trimStartMs
        val a = loadFrame(ctx, Uri.parse(job.sources.first()), t + offset, 2000, exact = true)
        val b = loadFrame(ctx, Uri.parse(job.outUri), (t / job.options.speed).toLong(), 2000, exact = true)
        if (a != null && b != null) { before = a; after = b; failed = false } else if (before == null) failed = true
        loading = false
    }

    Scaffold(
        containerColor = C.Bg,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(containerColor = C.Bg),
                title = { Text("Compare") },
                navigationIcon = { IconButton(onClick = { Nav.back() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back") } },
            )
        },
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad).padding(16.dp)) {
            if (job == null || failed) {
                Text("These two videos cannot be compared. One of them may have been moved or deleted.", color = C.Muted)
                return@Column
            }
            val shape = if (job.srcHeight > 0 && job.srcWidth > 0 && !job.options.hasCrop && job.options.rotate % 180 == 0)
                job.srcWidth.toFloat() / job.srcHeight else (after?.let { it.width.toFloat() / it.height } ?: 16f / 9f)
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                val boxShape = maxWidth.value / maxHeight.value
                val w = if (shape > boxShape) maxWidth else maxHeight * shape
                val h = if (shape > boxShape) maxWidth / shape else maxHeight
                val wPx = with(LocalDensity.current) { w.toPx() }
                Box(
                    Modifier.size(w, h).clip(RoundedCornerShape(12.dp)).clipToBounds().background(C.Surface)
                        .pointerInput(Unit) {
                            detectTransformGestures { _, panBy, zoomBy, _ ->
                                zoom = (zoom * zoomBy).coerceIn(1f, 8f)
                                val maxX = size.width * (zoom - 1) / 2; val maxY = size.height * (zoom - 1) / 2
                                pan = Offset((pan.x + panBy.x).coerceIn(-maxX, maxX), (pan.y + panBy.y).coerceIn(-maxY, maxY))
                            }
                        },
                ) {
                    val layer = Modifier.fillMaxSize().graphicsLayer { scaleX = zoom; scaleY = zoom; translationX = pan.x; translationY = pan.y }
                    after?.let { Image(it.asImageBitmap(), "Compressed", layer, contentScale = ContentScale.Fit) }
                    before?.let {
                        Box(Modifier.fillMaxSize().drawWithContent { clipRect(right = size.width * split) { this@drawWithContent.drawContent() } }) {
                            Image(it.asImageBitmap(), "Original", layer, contentScale = ContentScale.Fit)
                        }
                    }
                    Text("Original", Modifier.align(Alignment.TopStart).padding(8.dp).clip(RoundedCornerShape(50)).background(Color(0xAA000000)).padding(horizontal = 10.dp, vertical = 4.dp),
                        fontSize = 12.sp, color = C.BeforeText)
                    Text("Compressed", Modifier.align(Alignment.TopEnd).padding(8.dp).clip(RoundedCornerShape(50)).background(Color(0xAA000000)).padding(horizontal = 10.dp, vertical = 4.dp),
                        fontSize = 12.sp, color = C.Accent)
                    // Divider and its handle
                    Box(Modifier.offset { IntOffset((wPx * split).roundToInt() - 1, 0) }.width(2.dp).height(h).background(Color.White))
                    Box(
                        Modifier.offset { IntOffset((wPx * split).roundToInt() - 22.dp.roundToPx(), (h.toPx() / 2).roundToInt() - 22.dp.roundToPx()) }
                            .size(44.dp).clip(CircleShape).background(Color.White)
                            .pointerInput(Unit) {
                                detectDragGestures { change, drag -> change.consume(); split = (split + drag.x / wPx).coerceIn(0.02f, 0.98f) }
                            },
                        contentAlignment = Alignment.Center,
                    ) { Text("◂ ▸", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                    if (loading) CircularProgressIndicator(Modifier.align(Alignment.BottomEnd).padding(10.dp).size(20.dp), color = C.Accent, strokeWidth = 2.dp)
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SizeBox("Original", job.srcSize, "${job.srcWidth}×${job.srcHeight}", C.Before, C.BeforeText, Modifier.weight(1f))
                SizeBox("Compressed", job.outSize, "${job.outWidth}×${job.outHeight}", C.AccentDim, C.Accent, Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            val length = (if (job.options.trimEndMs > 0) job.options.trimEndMs - job.options.trimStartMs else job.srcDurationMs - job.options.trimStartMs).coerceAtLeast(1000)
            Slider(value = timeMs.coerceIn(0f, length.toFloat()), onValueChange = { timeMs = it }, valueRange = 0f..length.toFloat(),
                colors = SliderDefaults.colors(thumbColor = C.Accent, activeTrackColor = C.Accent, inactiveTrackColor = C.SurfaceHigh))
            Hint("Drag the white handle. Pinch to zoom in. ${Format.duration(timeMs.toLong())}")
            if (zoom > 1f) TextButton(onClick = { zoom = 1f; pan = Offset.Zero }) { Text("Reset zoom") }
        }
    }
}

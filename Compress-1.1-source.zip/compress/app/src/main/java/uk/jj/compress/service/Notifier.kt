package uk.jj.compress.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import uk.jj.compress.MainActivity
import uk.jj.compress.R
import uk.jj.compress.data.Job
import uk.jj.compress.data.JobState
import uk.jj.compress.engine.Format
import uk.jj.compress.engine.Tool

object Notifier {
    const val CH_PROGRESS = "progress"
    const val CH_DONE = "done"
    const val ID_PROGRESS = 1
    const val ID_DONE = 2
    const val ID_NUDGE = 3

    fun createChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_PROGRESS, "Compressing", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Shows progress while videos are being compressed"; setShowBadge(false)
        })
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Finished", NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Tells you when videos are done, or when they are waiting for you"
        })
    }

    private fun open(ctx: Context, action: String, extra: String? = null, code: Int = 0): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).setAction(action)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (extra != null) i.putExtra("job", extra)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun progress(ctx: Context, title: String, text: String, percent: Int, indeterminate: Boolean = false): Notification {
        val cancel = PendingIntent.getService(
            ctx, 10, Intent(ctx, CompressService::class.java).setAction(CompressService.ACTION_CANCEL),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        return NotificationCompat.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title).setContentText(text)
            .setProgress(100, percent.coerceIn(0, 100), indeterminate)
            .setOngoing(true).setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setContentIntent(open(ctx, MainActivity.ACTION_PROGRESS, code = 1))
            .addAction(0, "Cancel", cancel)
            .build()
    }

    fun shareIntent(uris: List<Uri>, mime: String): Intent {
        val send = if (uris.size == 1) Intent(Intent.ACTION_SEND).putExtra(Intent.EXTRA_STREAM, uris.first())
        else Intent(Intent.ACTION_SEND_MULTIPLE).putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(uris))
        send.type = mime
        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        return Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    fun done(ctx: Context, batch: List<Job>) {
        val ok = batch.filter { it.state == JobState.DONE }
        val failed = batch.count { it.state == JobState.FAILED }
        val skipped = batch.count { it.state == JobState.SKIPPED }
        if (ok.isEmpty() && failed == 0 && skipped == 0) return
        val saved = ok.sumOf { it.saved }
        val title = when {
            ok.size == 1 && batch.size == 1 -> when (ok[0].options.tool) {
                Tool.GIF -> "GIF ready"; Tool.AUDIO_ONLY -> "Audio saved"; Tool.JOIN -> "Videos joined"
                else -> "Video compressed"
            }
            ok.isNotEmpty() -> "${ok.size} videos compressed"
            failed > 0 -> "Compressing did not finish"
            else -> "Nothing needed compressing"
        }
        val parts = mutableListOf<String>()
        if (ok.size == 1 && ok[0].options.tool == Tool.COMPRESS) {
            parts += "${Format.size(ok[0].srcSize)} to ${Format.size(ok[0].outSize)} (${Format.percentSaved(ok[0].srcSize, ok[0].outSize)}% smaller)"
        } else if (saved > 0) parts += "${Format.size(saved)} saved"
        if (skipped > 0) parts += "$skipped skipped"
        if (failed > 0) parts += "$failed failed"
        val b = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title).setContentText(parts.joinToString(" · "))
            .setAutoCancel(true)
            .setContentIntent(open(ctx, MainActivity.ACTION_RESULTS, code = 2))
        val uris = ok.mapNotNull { it.outUri }.map(Uri::parse)
        if (uris.isNotEmpty()) {
            val mime = when (ok[0].options.tool) { Tool.GIF -> "image/gif"; Tool.AUDIO_ONLY -> "audio/*"; else -> "video/*" }
            b.addAction(0, "Share", PendingIntent.getActivity(ctx, 3, shareIntent(uris, mime),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE))
        }
        ok.firstOrNull { it.options.tool == Tool.COMPRESS }?.let {
            b.addAction(0, "Compare", open(ctx, MainActivity.ACTION_COMPARE, it.id, code = 4))
        }
        notify(ctx, ID_DONE, b.build())
    }

    /** A notification that needs a tap, used when Android will not let the app start by itself. */
    fun nudge(ctx: Context, title: String, text: String) {
        val n = NotificationCompat.Builder(ctx, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title).setContentText(text).setAutoCancel(true)
            .setContentIntent(open(ctx, MainActivity.ACTION_RESUME, code = 5))
            .build()
        notify(ctx, ID_NUDGE, n)
    }

    fun notify(ctx: Context, id: Int, n: Notification) {
        runCatching { ctx.getSystemService(NotificationManager::class.java).notify(id, n) }
    }

    fun cancel(ctx: Context, id: Int) {
        runCatching { ctx.getSystemService(NotificationManager::class.java).cancel(id) }
    }
}

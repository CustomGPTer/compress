package uk.jj.compress.engine

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.Metadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.SpeedParameters
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.DefaultGainProvider
import androidx.media3.common.audio.GainProcessor
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.common.util.ExperimentalApi
import androidx.media3.common.util.UnstableApi
import androidx.media3.container.MdtaMetadataEntry
import androidx.media3.container.Mp4LocationData
import androidx.media3.effect.Crop
import androidx.media3.effect.FrameDropEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.transformer.AudioEncoderSettings
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.InAppMp4Muxer
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

data class EngineInput(val uri: Uri, val info: SourceInfo)

data class EngineResult(
    val ok: Boolean,
    val message: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    /** A plain-English note when the phone could not do exactly what was asked. */
    val note: String? = null,
)

/**
 * The fast engine: the phone's own video chip, driven through Media3's Transformer.
 * Everything here runs on the main thread, as Transformer requires.
 */
@OptIn(UnstableApi::class, ExperimentalApi::class)
class FastEngine(private val ctx: Context) {

    private val main = Handler(Looper.getMainLooper())

    private class ConstantSpeed(private val speed: Float) : SpeedProvider {
        override fun getSpeed(timeUs: Long) = speed
        override fun getNextSpeedChangeTimeUs(timeUs: Long) = C.TIME_UNSET
    }

    private fun mediaItem(input: EngineInput, opt: Options, trim: Boolean): MediaItem {
        // With the media-location permission, ask Android for the untouched file so the place it was filmed survives.
        val wantsLocation = opt.keepInfo && !opt.stripLocation &&
            ctx.checkSelfPermission(android.Manifest.permission.ACCESS_MEDIA_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED
        val uri = if (wantsLocation && input.uri.authority == android.provider.MediaStore.AUTHORITY)
            runCatching { android.provider.MediaStore.setRequireOriginal(input.uri) }.getOrDefault(input.uri) else input.uri
        val b = MediaItem.Builder().setUri(uri)
        if (trim && opt.hasTrim) {
            val end = if (opt.trimEndMs > 0) minOf(opt.trimEndMs, input.info.durationMs) else input.info.durationMs
            val start = opt.trimStartMs.coerceIn(0, end)
            b.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder().setStartPositionMs(start).setEndPositionMs(end).build()
            )
        }
        return b.build()
    }

    private fun videoEffects(opt: Options, plan: Plan, src: SourceInfo, forceSize: Boolean): List<Effect> {
        val fx = mutableListOf<Effect>()
        opt.crop?.takeIf { !it.isFull }?.let {
            // Crop takes edges in the -1..1 square, with +1 at the top.
            fx += Crop(-1f + 2f * it.left, -1f + 2f * it.right, 1f - 2f * it.bottom, 1f - 2f * it.top)
        }
        if (opt.rotate != 0 || opt.flip) {
            val b = ScaleAndRotateTransformation.Builder()
            // The effect turns anticlockwise; the app's setting is clockwise.
            if (opt.rotate != 0) b.setRotationDegrees((360 - opt.rotate).toFloat())
            if (opt.flip) b.setScale(-1f, 1f)
            fx += b.build()
        }
        val srcFps = if (src.fps > 1f) src.fps else 30f
        if (opt.fps > 0 && plan.fps < srcFps - 0.5f || opt.speed > 1f) {
            fx += FrameDropEffect.createDefaultFrameDropEffect(plan.fps)
        }
        val (naturalW, naturalH) = Planner.outputSize(src, opt.copy(shortSide = 0))
        if (forceSize || naturalW != plan.width || naturalH != plan.height) {
            fx += Presentation.createForWidthAndHeight(plan.width, plan.height, Presentation.LAYOUT_SCALE_TO_FIT)
        }
        return fx
    }

    private fun audioEffects(opt: Options): List<AudioProcessor> {
        val fx = mutableListOf<AudioProcessor>()
        if (opt.volume != 1f) fx += GainProcessor(DefaultGainProvider.Builder(opt.volume).build())
        return fx
    }

    private fun friendly(e: ExportException): String = when (e.errorCode) {
        ExportException.ERROR_CODE_IO_FILE_NOT_FOUND -> "The video could not be found. It may have been moved or deleted."
        ExportException.ERROR_CODE_IO_NO_PERMISSION -> "Compress is not allowed to read this video."
        ExportException.ERROR_CODE_DECODER_INIT_FAILED,
        ExportException.ERROR_CODE_DECODING_FAILED,
        ExportException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED -> "This phone could not read the video's format."
        ExportException.ERROR_CODE_ENCODER_INIT_FAILED,
        ExportException.ERROR_CODE_ENCODING_FAILED,
        ExportException.ERROR_CODE_ENCODING_FORMAT_UNSUPPORTED -> "The phone's video chip refused these settings."
        ExportException.ERROR_CODE_MUXING_FAILED,
        ExportException.ERROR_CODE_MUXING_TIMEOUT,
        ExportException.ERROR_CODE_MUXING_APPEND -> "The new file could not be written."
        ExportException.ERROR_CODE_VIDEO_FRAME_PROCESSING_FAILED -> "The picture could not be processed."
        ExportException.ERROR_CODE_AUDIO_PROCESSING_FAILED -> "The sound could not be processed."
        else -> "Something went wrong while compressing (${e.errorCodeName})."
    }

    fun isMuxError(message: String?) = message == "The new file could not be written."

    /**
     * @param inputs one video, or several to be joined end to end.
     * @param compatMuxer write the file with Android's own writer instead of Media3's.
     */
    suspend fun run(
        inputs: List<EngineInput>, out: File, opt: Options, plan: Plan,
        compatMuxer: Boolean = false, onProgress: (Int) -> Unit,
    ): EngineResult = withContext(Dispatchers.Main.immediate) {
        val first = inputs.first().info
        val joining = inputs.size > 1
        val audioOnly = opt.tool == Tool.AUDIO_ONLY
        val anyHdr = inputs.any { it.info.isHdr }
        val codec = opt.codec

        val items = inputs.map { input ->
            val b = EditedMediaItem.Builder(mediaItem(input, opt, trim = !joining))
            if (audioOnly) b.setRemoveVideo(true)
            if (plan.audioBitrate == 0 && !audioOnly) b.setRemoveAudio(true)
            val vfx = if (audioOnly) emptyList() else
                videoEffects(if (joining) Options(rotate = 0) else opt, plan, input.info, forceSize = joining)
            b.setEffects(Effects(audioEffects(opt), vfx))
            if (opt.speed != 1f && !joining) b.setSpeed(SpeedParameters(ConstantSpeed(opt.speed), true))
            b.build()
        }

        // Say which tracks the result has. A clip with no sound is given silence when it is joined to ones that have it.
        val sequence = when {
            audioOnly -> EditedMediaItemSequence.withAudioFrom(items)
            plan.audioBitrate == 0 -> EditedMediaItemSequence.withVideoFrom(items)
            else -> EditedMediaItemSequence.withAudioAndVideoFrom(items)
        }
        val composition = Composition.Builder(sequence)
            .setHdrMode(
                if (anyHdr && opt.hdr == HdrMode.KEEP && codec != Codec.H264 && !joining) Composition.HDR_MODE_KEEP_HDR
                else Composition.HDR_MODE_TONE_MAP_HDR_TO_SDR_USING_OPEN_GL
            )
            .build()

        val encoders = DefaultEncoderFactory.Builder(ctx).setEnableFallback(true)
        if (!audioOnly) {
            encoders.setRequestedVideoEncoderSettings(
                VideoEncoderSettings.Builder().setBitrate(plan.videoBitrate).build()
            )
        }
        val reencodeAudio = plan.audioBitrate > 0 && !plan.audioCopied
        if (reencodeAudio) {
            encoders.setRequestedAudioEncoderSettings(AudioEncoderSettings.Builder().setBitrate(plan.audioBitrate).build())
        }

        var note: String? = null
        var result: EngineResult? = null
        var poll: Job? = null

        suspendCancellableCoroutine { cont ->
            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    result = EngineResult(true, null, exportResult.width, exportResult.height, note)
                    if (cont.isActive) cont.resume(Unit)
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    result = EngineResult(false, friendly(exportException))
                    if (cont.isActive) cont.resume(Unit)
                }

                override fun onFallbackApplied(
                    composition: Composition,
                    originalTransformationRequest: androidx.media3.transformer.TransformationRequest,
                    fallbackTransformationRequest: androidx.media3.transformer.TransformationRequest,
                ) {
                    val notes = mutableListOf<String>()
                    if (originalTransformationRequest.videoMimeType != fallbackTransformationRequest.videoMimeType) {
                        notes += "This phone's chip could not write ${codec.label}, so a format it supports was used."
                    }
                    if (originalTransformationRequest.hdrMode != fallbackTransformationRequest.hdrMode) {
                        notes += "HDR could not be kept on this phone, so the video was converted to normal colour."
                    }
                    if (originalTransformationRequest.outputHeight != fallbackTransformationRequest.outputHeight) {
                        notes += "The picture size was adjusted to one the phone's chip supports."
                    }
                    if (notes.isNotEmpty()) note = notes.joinToString(" ")
                }
            }

            val builder = Transformer.Builder(ctx)
                .setEncoderFactory(encoders.build())
                .addListener(listener)
            if (!audioOnly) builder.setVideoMimeType(codec.mime)
            if (reencodeAudio) builder.setAudioMimeType(MimeTypes.AUDIO_AAC)
            if (!compatMuxer) {
                builder.setMuxerFactory(InAppMp4Muxer.Factory(InAppMp4Muxer.MetadataProvider { entries: MutableSet<Metadata.Entry> ->
                    if (!opt.keepInfo) entries.clear()
                    else if (opt.stripLocation) entries.removeAll {
                        it is Mp4LocationData || (it is MdtaMetadataEntry && it.key.contains("location", ignoreCase = true))
                    }
                }))
            }
            val transformer = builder.build()

            val holder = ProgressHolder()
            poll = launch {
                while (isActive) {
                    if (transformer.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) onProgress(holder.progress)
                    delay(400)
                }
            }
            cont.invokeOnCancellation {
                main.post { runCatching { transformer.cancel() } }
            }
            try {
                transformer.start(composition, out.absolutePath)
            } catch (e: Exception) {
                result = EngineResult(false, "The video could not be opened for compressing.")
                if (cont.isActive) cont.resume(Unit)
            }
        }
        poll?.cancel()
        result ?: EngineResult(false, "Stopped.")
    }
}
